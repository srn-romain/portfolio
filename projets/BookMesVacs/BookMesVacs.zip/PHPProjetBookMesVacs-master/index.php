<html>
<head>
    <title>log in</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="lib/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="lib/css/design.css" rel="stylesheet">
    <script src="lib/jquery/jquery-2.1.3.min.js"></script>
    <script src="lib/bootstrap/js/ui-bootstrap-tpls.js" type="text/javascript"></script>
    <script src="lib/bootstrap/js/bootstrap.js"></script>
</head>
<body class="FondEcranIndex">

<?php
// Démarre la session
session_start();
// Vérifie si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['signOut'])) {
    // Vérifie les identifiants et mot de passe
    $userName = $_POST["userName"];
    $password = $_POST["password"];
    if ($userName == "adminsio" && $password == "siosio") {
        // Identifiants valides, stocke le nom d'utilisateur dans la session
        $_SESSION["userName"] = $userName;

        // Redirige vers la page d'accueil
        header("Location: vues/accueil.php");
        exit;
    } elseif ($userName == "editeursio" && $password == "siosio") {
        // Identifiants valides, stocke le nom d'utilisateur dans la session
        $_SESSION["userName"] = $userName;

        // Redirige vers la page d'accueil
        header("Location: vues/accueil.php");
        exit;}



else {
        // Identifiants invalides, affiche un message d'erreur
        $errorMessage = "Identifiants invalides";
    }
}

// Affiche le formulaire de connexion
?>

<h1>Bienvenue sur Bookmesvacs.fr !</h1>
<br><br><br>
<div class="wrapper">
    <div class="text-center mt-4 name">
        <b>Connectez-vous à votre Espace Client</b>
    </div><br>
    <?php if (isset($errorMessage)) { ?>
        <div class="alert alert-danger"><?= $errorMessage ?></div>
    <?php } ?>
    <form class="p-3 mt-3" action="index.php" method="post">
        <div class="text-center">
            <span class="far fa-user"></span>
            <input type="text" name="userName" id="userName" placeholder="Identifiant" autocomplete="off">
        </div>
        <br>
        <div class="text-center">
            <span class="fas fa-key"></span>
            <input type="password" name="password" id="pwd" placeholder=" Mot de passe" autocomplete="off">
        </div>
        <br>
        <form action="vues/accueil.php" method="post" class="text-center">
            <input type="submit" value="Connexion" class="btn" />
        </form>
    </form>
    <!--<div class="text-center" >
        <a class="btn2" href="vues/MotDePasseOublie.php">Mot de passe oublié ? </a>
    </div>-->
    <form action="vues/MotDePasseOublie.php" method="post" class="text-center" >
        <input type="submit" value="Mot de passe oublié ?" class="btn2" />
    </form>
</div>

<br>
<h2 class="container text-center" style="font-family: 'Comic Sans MS'">Chez nous, la préservation de l'environnement est primordiale, c'est pourquoi nous encourageons les transports peu polluant pour vos voyages. Profitez de vos vacances tout en réduisant votre impact sur la planète !</h2>
<br>



<div id="slideshow">
    <?php
    $ads = [
        [
            'image' => 'vetement.jpg',
            'title' => 'Découvrez notre nouvelle collection de vêtements',
            'description' => 'Profitez de nos prix exclusifs pour renouveler votre garde-robe'
        ],
        [
            'image' => 'vetement2.jpg',
            'title' => 'Offre spéciale : -50% sur tous les produits',
            'description' => 'Ne manquez pas cette occasion de faire des économies sur vos achats en ligne'
        ],
        [
            'image' => 'vetement3.jpg',
            'title' => 'Inscrivez-vous dès maintenant à notre programme fidélité',
            'description' => 'Bénéficiez de nombreux avantages exclusifs en devenant membre de notre communauté'
        ]
    ];

    shuffle($ads);

    foreach ($ads as $ad) {
        echo '<div class="slide">';
        echo '<img src="lib/img/' . $ad['image'] . '"/>';
        echo '<h2>' . $ad['title'] . '</h2>';
        echo '<p>' . $ad['description'] . '</p>';
        echo '</div>';
    }
    ?>
</div>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    form {
        text-align: center;
    }

    form .btn {
        display: inline-block;
    }





    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn2 {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #D7432F;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn2:hover {
        background-color: #EE6A59;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }






    #slideshow {
        position: relative;
        width: 800px;
        height: 600px;
        margin: 50px auto;
    }

    .slide {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: none;
        text-align: center;
        padding: 50px;
        background-color: #fff;
    }

    .slide img {
        max-width: 1500px;
        max-height: 900px;
        margin-bottom: 20px;
    }

    .slide h2 {
        font-size: 36px;
        margin-bottom: 20px;
    }

    .slide p {
        font-size: 24px;
        line-height: 1.5;
    }
</style>

<script>
    var slideIndex = 0;
    showSlides();

    function showSlides() {
        var i;
        var slides = document.getElementsByClassName("slide");
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) {
            slideIndex = 1
        }
        slides[slideIndex - 1].style.display = "block";
        setTimeout(showSlides, 5000); // Change image every 5 seconds
    }
</script>


</body>
</html>