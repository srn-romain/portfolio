<?php
require_once 'Connexion.php' ;
class DialogueBD {
    public function getTousLesDest() {
        try {
            $conn = Connexion::getConnexion();
            $sql = "select distinct * from destination d join pays py on d.idpays=py.idpays order by nompays";
            $sth = $conn->prepare($sql);
            $sth->execute();
            $tabDest = $sth->fetchAll(PDO::FETCH_ASSOC);
            return $tabDest;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getTousLesClients() {
        try {
            $conn = Connexion::getConnexion();
            $sql = "select distinct * from client ";
            $sth = $conn->prepare($sql);
            $sth->execute();
            $tabcli = $sth->fetchAll(PDO::FETCH_ASSOC);
            return $tabcli;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getTousLesResas() {
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT c.IDCLIENT,d.IMG_DEST,c.NOMCLI,c.PRENOMCLI,s.DATE_DEB,s.DATE_FIN,d.NOMDEST,s.MOYEN_TRANSPORT,p.NOMPAYS, d.IDDEST FROM client c JOIN se_rendre s ON c.IDCLIENT=s.IDCLIENT JOIN destination d ON s.IDDEST=d.IDDEST JOIN pays p ON d.IDPAYS=p.IDPAYS GROUP BY d.NOMDEST, c.IDCLIENT ORDER BY c.IDCLIENT;";
            $sth = $conn->prepare($sql);
            $sth->execute();
            $tabcli = $sth->fetchAll(PDO::FETCH_ASSOC);
            return $tabcli;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getUnClient($code) {
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT * FROM client WHERE IDCLIENT=?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($code));
            $employe = $sth->fetchObject();
            return $employe;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getUnPays($code) {
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT * FROM pays WHERE IDPAYS=?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($code));
            $employe = $sth->fetchObject();
            return $employe;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getUnHeber($heber) {
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT h.IDHEBER, h.NOMHEBER, d.NOMDEST, t.TYPEHEBER, h.NBETOILE, p.NOMPAYS FROM hebergement h JOIN destination d ON h.IDDEST=d.IDDEST JOIN typeheber t ON h.IDTYPEHEBER=t.IDTYPEHEBER JOIN pays p ON d.IDPAYS=p.IDPAYS WHERE h.IDHEBER=?;";
            $sth = $conn->prepare($sql);
            $sth->execute(array($heber));
            $rep = $sth->fetchObject();
            return $rep;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
            echo $erreur;
        }
    }

    public function getUneDest($code) {
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT * FROM destination WHERE IDDEST=?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($code));
            $employe = $sth->fetchObject();
            return $employe;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getUneResa($iddest,$idclient) {
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT * FROM se_rendre WHERE IDDEST=? AND IDCLIENT=?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($iddest,$idclient));
            $employe = $sth->fetchObject();
            return $employe;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function addUnClient($nom,$prenom,$sexe,$email,$tel)
    {   $ajoutOk = false;
        try {
            $conn = Connexion::getConnexion();
            $sql = "INSERT INTO client (nomcli,prenomcli,sexe,email,telephone) VALUES (?,?,?,?,?)";
            $sth = $conn->prepare($sql);
            $sth->execute(array($nom,$prenom,$sexe,$email,$tel));
        }catch(Exception $e){
            $erreur = $e->getMessage().'('.$e->getFile().',ligne'.$e->getLine().')';
            echo "$e ->getMessage";
        }
        return $ajoutOk;
    }

    public function addUneDest($idpays,$nomd,$img,$com)
    {   $ajoutOk = false;
        try {
            $conn = Connexion::getConnexion();
            $sql = "INSERT INTO destination (IDPAYS,NOMDEST,IMG_DEST,INFODEST) VALUES (?,?,?,?)";
            $sth = $conn->prepare($sql);
            $sth->execute(array($idpays,$nomd,$img,$com));
        }catch(Exception $e){
            $erreur = $e->getMessage().'('.$e->getFile().',ligne'.$e->getLine().')';
            echo "$e ->getMessage";
        }
        return $ajoutOk;
    }

    public function addResa($lieu,$nom,$dateD,$dateF,$transp)
    {   $ajoutOk = false;
        try {
            $conn = Connexion::getConnexion();
            $sql = "INSERT INTO se_rendre (IDDEST,IDCLIENT,DATE_DEB,DATE_FIN,MOYEN_TRANSPORT) VALUES (?,?,?,?,?)";
            $sth = $conn->prepare($sql);
            $sth->execute(array($lieu,$nom,$dateD,$dateF,$transp));
        }catch(Exception $e){
            $erreur = $e->getMessage().'('.$e->getFile().',ligne'.$e->getLine().')';
            echo "$e ->getMessage";
        }
        return $ajoutOk;
    }

    public function getTousLesTypes(){
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT * FROM typeheber order by TYPEHEBER";
            $sth = $conn->prepare($sql);
            $sth->execute();
            $tabType = $sth->fetchAll(PDO::FETCH_ASSOC);
            return $tabType;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getTousLesPays(){
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT * FROM pays order by NOMPAYS";
            $sth = $conn->prepare($sql);
            $sth->execute();
            $tabpays = $sth->fetchAll(PDO::FETCH_ASSOC);
            return $tabpays;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getTousLesContinents(){
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT DISTINCT CONTINENT FROM PAYS order by CONTINENT";
            $sth = $conn->prepare($sql);
            $sth->execute();
            $tabpays = $sth->fetchAll(PDO::FETCH_ASSOC);
            return $tabpays;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getTousLesHeber(){
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT * FROM hebergement order by NOMHEBER";
            $sth = $conn->prepare($sql);
            $sth->execute();
            $tabpays = $sth->fetchAll(PDO::FETCH_ASSOC);
            return $tabpays;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getHeberParType($partype){
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT * FROM HEBERGEMENT WHERE IDTYPEHEBER=?";
            $sql = $sql." ORDER BY NOMHEBER";
            $sth = $conn->prepare($sql);
            $sth->execute(array($partype));
            $tabheber = $sth->fetchAll(PDO::FETCH_ASSOC);
            return $tabheber;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getDestParPays($parpays){
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT * FROM destination WHERE IDPAYS=?";
            $sql = $sql." ORDER BY NOMDEST";
            $sth = $conn->prepare($sql);
            $sth->execute(array($parpays));
            $tabpays = $sth->fetchAll(PDO::FETCH_ASSOC);
            return $tabpays;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function clientParDest($dest){
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT c.IDCLIENT, c.NOMCLI, c.PRENOMCLI, c.SEXE, c.EMAIL, c.TELEPHONE,d.IMG_DEST FROM client c JOIN se_rendre s ON c.IDCLIENT=s.IDCLIENT JOIN destination d ON s.IDDEST=d.IDDEST WHERE d.IDDEST=?";
            $sql = $sql." ";
            $sth = $conn->prepare($sql);
            $sth->execute(array($dest));
            $tabdest = $sth->fetchAll(PDO::FETCH_ASSOC);
            return $tabdest;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getNomdutype($partype){
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT * FROM typeheber t WHERE t.IDTYPEHEBER=?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($partype));
            $leNomduType = $sth->fetchObject();
            return $leNomduType;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getNomdupays($parpays){
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT * FROM pays p WHERE p.IDPAYS=?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($parpays));
            $leNomduPays = $sth->fetchObject();
            return $leNomduPays;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function getNomDest($dest){
        try {
            $conn = Connexion::getConnexion();
            $sql = "SELECT * FROM destination d  WHERE d.IDDEST=?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($dest));
            $leNomdelaDest = $sth->fetchObject();
            return $leNomdelaDest;
        } catch (PDOException $e) {
            $erreur = $e->getMessage();
        }
    }

    public function supprClient($client){
        $supprOk = false;
        try{
            $conn = Connexion::getConnexion();
            $sql = "DELETE FROM client WHERE IDCLIENT= ?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($client));
            $supprOk = true;
        }catch(Exception $e){
            $erreur = $e->getMessage().'('.$e->getFile().',ligne'.$e->getLine().')';
        }
        return $supprOk ;
    }

    public function supprDest($iddest){
        $supprOk = false;
        try{
            $conn = Connexion::getConnexion();
            $sql = "DELETE FROM destination WHERE IDDEST= ?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($iddest));
            $supprOk = true;
        }catch(Exception $e){
            $erreur = $e->getMessage().'('.$e->getFile().',ligne'.$e->getLine().')';
        }
        return $supprOk ;
    }

    public function supprResa($iddest,$idclient){
        $supprOk = false;
        try{
            $conn = Connexion::getConnexion();
            $sql = "DELETE FROM se_rendre WHERE IDDEST=? AND IDCLIENT=?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($iddest,$idclient));
            $supprOk = true;
            echo $iddest,$idclient;
        }catch(Exception $e){
            $erreur = $e->getMessage().'('.$e->getFile().',ligne'.$e->getLine().')';
            echo $erreur;
        }
        return $supprOk ;
    }

    function modifuneDest($ville, $image, $commentaire, $id){
        $modifOk = false;
        try{
            $conn = Connexion::getConnexion();
            $sql = "UPDATE destination SET NOMDEST = ?, IMG_DEST = ?, INFODEST = ? WHERE IDDEST = ?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($ville, $image, $commentaire, $id));
            $modifOk = true;
        }catch(PDOException $e){
            $erreur = $e->getMessage();
            echo  $erreur;
        }
        return $modifOk;
    }

    function modifunClient($code, $nom, $prenom, $sexe, $email, $tel){
        $modifOk = false;
        try{
            $conn = Connexion::getConnexion();
            $sql = "UPDATE client SET NOMCLI = ?, PRENOMCLI = ?, SEXE = ?, EMAIL = ?, TELEPHONE = ? WHERE IDCLIENT = ?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($nom, $prenom, $sexe, $email, $tel, $code));
            $modifOk = true;
        }catch(PDOException $e){
            $erreur = $e->getMessage();
        }
        return $modifOk;
    }

    function modifuneResa($dateD, $dateF, $transp, $DESTINATION,$CLIENT){
        $modifOk = false;
        try{
            $conn = Connexion::getConnexion();
            $sql = "UPDATE se_rendre SET DATE_DEB = ?, DATE_FIN = ?, MOYEN_TRANSPORT = ? WHERE IDDEST = ? AND IDCLIENT=?";
            $sth = $conn->prepare($sql);
            $sth->execute(array($dateD, $dateF, $transp, $DESTINATION, $CLIENT));
            $modifOk = true;
        }catch(PDOException $e){
            $erreur = $e->getMessage();
        }
        return $modifOk;
    }
}