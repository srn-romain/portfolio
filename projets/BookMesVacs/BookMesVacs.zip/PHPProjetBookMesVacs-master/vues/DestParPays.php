<?php
// PARTIE DONNES ---------------------------------------------------------
// inclusion de la méthode de dialogue avec la BD
require_once '../persistance/DialogueBD.php';
require_once("menu.html");
require_once 'header.php';


try {
    $undlg = new DialogueBD();

    $parpays = $_POST['pays'];

    $mesDest = $undlg->getDestParPays($parpays);
    $lePays = $undlg->getNomdupays($parpays);


} catch (Exception $e) {
    $erreur = $e->getMessage();
}
?>
<!-- PARTIE AFFICHAGE --------------------------------------------------- -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Pays par destination</title>
    <link rel="stylesheet" />
</head>
<body>
<?php
if (isset($msgErreur)) {
    echo "Erreur : $msgErreur";
}
?>

<h1>Liste des destinations en <?php
    echo $lePays->NOMPAYS;
    ?> </h1>

<table class="table table-bordered table-striped">
    <thead>
    <tr>
        <th>Id</th>
        <th>Nom destination</th>
        <th>Photo</th>
        <th>Info pratique pour votre voyage</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $lignes="";
    $nbdest = 0;
    foreach ($mesDest as $dest)
    { // On parcourt la collection
        $lignes .= "<tr>\n"; // On construit une ligne <tr>
        $lignes .= "<td> $dest[IDDEST]</td>\n"; // On construit un <td>
        $lignes .= "<td> $dest[NOMDEST]</td>\n";
        $lignes .= "<td> <img src='../lib/img/$dest[IMG_DEST]' width='400' height='200'></td>\n";
        $lignes .= "<td> $dest[INFODEST]</td>\n";
        $lignes .= "</tr>\n";
        $nbdest ++ ;
    }
    echo utf8_encode($lignes);

    ?>
    </tbody>
</table>
<?php
if ($nbdest==1){
    ?><p class="container text-center" style="font-family: 'Comic Sans MS'; font-size: 32px"><?php echo "Il y a $nbdest destination en $lePays->NOMPAYS "; ?></p><?php ;
}else{
    ?><p class="container text-center" style="font-family: 'Comic Sans MS'; font-size: 32px"><?php echo "Il y a $nbdest destinations en $lePays->NOMPAYS "; ?></p><?php
} ?>


<div class="form-group">
    <div class="text-center">
        &nbsp;
        <button type="button" class="btn btn-default btn-primary"
                onclick="javascript: window.location='trie.php';"><span
                    class="glyphicon glyphicon glyphicon-ban-circle"></span> Retour
        </button>
    </div>
</div>

<div id="slideshow2">
    <?php
    $ads = [
        [
            'image' => 'pub3.jpg',
            'title' => 'Profitez de nos soldes d\'été jusqu\'à -70%',
            'description' => 'Trouvez les meilleures montres haut-de-gamme sur notre site internet'
        ],
        [
            'image' => 'pub1.jpg',
            'title' => 'Offrez-vous une escapade en amoureux dans notre hôtel 5 étoiles',
            'description' => 'Détendez-vous dans un cadre idyllique et profitez de nos prestations haut de gamme'
        ],
        [
            'image' => 'pub2.jpg',
            'title' => 'Abonnez-vous à notre box mensuelle et recevez chaque mois une sélection de produits exclusifs',
            'description' => 'Découvrez de nouvelles marques et produits de qualité chaque mois'
        ]
    ];

    shuffle($ads);

    foreach ($ads as $ad) {
        echo '<div class="slide">';
        echo '<img src="../lib/img/' . $ad['image'] . '"/>';
        echo '<h2>' . $ad['title'] . '</h2>';
        echo '<p>' . $ad['description'] . '</p>';
        echo '</div>';
    }
    ?>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>


<script>
    var slideIndex2 = 0;
    showSlides2();

    function showSlides2() {
        var i;
        var slides = document.getElementById("slideshow2").getElementsByTagName("div");
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex2++;
        if (slideIndex2 > slides.length) {
            slideIndex2 = 1
        }
        slides[slideIndex2 - 1].style.display = "block";
        setTimeout(showSlides2, 5000); // Change image every 5 seconds
    }
</script>


<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }



    #slideshow2 {
        position: relative;
        width: 800px;
        height: 600px;
        margin: 50px auto;
    }

    .slide {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: none;
        text-align: center;
        padding: 50px;
        background-color: #fff;
    }

    .slide img {
        max-width: 600px;
        max-height: 300px;
        margin-bottom: 20px;
    }

    .slide h2 {
        font-size: 36px;
        margin-bottom: 20px;
    }

    .slide p {
        font-size: 24px;
        line-height: 1.5;
    }
</style>
</body>
</html>