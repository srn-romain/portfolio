<!DOCTYPE html>
<html>
<head>
    <title>Mot de passe oublié</title>
</head>
<body>

<?php
require_once 'header.php';
if (isset($_POST['submit'])) {
    // vérifier si l'adresse e-mail a été saisie
    if (!empty($_POST['email'])) {
        // récupérer l'adresse e-mail
        $email = $_POST['email'];
        // afficher un message indiquant que l'e-mail a bien été envoyé
        echo '<p>Un e-mail de réinitialisation de mot de passe a été envoyé à ' . $email . '. Veuillez consulter votre boîte de réception.</p>';
    } else {
        // afficher un message d'erreur si l'adresse e-mail n'a pas été saisie
        echo '<p>Veuillez saisir une adresse e-mail valide.</p>';
    }
}
?>

<h1>Mot de passe oublié</h1>
<div class="well">
    <form method="post" class="form-horizontal" action="MotDePasseOublie.php">

        <div class="form-group">
            <label class="col-md-3 control-label">Email de réinitialisation:</label>
            <div class="col-md-3">
                <input name="email" type="email" class="form-control" required autofocus/>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label" for="acceptation_conditions">J'accepte les conditions générales d'utilisation :</label>
            <div class="col-md-3">
                <input type="checkbox" id="acceptation_conditions" name="acceptation_conditions" required><br>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
                <button type="submit" class="btn btn-default btn-primary"><span

                            class="glyphicon glyphicon-ok"></span> Envoyer</button>
                &nbsp;
                <button type="button" class="btn btn-default btn-primary"
                        onclick="javascript: window.location='../index.php';"><sapan
                            class="glyphicon glyphicon-ban-circle"></sapan> Retour
                </button>
            </div>
        </div>
    </form>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<script>
    document.querySelector('form').addEventListener('submit', function(e) {
        e.preventDefault(); // Empêche l'envoi du formulaire
        var email = document.querySelector('input[name="email"]').value; // Récupère l'adresse email
        var modal = document.createElement('div'); // Crée une div pour la fenêtre modale
        modal.classList.add('modal'); // Ajoute une classe à la div pour le CSS
        modal.innerHTML = '<p>Un e-mail de réinitialisation de mot de passe a été envoyé à ' + email + '. Veuillez consulter votre boîte de réception.</p><button class="close-modal">Fermer</button>'; // Ajoute le contenu de la fenêtre modale
        document.body.appendChild(modal); // Ajoute la fenêtre modale au DOM

        // Ferme la fenêtre modale lorsque l'utilisateur clique sur le bouton "Fermer"
        modal.querySelector('.close-modal').addEventListener('click', function() {
            modal.remove();
        });
    });
</script>
<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .modal {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .modal p {
        font-size: 18px;
        color: #fff;
        text-align: center;
        margin-bottom: 20px;
    }

    .close-modal {
        background-color: #fff;
        color: #000;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }
</style>



</body>
</html>
