<?php
require_once("menu.html");
require_once'header.php';

// PARTIE DONNES ---------------------------------------------------------
require_once '../persistance/DialogueBD.php';



if (isset($_POST['client'])){
    $idclient= $_POST['client'];
    try{

        $undlg = new DialogueBD();
        $OK = $undlg ->supprClient($idclient);
        header("location: listerClient.php");
    } catch (Exception $e){
        $erreur = $e ->getMessage();
    }
}

if (isset($_POST['destination'])){
    $iddest= $_POST['destination'];
    try{

        $undlg = new DialogueBD();
        $OK = $undlg ->supprDest($iddest);
        header("location: listerDest.php");
    } catch (Exception $e){
        $erreur = $e ->getMessage();
    }
}

if (isset($_GET['id'])&& isset($_GET['client'])){ // Modiifer condition avec les deux Get
    $iddestSelec= $_GET['id']; // ModifIer get
    $idclientSelec= $_GET['client']; // Modifier get
    $aSupprimerReservation = false;
} else {
    if (isset($_POST['reservation'])){ // Modiifer condition avec les deux Get
        $reservation= $_POST['reservation']; // ModifIer get
        $Detailresa = explode(",", $reservation);
        $idclient= $Detailresa[0]; // ModifIer get
        $iddest= $Detailresa[1]; // Modifier get
        $aSupprimerReservation = true;
    } else {
        $aSupprimerReservation = false;

    }
}


 if  ($aSupprimerReservation == true){
    try{

        $undlg = new DialogueBD();
        $OK = $undlg ->supprResa($iddest,$idclient);
       header("location: listerReservation.php");
    } catch (Exception $e){
        $erreur = $e ->getMessage();
    }
}

try{
    $undlg = new DialogueBD();
    $mesClients = $undlg->getTousLesClients();
    $mesDest = $undlg->getTousLesDest();
    $mesresa= $undlg->getTousLesResas();

}catch (Exception $e){
    $erreur = $e ->getMessage();
}

?>
<!-- PARTIE AFFICHAGE --------------------------------------------------- -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <link rel="stylesheet" />
    <title>Supprimer un client</title>
</head>
<body>
<h1>Suppression d'un Client</h1>
<div class="well">
    <form class="formulaire" action="Supprimer.php" method="post">
        <ul>
            <label for="champClient"> </label>
            <select name="client" id="champClient" class="form-control form-control-lg">
                <option selected="selected"> Selectionnez un client à supprimer </option>
                <?php
                foreach ($mesClients as $ligne) {
                    $idClient = $ligne['IDCLIENT'];
                    $nom = $ligne['NOMCLI'];
                    $prenom = $ligne['PRENOMCLI'];
                    $sexe = $ligne['SEXE'];
                    if(isset($_GET['code2']))
                    {
                        if ($_GET['code2']==$idClient){
                            echo "<option value='$idClient' selected>$nom  $prenom - $sexe</option>";
                        }else{
                        echo "<option value='$idClient'>$nom  $prenom - $sexe</option>";
                    }
                }else{
                    echo "<option value='$idClient'>$nom  $prenom - $sexe</option>";
                }}
                ?>
            </select>
        </ul>
        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span class="glyphicon glyphicon-ok"></span>Valider</button>&nbsp;
                <button type="button" class="btn btn-default btn-primary" onclick="javascript: window.location='Supprimer.php';"><span class="glyphicon glyphicon-remove"></span> Annuler</button>
            </div>
        </div>
    </form>
</div>

<br>

<h1>Suppression d'une destination</h1>
<div class="well">
    <form class="formulaire" action="Supprimer.php" method="post">
        <ul>
            <label for="champDest"> </label>
            <select name="destination" id="champDest" class="form-control form-control-lg">
                <option selected="selected"> Selectionnez une destination à supprimer </option>
                <?php
                foreach ($mesDest as $ligne) {
                    $code = $ligne['IDDEST'];
                    $dest = $ligne['NOMDEST'];
                    $pays = $ligne['NOMPAYS'];
                    if(isset($_GET['code']))
                    {
                        if ($_GET['code']==$code){
                            echo "<option value='$code' selected>$dest - $pays</option>";
                        }else{
                            echo "<option value='$code'>$dest - $pays</option>";
                        }
                    }else{
                        echo "<option value='$code'>$dest - $pays</option>";
                    }}
                ?>
            </select>
        </ul>
        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span class="glyphicon glyphicon-ok"></span>Valider</button>&nbsp;
                <button type="button" class="btn btn-default btn-primary" onclick="javascript: window.location='Supprimer.php';"><span class="glyphicon glyphicon-remove"></span> Annuler</button>
            </div>
        </div>
    </form>
</div>

<br>

<h1>Suppression d'une réservation </h1>
<div class="well">
    <form class="formulaire" action="Supprimer.php" method="post">
        <ul>
            <label for="champresa"> </label>
            <select name="reservation" id="champresa" class="form-control form-control-lg">
                <option selected="selected"> Selectionnez une réservation à supprimer </option>
                <?php
                foreach ($mesresa as $ligne) {
                    $idClient = $ligne['IDCLIENT'];
                    $idDest = $ligne['IDDEST'];
                    $nom = $ligne['NOMCLI'];
                    $prenom = $ligne['PRENOMCLI'];
                    $dest = $ligne['NOMDEST'];
                    $pays = $ligne['NOMPAYS'];
                    $dateD = $ligne['DATE_DEB'];
                    $dateF = $ligne['DATE_FIN'];
                    $transp = $ligne ['MOYEN_TRANSPORT'];

                    if ( ($idClient ==  $idclientSelec)  && ($idDest == $iddestSelec)){
                    $selected = " selected ";
                    } else {
                        $selected = "";

                    }
                    echo "<option $selected value='$idClient,$idDest' >$nom  $prenom - $dest $pays ($dateD au $dateF) $transp</option>";
                }
                ?>
            </select>
        </ul>
        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span class="glyphicon glyphicon-ok"></span>Valider</button>&nbsp;
                <button type="button" class="btn btn-default btn-primary" onclick="javascript: window.location='Supprimer.php';"><span class="glyphicon glyphicon-remove"></span> Annuler</button>
            </div>
        </div>
    </form>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }
</style>
</body>
</html>