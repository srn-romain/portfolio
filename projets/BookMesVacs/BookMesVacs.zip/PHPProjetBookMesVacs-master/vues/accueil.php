<html>
<head>
    <title>Bienvenue !</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../lib/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="../lib/css/design.css" rel="stylesheet">
    <script src="../lib/jquery/jquery-2.1.3.min.js"></script>
    <script src="../lib/bootstrap/js/ui-bootstrap-tpls.js" type="text/javascript"></script>
    <script src="../lib/bootstrap/js/bootstrap.js"></script>

    <style>

        /* Style CSS pour la fenêtre modale */
        .modal {
            display: none; /* Masque la fenêtre modale par défaut */
            position: fixed; /* Position fixe */
            z-index: 1; /* Met la fenêtre modale en avant-plan */
            left: 0;
            top: 0;
            width: 100%; /* Largeur de la fenêtre modale */
            height: 100%; /* Hauteur de la fenêtre modale */
            overflow: auto; /* Permet le scroll de la page en dessous de la fenêtre modale */
            background-color: rgba(0,0,0,0.4); /* Couleur de fond avec transparence */
        }

        /* Style CSS pour la boîte de dialogue dans la fenêtre modale */
        .modal-dialog {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
        }

    </style>
</head>
<body>
<?php
require_once("menu.html");
require_once 'header.php';
?>


<h1>Bienvenue sur Bookmesvacs.fr !</h1><br>

<br><br>
<h2 class="container text-center" style="font-family: 'Comic Sans MS'">Créé en 1970, BookMesVacs a toujours eu une forte volonté de préserver l'environnement. C'est pourquoi nous avons choisi un style et arrière-plan de couleur vert pour notre site web, symbole de notre engagement en faveur du développement durable. Nous voulons encourager les voyageurs à découvrir de nouveaux horizons tout en minimisant leur impact sur la planète. Grâce à notre site, réservez votre prochain séjour en toute sérénité et en harmonie avec la nature.</h2>

<br><br>
<h2 class="container text-center" style="font-family: 'Comic Sans MS'">Ne laissez pas la chance passer, réservez dès maintenant votre prochaine destination de rêve et vivez des expériences inoubliables !</h2>
<form action="addReservation.php" method="post" class="text-center">
    <input type="submit" value="Je Reserve !" class="btn" />
</form>


<br><br>
<h2 class="container text-center" style="font-family: 'Comic Sans MS'">A court d'idées de destination ? laissez vous tenter...</h2>
<button id="random-country-btn" class="btn" style="font-family: 'Comic Sans MS'"> Idée lumineuse !</button>
<p id="random-country"></p>

<div id="myModal" class="modal">
    <div class="modal-dialog">
        <h2>Bienvenue ! - Gestion Cookie</h2>
        <p>Merci de visiter notre site. Sachez que l'organisation « Bookmesvacs » accorde une grande importance à la protection des données à caractère personnel de ses clients. Les données collectées, telles que le nom, le prenom, le sexe, l'adresse e-mail et le numéro de téléphone, sont utilisées dans le seul but de faciliter la réservation des vacances et de fournir les services associés. </p>
        <button><a href="accueil.php" >J'ai compris</a></button>
        <button><a href="donneeperso.php" >En savoir plus</a></button>
    </div>

</div>

<br>
<h2 class="container text-center">- - - - - - - - - - - - P - U - B - L - I - C - I - T - E - - - - - - - - - - - -</h2>
<div id="slideshow2">
    <?php
    $ads = [
        [
            'image' => 'pub3.jpg',
            'title' => 'Profitez de nos soldes d\'été jusqu\'à -70%',
            'description' => 'Trouvez les meilleures montres haut-de-gamme sur notre site internet'
        ],
        [
            'image' => 'pub1.jpg',
            'title' => 'Offrez-vous une escapade en amoureux dans notre hôtel 5 étoiles',
            'description' => 'Détendez-vous dans un cadre idyllique et profitez de nos prestations haut de gamme'
        ],
        [
            'image' => 'pub2.jpg',
            'title' => 'Abonnez-vous à notre box mensuelle et recevez chaque mois une sélection de produits exclusifs',
            'description' => 'Découvrez de nouvelles marques et produits de qualité chaque mois'
        ]
    ];

    shuffle($ads);

    foreach ($ads as $ad) {
        echo '<div class="slide">';
        echo '<img src="../lib/img/' . $ad['image'] . '"/>';
        echo '<h2>' . $ad['title'] . '</h2>';
        echo '<p>' . $ad['description'] . '</p>';
        echo '</div>';
    }
    ?>
</div>

<form action="mentionlegale.php" method="post" class="text-center">
    <input type="submit" value="Consulter les mentions légales" class="btn" />
</form>
<form action="donneeperso.php" method="post" class="text-center">
    <input type="submit" value="Consulter les données à caractères personnel" class="btn" />
</form>
<form action="formulairereclamation.php" method="post" class="text-center">
    <input type="submit" value="Contacter nos services" class="btn" />
</form>
<br>
<form action="../index.php" method="post" class="text-center" >
    <input type="hidden" name="signOut" value="signOut"/>
    <input type="submit" value="Se deconnecter" class="btn2" />
</form>
<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>


<script>
    // Récupère la fenêtre modale
    var modal = document.getElementById("myModal");

    // Vérifie si un cookie "visited" existe
    if (document.cookie.indexOf("visited") >= 0) {
        // Le cookie existe, donc ne pas afficher la fenêtre modale
        modal.style.display = "none";
    } else {
        // Le cookie n'existe pas, donc afficher la fenêtre modale
        modal.style.display = "block";
        // Crée un cookie "visited" qui expire dans 7 jours
        var d = new Date();
        d.setTime(d.getTime() + (7*24*60*60*1000));
        var expires = "expires="+ d.toUTCString();
        document.cookie = "visited=true;" + expires + ";path=/";
    }

    // Ferme la fenêtre modale si l'utilisateur clique en dehors de la boîte de dialogue
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }




    var slideIndex2 = 0;
    showSlides2();

    function showSlides2() {
        var i;
        var slides = document.getElementById("slideshow2").getElementsByTagName("div");
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex2++;
        if (slideIndex2 > slides.length) {
            slideIndex2 = 1
        }
        slides[slideIndex2 - 1].style.display = "block";
        setTimeout(showSlides2, 5000); // Change image every 5 seconds
    }





    // Dans le fichier JavaScript
    const randomCountryBtn = document.querySelector("#random-country-btn");
    const randomCountry = document.querySelector("#random-country");

    // Fonction qui génère un pays aléatoire
    function generateRandomCountry() {
        // Liste des pays proposés
        const countries = ["Berlin", "Londres", "Sydney", "Vienne", "Rio de Janeiro", "Toronto", "Hong Kong", "Seoul", "Copenhague", "Edimbourg", "Dubai", "Seville", "Barcelone", "Madrid", "Miami", "New York", "Sans Diego", "Los Angeles", "Helsinki", "Paris", "Lyon", "Athenes", "Budapest", "Dublin", "Rome", "Tokyo", "Mexico", "Oslo", "Amsterdam", "Varsovie", "Lisbonne", "Moscou", "St-Petersbourg", "Stockholm", "Prague", "Bangkok", "Istanbul", "Singapour",];

        // Récupération d'un pays aléatoire dans la liste
        const randomIndex = Math.floor(Math.random() * countries.length);
        const randomCountryName = countries[randomIndex];

        // Affichage du pays aléatoire
        randomCountry.textContent = randomCountryName;
    }

    // Ajout de l'écouteur d'événement sur le bouton
    randomCountryBtn.addEventListener("click", generateRandomCountry);
</script>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }


    #slideshow2 {
        position: relative;
        width: 800px;
        height: 600px;
        margin: 50px auto;
    }

    .slide {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: none;
        text-align: center;
        padding: 50px;
        background-color: #fff;
    }

    .slide img {
        max-width: 600px;
        max-height: 300px;
        margin-bottom: 20px;
    }

    .slide h2 {
        font-size: 36px;
        margin-bottom: 20px;
    }

    .slide p {
        font-size: 24px;
        line-height: 1.5;
    }




    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn2 {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #D7432F;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn2:hover {
        background-color: #EE6A59;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }




    #random-country-btn {
        background-color: #348310; /* Couleur de fond */
        color: white; /* Couleur du texte */
        padding: 12px 24px; /* Espacement du texte par rapport aux bords du bouton */
        font-size: 16px; /* Taille du texte */
        border: none; /* Suppression de la bordure */
        border-radius: 4px; /* Ajout d'un arrondi aux coins */
        cursor: pointer; /* Changement du curseur de la souris au survol */
        transition: background-color 0.3s ease; /* Transition fluide de la couleur de fond */
    }
    #random-country-btn:hover {
        background-color: #69C93D; /* Couleur de fond au survol */
    }
    #random-country {
        font-size: 2em;
        font-weight: bold;
        text-align: center;
        margin-top: 20px;
        padding: 10px;
        border-radius: 5px;
        background-color: #69C93D ;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
    }

    #random-country-btn {
        /* Autres styles... */
        display: block;
        margin: 0 auto;
    }
</style>

</body>
</html>