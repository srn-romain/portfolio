<?php
// PARTIE DONNES ---------------------------------------------------------
require_once '../persistance/DialogueBD.php';

$undlg = new DialogueBD();
$tabPays = $undlg->getTousLesPays();


if (isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['sexe']) && isset($_POST['email']) && isset($_POST['telephone'])) {
    try {
        $undlg = new DialogueBD();

        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $sexe = $_POST['sexe'];
        $email = $_POST['email'];
        $tel = $_POST['telephone'];

        $ajoutOK = $undlg->addUnClient($nom,$prenom,$sexe,$email,$tel);
        header("location: listerClient.php");

    } catch (Exception $e) {
        $erreur = $e->getMessage();
    }
}


if (isset($_POST['idpays']) && isset($_POST['nomdest']) && isset($_FILES['couverture']) && isset($_POST['commentaire'])) {
    try {
        $undlg = new DialogueBD();

        $idpays = $_POST['idpays'];
        $nomd = $_POST['nomdest'];

        $image = basename($_FILES['couverture']['name']);
        $tmpname = $_FILES['couverture']['tmp_name'];
        $ok = move_uploaded_file($tmpname, "../lib/img/". $image);
        if ($ok)
        {
            $couverture = $image;
        } else {
            $couverture = "NOPE";
        }

        $com = $_POST['commentaire'];

        $ajoutOK = $undlg->addUneDest($idpays,$nomd,$couverture,$com);
        header("location: listerDest.php");

    } catch (Exception $e) {
        $erreur = $e->getMessage();
    }
}
?>

<!-- PARTIE AFFICHAGE --------------------------------------------------- -->
<html>
<body>
<head>
    <?php require_once 'header.php';?>
    <title>Add</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="body">
<?php require_once("menu.html");?>
<h1 style="text-align: center">Ajouter un Client</h1>
<div class="well">
    <form class="form-horizontal" enctype="multipart/form-data" role="form" name="addClient" action="add.php" method="POST">

        <div class="form-group">
            <label class="col-md-3 control-label">Nom :</label>
            <div class="col-md-3">
                <input name="nom" type="text" class="form-control" required autofocus/>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Prénom :</label>
            <div class="col-md-3">
                <input name="prenom" type="text" class="form-control" required autofocus/>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Sexe :</label>
            <div class="col-md-3">
                <select name="sexe" size="1" class="form-control form-control-lg">
                    <option value="M"> Homme  </option>
                    <option value="F"> Femme </option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label" >Email :</label>
            <div class="col-md-3">
                <input name="email" type="email" class="form-control"  required autofocus/>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Telephone :</label>
            <div class="col-md-3">
                <input name="telephone" type="text" class="form-control" required autofocus/>
            </div>
        </div>


        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span

                        class="glyphicon glyphicon-ok"></span> Ajouter</button>
                &nbsp;
                <button type="button" class="btn btn-default btn-primary"
                        onclick="javascript: window.location='add.php';"><span
                        class="glyphicon glyphicon-remove"></span> Annuler
                </button>
            </div>
        </div>
    </form>
</div>


<h1 style="text-align: center">Ajouter une destination</h1>
<div class="well">
    <form class="form-horizontal" enctype="multipart/form-data" role="form" name="addDest" action="add.php" method="POST">

        <div class="form-group">
            <label class="col-md-3 control-label">Pays :</label>
            <label class="col-md-3 control-label">
                <select name="idpays" class="form-control" required>
                    <option selected="selected" > Selectionner un pays </option>
                    <?php
                    foreach ($tabPays as $ligne) {
                        $code = $ligne['IDPAYS'];
                        $nomp = $ligne['NOMPAYS'];
                        $continent = $ligne['CONTINENT'];
                        echo "<option value=$code>$nomp - $continent </option>";
                    }
                    ?>
                </select>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Ville :</label>
            <div class="col-md-3">
                <input name="nomdest" type="text" class="form-control" required autofocus/>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Photographie destination :</label>
            <div class="col-md-3">
                <!--<input name="couverture" type="text" class="form-control" required autofocus/>-->
                <input type="file" name="couverture" accept="image/*" class="form-control" required>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Info pratique sur votre destination :</label>
            <div class="col-md-3">
                <input name="commentaire" type="text" class="form-control" required autofocus/>
            </div>
        </div>

        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span

                        class="glyphicon glyphicon-ok"></span> Ajouter</button>
                &nbsp;
                <button type="button" class="btn btn-default btn-primary"
                        onclick="javascript: window.location='add.php';"><span
                        class="glyphicon glyphicon-remove"></span> Annuler
                </button>
            </div>
        </div>
    </form>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }
</style>

</body>
</html>
