<?php
// PARTIE DONNES ---------------------------------------------------------
require_once '../persistance/DialogueBD.php';

$undlg = new DialogueBD();
$mesclients=$undlg->getTousLesClients();
$mesdest=$undlg->getTousLesDest();


if (isset($_POST['personne']) && isset($_POST['lieu']) && isset($_POST['date_deb']) && isset($_POST['date_fin']) && isset($_POST['transport'])) {
    try {
        $undlg = new DialogueBD();

        $nom = $_POST['personne'];
        $lieu = $_POST['lieu'];
        $dateD = $_POST['date_deb'];
        $dateF = $_POST['date_fin'];
        $transp = $_POST['transport'];

        $ajoutOK = $undlg->addResa($lieu,$nom,$dateD,$dateF,$transp);
        header("location: listerReservation.php");

    } catch (Exception $e) {
        $erreur = $e->getMessage();
    }
}
?>

<!-- PARTIE AFFICHAGE --------------------------------------------------- -->
<html>
<body>
<head>
    <?php require_once 'header.php';?>
    <title>Add reservation</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="body">
<?php require_once("menu.html");?>

<br>
<h2 class="container text-center" style="font-family: 'Comic Sans MS'">A court d'idées pour vos prochaines vacances ? Laissez-nous vous inspirer avec nos destinations de rêve et nos offres exclusives !</h2>
<br>

<div id="slideshow">
    <?php
    $destinations = array("lyon.jpg", "miami.jpg", "dubai.jpg","sydney.jpg", "toronto.jpg", "toulouse.jpg","edimbourg.jpg","seville.jpg", "oslo.jpg", "paris.jpg","dublin.jpg", "rome.jpg", "madrid.jpg", "seoul.jpg", "newyork.jpg", "londres.jpg", "hongkong.jpg", "barcelone.jpg", "newyork.jpg", "istanbul.jpg", "vienne.jpg", "berlin.jpg", "rio.jpg", "copenhague.jpg", "sandiego.jpg");
    shuffle($destinations);
    foreach ($destinations as $destination) {
        echo "<div><img src='../lib/img/$destination' /><p>" . ucfirst(pathinfo($destination, PATHINFO_FILENAME)) . "</p></div>";
    }
    ?>
</div>

<h1>Effectuer votre Reservation</h1>
<br>
<div class="well">
    <form class="form-horizontal" enctype="multipart/form-data" role="form" name="addresa" action="addReservation.php" method="POST">

        <div class="form-group">
            <label class="col-md-3 control-label">Qui êtes vous ? </label>
            <label class="col-md-3 control-label">
                <select name="personne" class="form-control" required>
                    <option selected="selected" > Selectionnez un client </option>
                    <?php
                    foreach ($mesclients as $ligne) {
                        $code = $ligne['IDCLIENT'];
                        $nom = $ligne['NOMCLI'];
                        $prenom = $ligne['PRENOMCLI'];
                        $sexe = $ligne['SEXE'];
                        echo "<option value=$code>$nom $prenom - $sexe </option>";
                    }
                    ?>
                </select>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Où souhaitez vous allez ? </label>
            <label class="col-md-3 control-label">
                <select name="lieu" class="form-control" required>
                    <option selected="selected" > Selectionnez une destination </option>
                <?php
                foreach ($mesdest as $ligne) {
                    $id = $ligne['IDDEST'];
                    $dest = $ligne['NOMDEST'];
                    $pays = $ligne['NOMPAYS'];
                    echo "<option value=$id>$pays - $dest </option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label" >Date de départ : </label>
            <div class="col-md-3">
                <input name="date_deb" type="date" id="start" class="form-control" min="2023-01-01" required autofocus/>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label" >Date d'arrivée : </label>
            <div class="col-md-3">
                <input name="date_fin" type="date" id="start" class="form-control" min="2023-01-01" required autofocus/>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Par quel transport ?</label>
            <div class="col-md-3">
                <select name="transport" size="1" class="form-control form-control-lg">
                    <option value="a pied">A pied   (0g CO²/km)</option>
                    <option value="velo">Velo   (0g CO²/km)</option>
                    <option value="train">Train   (14g CO²/km)</option>
                    <option value="bus">Bus   (68g CO²/km)</option>
                    <option value="bateau">Bateau   (139g CO²/km)</option>
                    <option value="avion">Avion   (285g CO²/km)</option>
                </select>
            </div>
        </div>


        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span

                        class="glyphicon glyphicon-ok"></span> Ajouter</button>
                &nbsp;
                <button type="button" class="btn btn-default btn-primary"
                        onclick="javascript: window.location='addReservation.php';"><span
                        class="glyphicon glyphicon-remove"></span> Annuler
                </button>
            </div>
        </div>
    </form>
</div>

<br>
<h2 class="container text-center" style="font-family: 'Comic Sans MS'">Toute nos destinations sont au départ de Paris alors qu'attendez-vous ?</h2>
<br>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>


<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    #slideshow {
        margin: 50px auto;
        position: relative;
        width: 800px;
        height: 600px;
        padding: 10px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.4);
    }
    #slideshow > div {
        position: absolute;
        top: 10px;
        left: 10px;
        right: 10px;
        bottom: 10px;
    }
    #slideshow > div > img {
        width: 100%;
        height: 100%;
    }
    #slideshow > div > p {
        position: absolute;
        bottom: 10px;
        left: 10px;
        font-size: 24px;
        color: white;
        text-shadow: 2px 2px #000000;
    }




    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }
</style>


<script>
    var slideIndex = 0;
    showSlides();

    function showSlides() {
        var i;
        var slides = document.getElementById("slideshow").getElementsByTagName("div");
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) {slideIndex = 1}
        slides[slideIndex-1].style.display = "block";
        setTimeout(showSlides, 2000); // Change image every 2 seconds
    }
</script>

</body>
</html>
