<?php
require_once("menu.html");
require_once("header.php");
?>

<html>
<head>
    <title>Données personnelle</title>
    <h1>Données à caractère personnel</h1>
    <meta charset="UTF-8">
</head>
<body>
<h2><b>Politique de gestion des données de BookMesVacs.fr</b></h2>Les informations recueillies sur le site font l’objet d’un traitement informatique destiné à la gestion des réservations et à l’envoi de newsletters. Les données sont destinées à Bookmesvacs en tant que responsable du traitement et sont conservées pendant 3 ans. Conformément à la loi « Informatique et Libertés » du 6 janvier 1978 modifiée et au Règlement Général sur la Protection des Données (RGPD), vous disposez d’un droit d’accès, de rectification, de suppression et d’opposition aux données vous concernant. Vous pouvez exercer ces droits en nous contactant à l’adresse suivante : contact@bookmesvacs.fr<br><br>
L'organisation « Bookmesvacs » accorde une grande importance à la protection des données à caractère personnel de ses clients. Les données collectées, telles que le nom, l'adresse, l'adresse e-mail et le numéro de téléphone, sont utilisées dans le seul but de faciliter la réservation des vacances et de fournir les services associés. Les données sont stockées de manière sécurisée et sont traitées conformément aux lois en vigueur sur la protection des données.
Il est important de noter que les données à caractère personnel ne sont conservées que pour la durée nécessaire à l'accomplissement des finalités pour lesquelles elles ont été collectées. Dans le cas de « Bookmesvacs », les données sont conservées pendant une période de deux ans à compter de la fin du contrat avec le client.
Au-delà de cette période de conservation, les données à caractère personnel sont supprimées ou anonymisées de manière à ne plus pouvoir être associées à une personne physique identifiable. Cette politique de conservation des données est en accord avec les principes fondamentaux de protection des données à caractère personnel et assure que les données ne sont pas conservées plus longtemps que nécessaire.

<h2><b>Politique de gestion des cookies de BookMesVacs.fr</b></h2>Chez BookMesVacs.fr, nous sommes attachés à la protection de votre vie privée et nous sommes engagés à respecter les réglementations en vigueur en matière de protection des données. Nous utilisons des cookies sur notre site pour améliorer votre expérience de navigation, personnaliser le contenu et les publicités que nous affichons et pour analyser l’utilisation de notre site
<br>
<h3>Qu’est-ce qu’un cookie ?</h3>
Un cookie est un petit fichier texte qui est stocké sur votre ordinateur ou votre appareil mobile lorsque vous visitez un site Web.
<br><br>
<h3>Quels types de cookies utilisons-nous ?</h3>
Nous utilisons des cookies de session qui sont temporaires et qui expirent à la fin de votre session de navigation, ainsi que des cookies persistants qui restent sur votre appareil après la fin de votre session de navigation. Nous utilisons également des cookies tiers, qui sont placés par des partenaires de confiance pour nous aider à analyser l'utilisation de notre site et à fournir des publicités personnalisées.
<br><br>
<h3>Comment gérer les cookies ?</h3>
Si vous souhaitez restreindre ou bloquer les cookies que nous utilisons sur notre site Web, vous pouvez généralement le faire en modifiant les paramètres de votre navigateur. Cependant, veuillez noter que cela peut affecter la fonctionnalité de notre site Web et vous empêcher d'accéder à certaines parties du site.
<br>
En utilisant notre site Web, vous acceptez notre utilisation des cookies conformément à cette politique de gestion des cookies. Si vous avez des questions ou des préoccupations concernant notre politique de gestion des cookies, n'hésitez pas à nous contacter à l'adresse e-mail fournie sur notre site.
<br><br>
En cas de questions ou de préoccupations concernant la protection des données à caractère personnel,vous pouvez contacter le service clientèle de « Bookmesvacs » pour obtenir des informations supplémentaires. Vous avez également la possibilité de cliquez sur le bouton ci-dessous:

<br><br><br><br>
<form action="formulairereclamation.php" method="post" class="text-center">
    <input type="submit" value="Faire une réclamation" class="btn2" />
</form>

<form action="accueil.php" method="post" class="text-center">
    <input type="submit" value="Retour à l'accueil" class="btn" />
</form>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn2 {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #D7432F;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .btn2:hover {
        background-color: #EE6A59;
    }
</style>

</body>
</html>


