<?php
require_once '../persistance/DialogueBD.php';
try {
    $undlg= new DialogueBD();
    $mesclients=$undlg->getTousLesClients();
} catch (Exception $e) {
    $erreur=$e->getMessage();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Formulaire de réclamation</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../lib/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="../lib/css/design.css" rel="stylesheet">
    <script src="../lib/jquery/jquery-2.1.3.min.js"></script>
    <script src="../lib/bootstrap/js/ui-bootstrap-tpls.js" type="text/javascript"></script>
    <script src="../lib/bootstrap/js/bootstrap.js"></script>
</head>
<body>
<?php
require_once("menu.html");
require_once 'header.php';
?>
<h1>Formulaire de réclamation</h1>
<div class="well">
    <form class="form-horizontal" enctype="multipart/form-data" role="form" name="reclamation" action="formulairereponse.php" method="POST">

    <div class="form-group">
        <label class="col-md-3 control-label">Qui êtes vous ? </label>
        <label class="col-md-3 control-label">
            <select name="personne" class="form-control" required>
                <option selected="selected" > Selectionnez un client </option>
                <?php
                foreach ($mesclients as $ligne) {
                    $code = $ligne['IDCLIENT'];
                    $nom = $ligne['NOMCLI'];
                    $prenom = $ligne['PRENOMCLI'];
                    $sexe = $ligne['SEXE'];
                    echo "<option value=$code>$nom $prenom - $sexe </option>";
                }
                ?>
            </select>
    </div>

    <div class="form-group">
        <label class="col-md-3 control-label" for="type_reclamation">Type de réclamation :</label>
        <div class="col-md-3">
            <input type="radio" id="reclamation_produit" name="type_reclamation" value="Problème de réservation">
            <label for="reclamation_produit">Problème de réservation</label><br>
            <input type="radio" id="reclamation_livraison" name="type_reclamation" value="Remboursement non effectué">
            <label for="reclamation_livraison">Remboursement non effectué</label><br>
            <input type="radio" id="reclamation_service" name="type_reclamation" value="Mauvais service client">
            <label for="reclamation_service">Mauvais service client</label><br>
            <input type="radio" id="reclamation_autre" name="type_reclamation" value="Autre">
            <label for="reclamation_autre">Autre</label><br>
        </div>
    </div>

    <div class="form-group">
        <label class="col-md-3 control-label">Commentaire (facultatif) :</label>
        <div class="col-md-3">
            <input name="commentaire" type="text" class="form-control"  autofocus/>
        </div>
    </div>

    <div class="form-group">
        <label class="col-md-3 control-label" for="acceptation_conditions">J'accepte les conditions générales d'utilisation :</label>
        <div class="col-md-3">
            <input type="checkbox" id="acceptation_conditions" name="acceptation_conditions" required><br>
        </div>
    </div>

        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span

                            class="glyphicon glyphicon-ok"></span> Envoyer</button>
                &nbsp;
                <button type="button" class="btn btn-default btn-primary"
                        onclick="javascript: window.location='accueil.php';"><span
                            class="glyphicon glyphicon-remove"></span> Retour
                </button>
            </div>
        </div>
    </form>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }
</style>
</body>
</html>
