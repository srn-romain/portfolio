<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Formulaire réponse</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../lib/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="../lib/css/design.css" rel="stylesheet">
    <script src="../lib/jquery/jquery-2.1.3.min.js"></script>
    <script src="../lib/bootstrap/js/ui-bootstrap-tpls.js" type="text/javascript"></script>
    <script src="../lib/bootstrap/js/bootstrap.js"></script>
</head>
<body>

<h1>Votre formulaire a bien été enregistré par nos services</h1><br>
<div class="well">
<?php
require_once("menu.html");
require_once 'header.php';

echo "Nous nous engageons à vous répondre dans les meilleurs délais. Si la réponse apportée ne vous satisfait pas, vous pouvez saisir le Médiateur du Tourisme et du Voyage à l'adresse suivante : MTV Médiation Tourisme Voyage BP 80 303 75 823 Paris Cedex 17.";
// Récupération des données saisies dans le formulaire
$personne = $_POST['personne'];
$type_reclamation = $_POST['type_reclamation'];
$commentaire = $_POST['commentaire'];

echo "<br><br>";
echo "Votre numéro client est le $personne. ";
echo "<br><br>";
echo "Votre motif de contact : $type_reclamation.";
echo "<br><br>";

if(isset($_POST['commentaire']) && !empty($_POST['commentaire'])){
    echo "Votre commentaire : $commentaire";
}

?>
<br><br>
    <form action="accueil.php" method="post" class="text-center">
        <input type="submit" value="Retour à l'accueil" class="btn" />
    </form>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }
</style>
</body>
</html>

