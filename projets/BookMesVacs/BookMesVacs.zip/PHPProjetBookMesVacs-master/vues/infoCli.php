<?php
// PARTIE DONNES ---------------------------------------------------------
require_once '../persistance/DialogueBD.php';

require_once 'header.php';
require_once("menu.html");

try {
    // on crée un objet référant la classe DialogueBD
    $undlg = new DialogueBD();
    $code= $_POST['client'];
    $unClient = $undlg->getUnClient($code);

} catch (Exception $e) {
    $erreur = $e->getMessage();
}
?>
<!-- PARTIE AFFICHAGE --------------------------------------------------- -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>info client</title>
</head>
<body>
<?php
if (isset($msgErreur)) {
    echo "Erreur : $msgErreur";
}
?>
<h1>Renseignements du client numéro <?php echo $unClient->IDCLIENT; ?></h1>
<div class="well"  style="font-size: 35px;">
    <ul>
        <?php
        echo "<li>ID : " . $unClient->IDCLIENT . "</li>";
        echo "<li>Nom : " . $unClient->NOMCLI . "</li>";
        echo "<li>Prenom : " . $unClient->PRENOMCLI . "</li>";
        echo "<li>Sexe : " . $unClient->SEXE . "</li>";
        echo "<li>Email : " . $unClient->EMAIL . "</li>";
        echo "<li>Téléphone : " . $unClient->TELEPHONE . "</li>";
        ?>
    </ul>
</div>

<div class="form-group">
    <div class="text-center">
        &nbsp;
        <button type="button" class="btn btn-default btn-primary"
                onclick="javascript: window.location='trie2.php';"><span
                    class="glyphicon glyphicon glyphicon-ban-circle"></span> Retour
        </button>
    </div>
</div>


<div id="slideshow">
    <?php
    $ads = [
        [
            'image' => 'vetement.jpg',
            'title' => 'Découvrez notre nouvelle collection de vêtements',
            'description' => 'Profitez de nos prix exclusifs pour renouveler votre garde-robe'
        ],
        [
            'image' => 'vetement2.jpg',
            'title' => 'Offre spéciale : -50% sur tous les produits',
            'description' => 'Ne manquez pas cette occasion de faire des économies sur vos achats en ligne'
        ],
        [
            'image' => 'vetement3.jpg',
            'title' => 'Inscrivez-vous dès maintenant à notre programme fidélité',
            'description' => 'Bénéficiez de nombreux avantages exclusifs en devenant membre de notre communauté'
        ]
    ];

    shuffle($ads);

    foreach ($ads as $ad) {
        echo '<div class="slide">';
        echo '<img src="../lib/img/' . $ad['image'] . '"/>';
        echo '<h2>' . $ad['title'] . '</h2>';
        echo '<p>' . $ad['description'] . '</p>';
        echo '</div>';
    }
    ?>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>


<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }





    form {
        text-align: center;
    }

    form .btn {
        display: inline-block;
    }

    #slideshow {
        position: relative;
        width: 800px;
        height: 600px;
        margin: 50px auto;
    }

    .slide {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: none;
        text-align: center;
        padding: 50px;
        background-color: #fff;
    }

    .slide img {
        max-width: 1500px;
        max-height: 900px;
        margin-bottom: 20px;
    }

    .slide h2 {
        font-size: 36px;
        margin-bottom: 20px;
    }

    .slide p {
        font-size: 24px;
        line-height: 1.5;
    }
</style>

<script>
    var slideIndex = 0;
    showSlides();

    function showSlides() {
        var i;
        var slides = document.getElementsByClassName("slide");
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) {
            slideIndex = 1
        }
        slides[slideIndex - 1].style.display = "block";
        setTimeout(showSlides, 3000); // Change image every 3 seconds
    }
</script>

</body>
</html>