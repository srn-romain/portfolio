<?php
// PARTIE DONNES ---------------------------------------------------------
require_once '../persistance/DialogueBD.php';

require_once 'header.php';
require_once("menu.html");

try {
    // on crée un objet référant la classe DialogueBD
    $undlg = new DialogueBD();
    $heber= $_POST['hebergement'];
    $unHeber = $undlg->getUnHeber($heber);
    $id= $unHeber->IDHEBER;
    $nom = $unHeber->NOMHEBER;
    $localisation = $unHeber->NOMDEST;
    $pays = $unHeber->NOMPAYS;
    $type = $unHeber->TYPEHEBER;
    $nbetoile = $unHeber->NBETOILE;

} catch (Exception $e) {
    $erreur = $e->getMessage();
}
?>
<!-- PARTIE AFFICHAGE --------------------------------------------------- -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>info heber</title>
</head>
<body>
<?php
if (isset($msgErreur)) {
    echo "Erreur : $msgErreur";
}
?>
<h1>Renseignements de l'hébergement numéro <?php echo $unHeber->IDHEBER; ?></h1>
<div class="well" style="font-size: 35px;">
    <ul>
        <?php
        echo "<li>Identifiant hébergement : " . $id . "</li>";
        echo "<li>Nom : " . $nom . "</li>";
        echo "<li>Localisation : " . $localisation . "</li>";
        echo "<li>Pays : " . $pays . "</li>";
        echo "<li>Type : " . $type . "</li>";
        echo "<li>Nombre d'étoile : " . $nbetoile . "</li>";
        ?>
    </ul>
</div>

<div class="form-group">
    <div class="text-center">
        &nbsp;
        <button type="button" class="btn btn-default btn-primary"
                onclick="javascript: window.location='trie2.php';"><span
                class="glyphicon glyphicon glyphicon-ban-circle"></span> Retour
        </button>
    </div>
</div>

<div id="slideshow">
    <?php
    $ads = [
        [
            'image' => 'pub4.jpg',
            'title' => 'Le café qui vous transporte',
            'description' => ' Découvrez notre café aux arômes exotiques qui vous fera voyager.'
        ],
        [
            'image' => 'pub5.jpg',
            'title' => 'Le secret de la jeunesse éternelle ',
            'description' => 'Découvrez notre nouvelle crème anti-âge révolutionnaire qui efface les rides de votre peau'
        ],
        [
            'image' => 'pub6.jpg',
            'title' => 'Le goût de l’aventure',
            'description' => 'Partez à l’aventure avec notre sélection de produits outdoor de qualité, pour des expériences inoubliables en pleine nature.'
        ]
    ];

    shuffle($ads);

    foreach ($ads as $ad) {
        echo '<div class="slide">';
        echo '<img src="../lib/img/' . $ad['image'] . '"/>';
        echo '<h2>' . $ad['title'] . '</h2>';
        echo '<p>' . $ad['description'] . '</p>';
        echo '</div>';
    }
    ?>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<script>
    var slideIndex = 0;
    showSlides();

    function showSlides() {
        var i;
        var slides = document.getElementsByClassName("slide");
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) {
            slideIndex = 1
        }
        slides[slideIndex - 1].style.display = "block";
        setTimeout(showSlides, 5000); // Change image every 3 seconds
    }
</script>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }







    form {
        text-align: center;
    }

    form .btn {
        display: inline-block;
    }

    #slideshow {
        position: relative;
        width: 800px;
        height: 600px;
        margin: 50px auto;
    }

    .slide {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: none;
        text-align: center;
        padding: 50px;
        background-color: #fff;
    }

    .slide img {
        max-width: 600px;
        max-height: 300px;
        margin-bottom: 20px;
    }

    .slide h2 {
        font-size: 36px;
        margin-bottom: 20px;
    }

    .slide p {
        font-size: 24px;
        line-height: 1.5;
    }
</style>
</body>
</html>