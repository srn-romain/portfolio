<!DOCTYPE html>
<html>
<?php
require_once '../persistance/DialogueBD.php';
try {
    $undlg= new DialogueBD();
    $mesclients=$undlg->getTousLesClients();
} catch (Exception $e) {
    $erreur=$e->getMessage();
}
?>
<head>
    <?php require_once 'header.php';?>
    <title>Liste Client</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<?php
require_once("menu.html");
?>
<div class="container">
    <h1>Liste de nos Clients</h1>
    <br><br>
    <form action="add.php" method="post" class="text-center">
        <input type="submit" value="Ajouter un client" class="btn" />
    </form>
    <br><br>
    <table class="table table-bordered table-striped">
        <thead>
        <tr>
            <th>IdClient</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Sexe</th>
            <th>Email</th>
            <th>Telephone</th>
            <th>Modifier</th>
            <th>Supprimer</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $lignes="";
        $nb=0;
        foreach ($mesclients as $client)
        { // On parcourt la collection
            $lignes .= "<tr>\n"; // On construit une ligne <tr>
            $lignes .= "<td> $client[IDCLIENT]</td>\n"; // On construit un <td>
            $nb ++;
            $lignes .= "<td> $client[NOMCLI]</td>\n";
            $lignes .= "<td> $client[PRENOMCLI]</td>\n";
            $lignes .= "<td> $client[SEXE]</td>\n";
            $lignes .= "<td> $client[EMAIL]</td>\n";
            $lignes .= "<td> $client[TELEPHONE]</td>\n";
            $lignes .= "<td style='text-align: center'> <a href='modifierclient.php?code=$client[IDCLIENT]'><span class='glyphicon glyphicon-pencil' style='font-size: 2em; color: #348310'></span></a></td>\n";
            $lignes .= "<td style='text-align: center'> <a href='Supprimer.php?code2=$client[IDCLIENT]'><span class='glyphicon glyphicon-trash' style='font-size: 2em; color: #348310'></span></a></td>\n";
            $lignes .= "</tr>\n";
        }
        echo utf8_encode($lignes); // On affiche tous les <tr>
        ?>
        </tbody>
    </table>
</div>
<p class="text-center"><b><?php echo "Total : $nb clients"; ?></b></p>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

</style>

</body>
</html>