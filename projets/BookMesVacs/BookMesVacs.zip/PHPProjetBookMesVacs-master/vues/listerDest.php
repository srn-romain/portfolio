<!DOCTYPE html>
<html>
<?php
require_once '../persistance/DialogueBD.php';
try {
    $undlg= new DialogueBD();
    $mesdestinations=$undlg->getTousLesDest();
} catch (Exception $e) {
    $erreur=$e->getMessage();
}
?>
<head>
    <?php require_once 'header.php';?>
    <title>Liste Destination</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<?php
require_once("menu.html");
?>
<div class="container">
    <h1>Nos plus belles destinations</h1>
    <br><br>
    <form action="add.php" method="post" class="text-center">
        <input type="submit" value="Ajouter une Destination" class="btn" />
    </form>
    <br><br>
    <table class="table table-bordered table-striped">
        <thead>
        <tr>
            <th>IdDestination</th>
            <th>Nom</th>
            <th>Pays</th>
            <th>Photo</th>
            <th>Info pratique</th>
            <th>Modifier</th>
            <th>Supprimer</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $lignes="";
        $nb=0;
        foreach ($mesdestinations as $destination)
        { // On parcourt la collection
            $lignes .= "<tr>\n"; // On construit une ligne <tr>
            $lignes .= "<td> $destination[IDDEST]</td>\n"; // On construit un <td>
            $nb ++;
            $lignes .= "<td> $destination[NOMDEST]</td>\n";
            $lignes .= "<td> $destination[NOMPAYS]</td>\n";
            $lignes .= "<td> <img src='../lib/img/$destination[IMG_DEST]' width='400' height='200'></td>\n";
            $lignes .= "<td> $destination[INFODEST]</td>\n";
            $lignes .= "<td style='text-align: center'> <a href='modifierdest.php?codee=$destination[IDDEST]'><span class='glyphicon glyphicon-pencil' style='font-size: 2em; color: #348310'></span></a></td>\n";
            $lignes .= "<td style='text-align:center;'> <a href='Supprimer.php?code=$destination[IDDEST]'><span class='glyphicon glyphicon-trash' style='font-size: 2em; color: #348310'></span></a></td>\n";
            $lignes .= "</tr>\n";
        }
        echo utf8_encode($lignes); // On affiche tous les <tr>
        ?>
        </tbody>
    </table>
</div>

<p class="text-center"><b><?php echo "Total : $nb destinations"; ?></b></p>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

</style>

</body>
</html>