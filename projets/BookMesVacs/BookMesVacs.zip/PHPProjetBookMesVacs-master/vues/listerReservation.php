<!DOCTYPE html>
<html>
<?php
require_once '../persistance/DialogueBD.php';
try {
    $undlg= new DialogueBD();
    $mesresa=$undlg->getTousLesResas();
} catch (Exception $e) {
    $erreur=$e->getMessage();
}
?>
<head>
    <?php require_once 'header.php';?>
    <title>Liste Client</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<?php
require_once("menu.html");
?>
<div class="container">
    <h1>Liste de nos Reservations</h1>
    <br><br>
    <form action="addReservation.php" method="post" class="text-center">
        <input type="submit" value="Ajouter une Réservation" class="btn" />
    </form>
    <br><br>
    <table class="table table-bordered table-striped">
        <thead>
        <tr>
            <th>ID Client</th>
            <th>Nom Client</th>
            <th>Prenom Client</th>
            <th>Destination</th>
            <th>Pays</th>
            <th>Photo</th>
            <th>Début Séjour</th>
            <th>Fin Séjour</th>
            <th>Moyen de transport</th>
            <th>Modifier</th>
            <th>Supprimer</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $lignes="";
        $nb=0;
        foreach ($mesresa as $client)
        { // On parcourt la collection
            $lignes .= "<tr>\n"; // On construit une ligne <tr>
            $lignes .= "<td> $client[IDCLIENT]</td>\n";
            $nb ++;
            $lignes .= "<td> $client[NOMCLI]</td>\n"; // On construit un <td>
            $lignes .= "<td> $client[PRENOMCLI]</td>\n";
            $lignes .= "<td> $client[NOMDEST]</td>\n";
            $lignes .= "<td> $client[NOMPAYS]</td>\n";
            $lignes .= "<td> <img src='../lib/img/$client[IMG_DEST]' width='257' height='165'></td>\n";
            $lignes .= "<td> $client[DATE_DEB]</td>\n";
            $lignes .= "<td> $client[DATE_FIN]</td>\n";
            $lignes .= "<td> $client[MOYEN_TRANSPORT]</td>\n";
            $lignes .= "<td style='text-align: center'> <a href='modifierresa.php?destmodif=$client[IDDEST]&clientmodif=$client[IDCLIENT]'><span class='glyphicon glyphicon-pencil' style='font-size: 2em; color: #348310'></span></a></td>\n";
            $lignes .= "<td style='text-align: center'> <a href='Supprimer.php?id=$client[IDDEST]&client=$client[IDCLIENT]'><span class='glyphicon glyphicon-trash' style='font-size: 2em; color: #348310'></span></a></td>\n";
            $lignes .= "</tr>\n";
        }
        echo utf8_encode($lignes); // On affiche tous les <tr>
        ?>
        </tbody>
    </table>
</div>

<p class="text-center"><b><?php echo "Total : $nb réservations"; ?></b></p>

<br>
<h2 class="container text-center" style="font-family: 'Comic Sans MS'">Chez nous, la préservation de l'environnement est primordiale, c'est pourquoi nous encourageons les transports peu polluant pour vos voyages. Profitez de vos vacances tout en réduisant votre impact sur la planète !</h2>
<br>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

</style>

</body>
</html>