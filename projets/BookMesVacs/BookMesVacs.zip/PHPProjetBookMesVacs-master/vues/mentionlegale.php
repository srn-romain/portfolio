<?php
require_once("menu.html");
require_once("header.php");
?>

<html>
<head>
    <title>Mentions Légales</title>
    <h1>Mentions légales</h1>
    <meta charset="UTF-8">
</head>
<body>
<h2>Mentions</h2>Le présent site web est édité par Bookmesvacs.fr, société par actions simplifiée au capital de 150 000 euros, immatriculée au registre du commerce et des sociétés de Paris <br>
<h2>Responsabilité</h2>Nom et prénom du responsable de la publication : Jean Dupont (responsable agence Paris)<br>
<h2>Propriétés</h2>Tous les éléments présents sur le site (textes, images, logos, vidéos, etc.) sont la propriété exclusive de Voyages Aventure ou de ses partenaires et sont protégés par les lois françaises et internationales relatives à la propriété intellectuelle. Toute reproduction, représentation, modification, publication, transmission ou adaptation de ces éléments, en tout ou partie, est strictement interdite sans l’autorisation préalable écrite de bookmesvacs ou de ses partenaires<br>
<h2>Liens vers des sites tiers</h2>Le site peut contenir des liens vers des sites web de tiers. Ces liens sont fournis uniquement pour votre commodité et ne constituent en aucun cas une approbation ou une recommandation de ces sites. Nous n'avons aucun contrôle sur ces sites et déclinons toute responsabilité quant à leur contenu ou leur utilisation.<br>
<h2>Limitation de responsabilité</h2>L'utilisation du site se fait sous votre seule responsabilité. Nous ne pouvons garantir l'exactitude, la qualité, l'exhaustivité ou la pertinence des informations présentées sur le site. Nous ne saurions être tenus responsables en cas de dommages directs ou indirects résultant de l'utilisation ou de l'impossibilité d'utilisation du site ou de son contenu.<br>
<h2>Droit applicable et juridiction compétente</h2>Les présentes mentions légales sont régies par le droit français. Tout litige relatif à l'utilisation du site ou à son contenu sera soumis à la compétence exclusive des tribunaux français.<br>
<h2>Modification des mentions légales</h2>Nous nous réservons le droit de modifier les présentes mentions légales à tout moment et sans préavis. Il est de votre responsabilité de consulter régulièrement la page "Mentions légales" du site afin de prendre connaissance des éventuelles modifications.<br>
<h2>Coordonnées de l'agence</h2>Nom de l'agence : Bookmesvacs : 10 rue de la Liberté, 75001 Paris Téléphone : +33 (0)1 23 45 67 89 E-mail : contact@bookmesvacs.fr<br>
<h2>Crédits photos</h2>Les photos utilisées sur le site sont la propriété de Bookmesvacs ou de ses partenaires et sont utilisées avec leur autorisation. Toute reproduction, représentation ou utilisation des photos sans autorisation est strictement interdite.<br>
<h2>Conditions générales de vente</h2>Les conditions générales de vente sont disponibles sur une page dédiée du site et sont accessibles via un lien présent sur toutes les pages du site.<br>
<h2>Informations sur les voyages</h2>Les informations sur les voyages proposés par Bookmesvacs sont fournies à titre indicatif et sont susceptibles de changer sans préavis. Les prix indiqués sur le site sont des prix TTC et incluent toutes les taxes et charges applicables. Les offres de voyages sont soumises à disponibilité et peuvent être soumises à des conditions particulières. Nous vous invitons à nous contacter pour obtenir des informations plus détaillées sur les voyages proposés.<br>
<h2>Réclamation</h2>Si vous avez une réclamation à formuler, nous vous invitons à nous contacter par e-mail à l'adresse suivante : "contact@bookmesvacs.fr" ou à cliquer sur le bouton "Faire une réclamation" situé ci-dessous. Nous nous engageons à vous répondre dans les meilleurs délais. Si la réponse apportée ne vous satisfait pas, vous pouvez saisir le Médiateur du Tourisme et du Voyage à l'adresse suivante : MTV Médiation Tourisme Voyage BP 80 303 75 823 Paris Cedex 17.<br>
<br><br>


<form action="formulairereclamation.php" method="post" class="text-center">
    <input type="submit" value="Faire une réclamation" class="btn2" />
</form>

<form action="accueil.php" method="post" class="text-center">
    <input type="submit" value="Retour à l'accueil" class="btn" />
</form>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }

    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn2 {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #D7432F;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .btn2:hover {
        background-color: #EE6A59;
    }
</style>

</body>
</html>

