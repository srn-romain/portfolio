<?php
// PARTIE DONNES ---------------------------------------------------------
require_once '../persistance/DialogueBD.php';

try {
    $undlg = new DialogueBD();

    if (isset($_POST['dateD']) && isset($_POST['dateF']) && isset($_POST['transp']) && isset($_POST['code'])) {
        $dateD = $_POST['dateD'];
        $dateF = $_POST['dateF'];
        $transp = $_POST['transp'];
        $code = $_POST['code'];
        $Detailresa = explode(",", $code);
        $DESTINATION= $Detailresa[0]; // ModifIer get
        $CLIENT= $Detailresa[1]; // Modifier get
        echo'test';

        $ajoutOK = $undlg->modifuneResa($dateD, $dateF, $transp, $DESTINATION,$CLIENT);
        if($ajoutOK){
            header("location: listerReservation.php");
        }else
        {
            $prb = true;
        }
    }else {
        // Premier affichage
        $iddest = $_GET['destmodif'];
        $idclient = $_GET['clientmodif'];
        // Récupérer les valeurs dans la table avec $_POST['code']
        $UneResa= $undlg->getUneResa($iddest,$idclient);
        $dateD = $UneResa->DATE_DEB;
        $dateF = $UneResa->DATE_FIN;
        $transp = $UneResa->MOYEN_TRANSPORT;
    }
} catch (Exception $e) {
    $erreur = $e->getMessage();
}
?>
<!-- PARTIE AFFICHAGE --------------------------------------------------- -->
<html>
<head>
    <?php require_once 'header.php';?>
    <title>Modif resa</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="body">
<?php require_once("menu.html");?>

<h1 style="text-align: center">Modifier une réservation</h1>
<div class="well">
    <form class="form-horizontal" enctype="multipart/form-data" role="form" name="modifResa" action="modifierResa.php" method="POST">

        <div class="form-group">
            <div class="col-md-3">
                <?php
                echo "<input name='code' type='hidden' class='form-control' value='$iddest,$idclient' required autofocus/>";
                ?>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Date Départ :</label>
            <div class="col-md-3">
                <?php
                echo "<input name='dateD' type='date' class='form-control' value='$dateD' required autofocus/>";
                ?>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Date Retour :</label>
            <div class="col-md-3">
                <?php
                echo "<input name='dateF' type='date' class='form-control' value='$dateF' required autofocus/>";
                ?>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Moyen de transport :</label>
            <div class="col-md-3">
                <select name="transp" size="1" class="form-control form-control-lg">
                    <option value="a pied" <?php if ($transp == "a pied"){echo 'selected';} ?> > A pied (0g CO²/km)  </option>
                    <option value="velo" <?php if ($transp == "velo"){echo 'selected';} ?>  > En velo (0g CO²/km)</option>
                    <option value="train" <?php if ($transp == "train"){echo 'selected';} ?>  > En train (14g CO²/km)</option>
                    <option value="bus" <?php if ($transp == "bus"){echo 'selected';} ?>  > En bus (68g CO²/km)</option>
                    <option value="bateau" <?php if ($transp == "bateau"){echo 'selected';} ?>  > En bateau (139g CO²/km)</option>
                    <option value="avion" <?php if ($transp == "avion"){echo 'selected';} ?>  > En avion (285g CO²/km)</option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
                <button type="submit" class="btn btn-default btn-primary"><span

                        class="glyphicon glyphicon-ok"></span> Modifier</button>
                &nbsp;
                <button type="button" class="btn btn-default btn-primary"
                        onclick="javascript: window.location='listerReservation.php';"><span
                        class="glyphicon glyphicon-remove"></span> Retour
                </button>
            </div>
        </div>
    </form>
    <?php
    if(isset($prb)){
        echo "<div class='alert alert-danger' role='alert'>La réservation n'a pas pu être modifiée, vérifier vos informations </div>";
    }
    ?>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }


    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }
</style>

</body>
</html>