<?php
// PARTIE DONNES ---------------------------------------------------------
require_once '../persistance/DialogueBD.php';

try {
    $undlg = new DialogueBD();

    if (isset($_POST['code']) && isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['sexe']) && isset($_POST['email']) && isset($_POST['tel'])) {
       // MODIFICATION APRES SUBMIT
        $code = $_POST['code'];
        $nom= $_POST['nom'];
        $prenom = $_POST['prenom'];
        $sexe = $_POST['sexe'];
        $email = $_POST['email'];
        $tel = $_POST['tel'];
        $ajoutOK = $undlg->modifunClient($code, $nom, $prenom, $sexe, $email, $tel);
        if($ajoutOK){
          header("location: listerClient.php");
        }else
        {
            $prb = true;
        }
    } else {
        // Premier affichage
        $code = $_GET['code'];
        // Récupérer les valeurs dans la table avec $_POST['code']
        $UnClient= $undlg->getUnClient($code);
        $nom= $UnClient->NOMCLI;
        $prenom = $UnClient->PRENOMCLI;
        $sexe = $UnClient->SEXE;
        $email = $UnClient->EMAIL;
        $tel = $UnClient->TELEPHONE;
    }
} catch (Exception $e) {
    $erreur = $e->getMessage();
}
?>
<!-- PARTIE AFFICHAGE --------------------------------------------------- -->
<html>
<head>
    <?php require_once 'header.php';?>
    <title>Modif client</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="body">
<?php require_once("menu.html");?>

<h1>Modifier un Client</h1>
<div class="well">
    <form class="form-horizontal" enctype="multipart/form-data" role="form" name="modifCli" action="modifierclient.php" method="POST">

        <div class="form-group">
            <div class="col-md-3">
                <?php
                    echo "<input name='code' type='hidden' class='form-control' value='$code' required autofocus/>";
                ?>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Nom Client :</label>
            <div class="col-md-3">
                <?php
                    echo "<input name='nom' type='text' class='form-control' value='$nom' required autofocus/>";
                ?>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Prénom Client :</label>
            <div class="col-md-3">
                <?php
                    echo "<input name='prenom' type='text' class='form-control' value='$prenom' required autofocus/>";
                ?>
            </div>
        </div>
        <!--
        <div class="form-group">
            <label class="col-md-3 control-label">Sexe :</label>
            <div class="col-md-3">
                <?php
                    echo "<input name='sexe' type='text' class='form-control' value='$sexe' required autofocus/>";
                ?>
            </div>
        </div>-->

        <div class="form-group">
            <label class="col-md-3 control-label" >Sexe : </label>
            <div class="col-md-3">
                <select name="sexe" size="1" class="form-control form-control-lg">
                    <option value="M" <?php if ($sexe == "M"){echo 'selected';} ?> > Homme  </option>
                    <option value="F" <?php if ($sexe == "F"){echo 'selected';} ?>  > Femme </option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Email :</label>
            <div class="col-md-3">
                <?php
                    echo "<input name='email' type='text' class='form-control' value='$email' required autofocus/>";
                ?>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Téléphone :</label>
            <div class="col-md-3">
                <?php
                    echo "<input name='tel' type='text' class='form-control' value='$tel' required autofocus/>";
                ?>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
                <button type="submit" class="btn btn-default btn-primary"><span

                        class="glyphicon glyphicon-ok"></span> Modifier</button>
                &nbsp;
                <button type="button" class="btn btn-default btn-primary"
                        onclick="javascript: window.location='listerClient.php';"><span
                        class="glyphicon glyphicon-remove"></span> Retour
                </button>
            </div>
        </div>
    </form>
    <?php
    if(isset($prb)){
        echo "<div class='alert alert-danger' role='alert'>Le Client n'a pas pu être modifié, vérifier vos informations </div>";
    }
    ?>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }


    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }
</style>

</body>
</html>