<?php
// PARTIE DONNES ---------------------------------------------------------
require_once '../persistance/DialogueBD.php';

try {
    $undlg = new DialogueBD();

    if (isset($_POST['code']) && isset($_POST['ville']) && isset($_FILES["couverture"]) && isset($_POST['commentaire'])) {



        $id = $_POST['code'];

        $ville = $_POST['ville'];

        $image = basename($_FILES['couverture']['name']);
        $tmpname = $_FILES['couverture']['tmp_name'];
        $ok = move_uploaded_file($tmpname, "../lib/img/". $image);
        if ($ok)
        {
            $couverture = $image;
        } else {
            $couverture = "NOPE";
        }

        $commentaire = $_POST['commentaire'];
        $ajoutOK = $undlg->modifuneDest($ville, $couverture, $commentaire, $id);
        if($ajoutOK){
            header("location: listerDest.php");
        }else
        {
            $prb = true;
        }
    }else {
        // Premier affichage
        $code = $_GET['codee'];
        // Récupérer les valeurs dans la table avec $_POST['code']
        $UnClient= $undlg->getUneDest($code);
        $ville = $UnClient->NOMDEST;
        $info = $UnClient->INFODEST;
    }
} catch (Exception $e) {
    $erreur = $e->getMessage();
}
?>
<!-- PARTIE AFFICHAGE --------------------------------------------------- -->
<html>
<head>
    <?php require_once 'header.php';?>
    <title>Modif dest</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="body">
<?php require_once("menu.html");?>

<h1 style="text-align: center">Modifier une destination</h1>
<div class="well">
    <form class="form-horizontal" enctype="multipart/form-data" role="form" name="modifDest" action="modifierdest.php" method="POST">

        <div class="form-group">
            <div class="col-md-3">
                <?php
                echo "<input name='code' type='hidden' class='form-control' value='$code' required autofocus/>";
                ?>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Ville :</label>
            <div class="col-md-3">
                <?php
                echo "<input name='ville' type='text' class='form-control' value='$ville' required autofocus/>";
                ?>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Photographie destination :</label>
            <div class="col-md-3">
                <input type="file" name="couverture" accept="image/*" class="form-control" required >
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-3 control-label">Info pratique sur votre destination :</label>
            <div class="col-md-3">
                <textarea name='commentaire' rows='3' class='form-control' required autofocus><?php echo $info; ?></textarea>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
                <button type="submit" class="btn btn-default btn-primary"><span

                            class="glyphicon glyphicon-ok"></span> Modifier</button>
                &nbsp;
                <button type="button" class="btn btn-default btn-primary"
                        onclick="javascript: window.location='listerDest.php';"><span
                            class="glyphicon glyphicon-remove"></span> Retour
                </button>
            </div>
        </div>
    </form>
    <?php
    if(isset($prb)){
        echo "<div class='alert alert-danger' role='alert'>La destination n'a pas pu être modifiée, vérifier vos informations </div>";
    }
    ?>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }


    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }
</style>

</body>
</html>