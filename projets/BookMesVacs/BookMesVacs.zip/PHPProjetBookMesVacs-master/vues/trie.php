<?php
// PARTIE DONNES ---------------------------------------------------------
// inclusion de la méthode de dialogue avec la BD
require_once '../persistance/DialogueBD.php';
require_once 'menu.html';

try {
    $undlg = new DialogueBD();

    //$codeService = $_POST['service'];
    $mesTypes = $undlg-> getTousLesTypes();
    $mesPays = $undlg-> getTousLesPays();
    $mesConti = $undlg-> getTousLesContinents();
    $mesDests = $undlg-> getTousLesDest();
} catch (Exception $e) {
    $erreur = $e->getMessage();
}
?>
<!-- PARTIE AFFICHAGE --------------------------------------------------- -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <link rel="stylesheet" />
    <title>Selection du Type</title>
    <?php require_once("header.php"); ?>
</head>
<body>
<h1>Liste de nos hébergements par type</h1>
<div class="well">
    <form class="formulaire" action="HeberParType.php" method="post">
        <ul>
            <label for="champType"> </label>
            <select name="type" id="champType" class="form-control form-control-lg">
                <option selected="selected" > Selectionnez un type d'hébergement</option>
                <?php
                foreach ($mesTypes as $ligne) {
                    $idType = $ligne['IDTYPEHEBER'];
                    $type = $ligne['TYPEHEBER'];
                    echo "<option value=$idType>$type</option>";
                }
                ?>
            </select>
        </ul>
        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span class="glyphicon glyphicon-ok"></span>Valider</button>
                <button type="button" class="btn btn-default btn-primary" onclick="javascript: window.location='trie.php';"><span class="glyphicon glyphicon-remove"></span> Annuler</button>
            </div>
        </div>
    </form>
</div>

<br><br>

<h1>Liste de nos destinations par pays</h1>
<div class="well">
    <form class="formulaire" action="DestParPays.php" method="post">
        <ul>
            <label for="champPays"> </label>
            <select name="pays" id="champPays" class="form-control form-control-lg">
                <option selected="selected" > Selectionnez un pays </option>
                <?php
                foreach ($mesPays as $ligne) {
                    $code = $ligne['IDPAYS'];
                    $pays = $ligne['NOMPAYS'];
                    $cont = $ligne['CONTINENT'];
                    echo "<option value=$code>$pays - $cont</option>";
                }
                ?>
            </select>
        </ul>
        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span class="glyphicon glyphicon-ok"></span>Valider</button>

                <button type="button" class="btn btn-default btn-primary" onclick="javascript: window.location='trie.php';"><span class="glyphicon glyphicon-remove"></span> Annuler</button>
            </div>
        </div>
    </form>
</div>

<br><br>

<h1>Liste de nos réservations par client</h1>
<div class="well">
    <form class="formulaire" action="clientParDest.php" method="post">
        <ul>
            <label for="champdest"> </label>
            <select name="clientdest" id="champclient" class="form-control form-control-lg">
                <option selected="selected" > Selectionnez une destination </option>
                <?php
                foreach ($mesDests as $ligne) {
                    $code = $ligne['IDDEST'];
                    $dest = $ligne['NOMDEST'];
                    $pays = $ligne['NOMPAYS'];
                    echo "<option value=$code>$pays - $dest</option>";
                }
                ?>
            </select>
        </ul>
        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span class="glyphicon glyphicon-ok"></span>Valider</button>

                <button type="button" class="btn btn-default btn-primary" onclick="javascript: window.location='trie.php';"><span class="glyphicon glyphicon-remove"></span> Annuler</button>
            </div>
        </div>
    </form>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }


    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }
</style>
</body>
</html>
