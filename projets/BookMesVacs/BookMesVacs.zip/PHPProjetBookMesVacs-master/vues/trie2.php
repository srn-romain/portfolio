<?php
// PARTIE DONNES ---------------------------------------------------------
// inclusion de la méthode de dialogue avec la BD
require_once '../persistance/DialogueBD.php';
require_once 'menu.html';

try {
    $undlg = new DialogueBD();

    //$codeService = $_POST['service'];
    $mesCli = $undlg-> getTousLesClients();
    $mesPays = $undlg-> getTousLesPays();
    $mesHeber = $undlg-> getTousLesHeber();
} catch (Exception $e) {
    $erreur = $e->getMessage();
}
?>
<!-- PARTIE AFFICHAGE --------------------------------------------------- -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <link rel="stylesheet" />
    <title>info select</title>
    <?php require_once("header.php"); ?>
</head>
<body>
<h1>Selectionnez un sujet pour avoir plus d'information</h1>
<br><br>
<div class="well">
    <form class="formulaire" action="infoCli.php" method="post">
        <ul>
            <label for="champCli"> </label>
            <select name="client" id="champCli" class="form-control form-control-lg">
                <option selected="selected" > Selectionnez un client</option>
                <?php
                foreach ($mesCli as $ligne) {
                    $code = $ligne['IDCLIENT'];
                    $nom = $ligne['NOMCLI'];
                    $prenom = $ligne['PRENOMCLI'];
                    echo "<option value=$code>$nom $prenom</option>";
                }
                ?>
            </select>
        </ul>
        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span class="glyphicon glyphicon-ok"></span>Valider</button>
                <button type="button" class="btn btn-default btn-primary" onclick="javascript: window.location='trie2.php';"><span class="glyphicon glyphicon-remove"></span> Annuler</button>
            </div>
        </div>
    </form>
</div>

<br><br>

<div class="well">
    <form class="formulaire" action="infoPays.php" method="post">
        <ul>
            <label for="champPays"> </label>
            <select name="pays" id="champPays" class="form-control form-control-lg">
                <option selected="selected" > Selectionnez un pays </option>
                <?php
                foreach ($mesPays as $ligne) {
                    $code = $ligne['IDPAYS'];
                    $pays = $ligne['NOMPAYS'];
                    echo "<option value=$code>$pays </option>";
                }
                ?>
            </select>
        </ul>
        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span class="glyphicon glyphicon-ok"></span>Valider</button>

                <button type="button" class="btn btn-default btn-primary" onclick="javascript: window.location='trie2.php';"><span class="glyphicon glyphicon-remove"></span> Annuler</button>
            </div>
        </div>
    </form>
</div>

<br><br>

<div class="well">
    <form class="formulaire" action="infoHeber.php" method="post">
        <ul>
            <label for="champHeber"> </label>
            <select name="hebergement" id="champHeber" class="form-control form-control-lg">
                <option selected="selected" > Selectionnez un hebergement </option>
                <?php
                foreach ($mesHeber as $ligne) {
                    $code = $ligne['IDHEBER'];
                    $nom = $ligne['NOMHEBER'];
                    echo "<option value=$code>$nom </option>";
                }
                ?>
            </select>
        </ul>
        <div class="form-group">
            <div class="text-center">
                <button type="submit" class="btn btn-default btn-primary"><span class="glyphicon glyphicon-ok"></span>Valider</button>

                <button type="button" class="btn btn-default btn-primary" onclick="javascript: window.location='trie2.php';"><span class="glyphicon glyphicon-remove"></span> Annuler</button>
            </div>
        </div>
    </form>
</div>

<br>
<div class="text-center">
    <p class="mb-0">Site web développé par SIEURIN Romain - BookMesVacs.fr - Tous droits réservés &copy; 2023.</p>
</div>
<br>

<style>
    body{
        background-color: #7BC626;
        background-repeat: no-repeat;
        background-size: 120%;
        padding-top: 100px;
    }


    .btn {
        display: inline-block;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        background-color: #348310;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #69C93D;
    }

    .text-center {
        text-align: center;
    }
</style>
</body>
</html>
