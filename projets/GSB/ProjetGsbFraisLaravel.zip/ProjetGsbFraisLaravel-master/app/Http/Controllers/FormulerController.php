<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Session;
use App\metier\Formulation;
use Exception;
use App\Exceptions\MonException;
use App\dao\serviceFormulation;
//use Illuminate\Support\Facades\Request; //Pour ajouter un medoc
use Illuminate\Http\Request; //Pour rechercher un medoc


class FormulerController extends Controller
{

    public function getFormulation()
    {
        try {
            $erreur = Session::get('erreur');
            Session::forget('erreur');
            $unServiceForm = new serviceFormulation();
            $id_visiteur = Session::get('id');
            $mesFormulations = $unServiceForm->getFormulationVisiteur($id_visiteur);
            return view('vues/SP1/listeFormulation', compact('mesFormulations', 'erreur'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function beforeAjouterFormulation()
    {
        try {
            $erreur = "";
            $titreVue = "Ajout d'une formulation";
            $unServiceForm = new serviceFormulation();
            $mesFormulations = $unServiceForm->afficherFormulaireAjoutFormulation();
            return view('vues/SP1/formFormulationAjouter', compact('mesFormulations', 'titreVue', 'erreur'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function postAjouterForm(Request $request) {
        try {
            $qte_formuler = $request->input("qte_formuler");
            $id_medicament = $request->input("id_medicament");
            $id_presentation = $request->input("id_presentation");

            $unServiceForm = new serviceFormulation();
            $unServiceForm->ajoutForm($qte_formuler, $id_medicament, $id_presentation);

            // Récupére données formulations
            $id_visiteur = Session::get('id');
            $mesFormulations = $unServiceForm->getFormulationVisiteur($id_visiteur);

            // Rediriger vers page "listeFormulation"
            return view('vues/SP1/listeFormulation', ['mesFormulations' => $mesFormulations, 'success' => 'La formulation a bien été été ajoutée']);

        } catch (MonException $e) {
            $erreurspe = $e->getMessage();
            $mesFormulations = $unServiceForm->afficherFormulaireAjoutFormulation();

            return view('vues/SP1/formFormulationAjouter', compact('erreurspe', 'mesFormulations'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }


    public function beforeSupprimerFormulation($id_medicament, $id_presentation) {
        try {
            $unServiceForm = new serviceFormulation();
            $uneForm = $unServiceForm->getuneForm($id_medicament, $id_presentation);
            return view('vues/SP1/supprimerFormulation', compact('uneForm'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function postSupprimerFormulation($id_medicament = null, $id_presentation = null) {
        try {
            $unServiceFormulation = new serviceFormulation();
            $unServiceFormulation->supprimerFormulation($id_medicament, $id_presentation);

            // Récupérer les données des formulations
            $unServiceForm = new serviceFormulation();
            $id_visiteur = Session::get('id');
            $mesFormulations = $unServiceForm->getFormulationVisiteur($id_visiteur);

            // Rediriger vers la page "listeFormulation" avec un message de succès
            return view('vues/SP1/listeFormulation', ['mesFormulations' => $mesFormulations, 'success' => 'La formulation a été supprimée avec succès']);
        } catch (MonException $e) {
            $erreur = "Erreur lors de la suppression de la formulation.";
            return view('vues/monError', compact('erreur'));
        } catch (Exception $e) {
            $erreur = "Une erreur inattendue s'est produite.";
            return view('vues/monError', compact('erreur'));
        }
    }

    public function beforeModifierFormulation($id_medicament, $id_presentation)
    {
        try {
            $erreur = "";
            $unServiceForm = new serviceFormulation();
            $uneForm = $unServiceForm->getuneForm($id_medicament, $id_presentation);
            $titreVue = "Modification d'une formulation";

            // Récupére données formulations
            $id_visiteur = Session::get('id');
            $mesFormulations = $unServiceForm->getFormulationVisiteur($id_visiteur);

            return view('vues/SP1/modifierFormulation', compact('uneForm', 'titreVue', 'mesFormulations','erreur'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function postModifierFormulation(Request $request, $id_medicament, $id_presentation)
    {
        try {
            $new_id_medicament = $request->input("id_medicament");
            $new_id_presentation = $request->input("id_presentation");
            $qte_formuler = $request->input("qte_formuler");

            $unServiceFormulation = new serviceFormulation();
            $unServiceFormulation->modifierFormulation($id_medicament, $id_presentation, $new_id_medicament, $new_id_presentation, $qte_formuler);

            // Récupérer les données de formulation
            $id_visiteur = Session::get('id');
            $mesFormulations = $unServiceFormulation->getFormulationVisiteur($id_visiteur);

            return view('vues/SP1/listeFormulation', ['mesFormulations' => $mesFormulations, 'success' => 'La formulation a été modifiée avec succès']);
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (\Illuminate\Database\QueryException $e) {
            // Vérifier si c'est une erreur de violation de contrainte d'intégrité
            if ($e->errorInfo[1] === 1062) {
                $errorMessage = "Erreur de violation de contrainte d'intégrité : La combinaison de médicament et de présentation existe déjà.";
                return redirect()->back()->with('errorMessage', $errorMessage);
            } else {
                // Autre traitement des erreurs de requête SQL
                $errorMessage = "Erreur lors de la modification de la formulation : " . $e->getMessage();
                return redirect()->back()->with('errorMessage', $errorMessage);
            }
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }


    public function getMedicament()
    {
        try {
            $erreur = Session::get('erreur');
            Session::forget('erreur');
            $unServiceForm = new serviceFormulation();
            $mesFamilles = $unServiceForm->getFamille();
            return view('vues/SP1/rechercheMedicament', compact('mesFamilles', 'erreur'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function getresultatParNom(Request $request)
    {
        try {
            $searchTerm = $request->input('searchTerm');
            $erreur = Session::get('erreur');
            Session::forget('erreur');
            $unServiceForm = new serviceFormulation();
            $mesResultatsNom = $unServiceForm->rechercherMedicamentParNom($searchTerm);
            return view('vues/SP1/resultatRechercheMedicamentNom', compact('mesResultatsNom', 'erreur','searchTerm'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }


    public function getresultatParFamille(Request $request)
    {
        try {
            $erreur = Session::get('erreur');
            Session::forget('erreur');
            $searchTermRempli = $request->input('selectedFamily');
            $unServiceForm = new serviceFormulation();
            $mesResultatsFamille = $unServiceForm->rechercherMedicamentParFamille($searchTermRempli);
            return view('vues/SP1/resultatRechercheMedicamentFamille', compact('mesResultatsFamille', 'erreur','searchTermRempli'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function postTriePresentation(Request $request) {
        try {
            $seuil = $request->input("nb");

            $unServiceTrier = new serviceFormulation();
            $mesValeurs = $unServiceTrier->getPreTrie($seuil);

            return view('vues/SP1/listePresentationTrier', compact('mesValeurs'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }



}
