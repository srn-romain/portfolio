<?php

namespace App\Http\Controllers;

//use Request;
use Illuminate\Support\Facades\Session;
use App\metier\Frais;
use Exception;
use App\Exceptions\MonException;
use App\dao\serviceFrais;
use Illuminate\Support\Facades\Request;

class FraisController extends Controller
{

    public function getFraisVisiteur()
    {
        try {
            $erreur = Session::get('erreur');
            Session::forget('erreur');
            $unServiceFrais = new serviceFrais();
            $id_visiteur = Session::get('id');
            $mesFrais = $unServiceFrais->getFrais($id_visiteur);
            return view('vues/listeFrais', compact('mesFrais', 'erreur'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function updateFrais($id)
    {
        try {
            $erreur = "";
            $unServiceFrais = new serviceFrais();
            $unFrais = $unServiceFrais->getunFrais($id);
            $titreVue = "Modification d'une fiche de Frais";
            return view('vues/formFraisModifier', compact('unFrais', 'titreVue', 'erreur'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function beforeAjouterFrais()
    {
        try {
            $erreur = "";
            $unFrais = new Frais();
            $unFrais ->__construct();
            $titreVue="Ajout d'une fiche de frais";
            return view('vues/formFraisAjouter', compact('unFrais','titreVue','erreur'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function postmodifierFrais()
    {
        try {
            $id_frais = Request::input("id_frais");
            $anneemois = Request::input("anneemois");
            $nbjustificatifs = Request::input("nbjustificatifs");
            $unServiceFrais = new serviceFrais();
            if ($id_frais > 0) {
                $unServiceFrais->updateFrais($id_frais, $anneemois, $nbjustificatifs);
            } else {
                $montant = Request::input("montant");
                $id_visiteur = Request::get("id");
                $unServiceFrais = insertFrais($anneemois, $nbjustificatifs, $id_visiteur, $montant);
            }
            return redirect('/frais/listeFrais');
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));

        }
    }

    public function postAjouterFrais() {
        try {
            $id_frais = Request::input("id_frais");
            $anneemois = Request::input("anneemois");
            $nbjustificatifs = Request::input("nbjustificatifs");

            $unServiceFrais = new serviceFrais();
            $id_visiteur=Session::get('id');
            $unServiceFrais->ajoutFrais($anneemois, $nbjustificatifs, $id_visiteur);

            return view("home");
        }catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact( 'erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function supprimerFrais($id){
        try{
            $unServiceFrais= new serviceFrais();
            $unFrais = $unServiceFrais->getunFrais($id);
        }catch (MonException $e) {
            $erreur = $e->getMessage();
            return view( 'vues/error', compact ( 'erreur'));
        }catch (Exception $e){
            $erreur = $e->getMessage();
            return view( 'vues/error', compact ( 'erreur'));
        }
        return view( 'vues/formFraisSupprimer', compact('unFrais'));
    }

    public function postSupprimerFrais($id = null) {
        try {
            $unServiceFrais = new serviceFrais();
            $unServiceFrais->deleteFrais($id);
            return view('home');
        } catch (MonException $e) {
            //$erreur = $e->getMessage();
            $erreur = " frais HF existants";
            return view('vues/monError', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/monError', compact('erreur'));
        }
    }

    public function getFraisHF($id_frais)
    {
        try {
            $erreur = Session::get('erreur');
            Session::forget('erreur');
            $unServiceFrais = new serviceFrais();
       //     $id_frais = Session::get('id');
            $mesFraisHF = $unServiceFrais->getFraisHF($id_frais);

            return view('vues/listeFraisHF', compact('id_frais','mesFraisHF', 'erreur'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function updateFraisHF($id)
    {
        try {
            $erreur = "";
            $unServiceFraisHF = new serviceFrais();
            $unFraisHF = $unServiceFraisHF->getunFraisHF($id);
            $titreVue = "Modification d'une fiche de Frais Hors Forfait";
            return view('vues/formFraisModifierHF', compact('unFraisHF', 'titreVue', 'erreur'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function postmodifierFraisHF()
    {
        try {
            $id_frais = Request::input("id_frais");
            $date = Request::input("date");
            $lib = Request::input("lib");
            $montant = Request::input("montant");
            $unServiceFraisHF = new serviceFrais();
            $unServiceFraisHF->updateFraisHF($id_frais, $date, $lib,$montant);

            return view('home');
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));

        }
    }

    public function supprimerFraisHF($id){
        try{
            $unServiceFrais= new serviceFrais();
            $unFraisHF = $unServiceFrais->getunFraisHF($id);
        }catch (MonException $e) {
            $erreur = $e->getMessage();
            return view( 'vues/error', compact ( 'erreur'));
        }catch (Exception $e){
            $erreur = $e->getMessage();
            return view( 'vues/error', compact ( 'erreur'));
        }
        return view( 'vues/formFraisSupprimerHF', compact('unFraisHF'));
    }

    public function postSupprimerFraisHF($id = null) {
        try {
            $unServiceFraisHF = new serviceFrais();
            $unServiceFraisHF->deleteFraisHF($id);
            return view('home');
        } catch (MonException $e) {
            //$erreur = $e->getMessage();
            $erreur = " frais HF existants";
            return view('vues/monError', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/monError', compact('erreur'));
        }
    }

    public function beforeajouterFraisHF($id_frais)
    {
        try {
            $erreur = "";
            $unFraisHF = new Frais();
            $unFraisHF ->__construct();
            $unFraisHF ->id_frais=$id_frais;
            $titreVue="Ajout d'une fiche de frais HF";
            return view('vues/formFraisAjouterHF', compact('unFraisHF'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function postAjouterFraisHF() {
        try {
            $date = Request::input("date_fraishorsforfait");
            $lib = Request::input("lib_fraishorsforfait");
            $montant = Request::input("montant_fraishorsforfait");
            $id_frais = Request::input("id_frais");

            $unServiceFraisHF = new serviceFrais();
            $unServiceFraisHF->ajoutFraisHF($date, $lib, $montant, $id_frais);

            return redirect('/fraisHF/listerFraisHF/' . $id_frais);        }catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact( 'erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

}
