<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Session;
use App\metier\Formulation;
use Exception;
use App\Exceptions\MonException;
use App\dao\servicePresentation;
//use Illuminate\Support\Facades\Request; //Pour ajouter un medoc
use Illuminate\Http\Request;

class PresentationController extends Controller
{

    public function getPre()
    {
        try {
            $erreur = Session::get('erreur');
            Session::forget('erreur');
            $unServiceForm = new servicePresentation();
            $mesFormulations = $unServiceForm->getPre();
            return view('vues/SP1/listePresentation', compact('mesFormulations', 'erreur'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function beforemodifPre($id_presentation)
    {
        try {
            $erreur = "";
            $unServicePre = new servicePresentation();
            $unePre = $unServicePre->getunePre($id_presentation);
            $titreVue = "Modification d'une Presentation";
            return view('vues/SP1/modifPresentation', compact('unePre', 'titreVue', 'erreur'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function beforeAjouterPre()
    {
        try {
            $erreur = "";
            $titreVue="Ajout d'une fiche de frais";
            return view('vues/SP1/formPreAjouter', compact('titreVue','erreur'));
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }


    public function postAjouterPre(Request $request) {
        try {
            $libelle = $request->input("libelle");

            $unServiceFrais = new servicePresentation();
            $unServiceFrais->ajoutPre($libelle);

            return view("home");
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function getPageTrie()
    {
        try {
            return view('vues/SP1/trie');
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

    public function postModifierPresentation(Request $request, $id_medicament, $id_presentation)
    {
        try {
            $new_id_medicament = $request->input("id_medicament");
            $new_id_presentation = $request->input("id_presentation");
            $qte_formuler = $request->input("qte_formuler");

            $unServiceFormulation = new serviceFormulation();
            $unServiceFormulation->modifierFormulation($id_medicament, $id_presentation, $new_id_medicament, $new_id_presentation, $qte_formuler);

            // Récupérer les données de formulation
            $id_visiteur = Session::get('id');
            $mesFormulations = $unServiceFormulation->getFormulationVisiteur($id_visiteur);

            return view('vues/SP1/listeFormulation', ['mesFormulations' => $mesFormulations, 'success' => 'La formulation a été modifiée avec succès']);
        } catch (MonException $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        } catch (\Illuminate\Database\QueryException $e) {
            // Vérifier si c'est une erreur de violation de contrainte d'intégrité
            if ($e->errorInfo[1] === 1062) {
                $errorMessage = "Erreur de violation de contrainte d'intégrité : La combinaison de médicament et de présentation existe déjà.";
                return redirect()->back()->with('errorMessage', $errorMessage);
            } else {
                // Autre traitement des erreurs de requête SQL
                $errorMessage = "Erreur lors de la modification de la formulation : " . $e->getMessage();
                return redirect()->back()->with('errorMessage', $errorMessage);
            }
        } catch (Exception $e) {
            $erreur = $e->getMessage();
            return view('vues/error', compact('erreur'));
        }
    }

}
