<?php

namespace App\Http\Controllers;

//use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Request;
use App\dao\ServiceVisiteur;
class VisiteurController extends Controller{
    public function getLogin(){
        try{
            $erreur="";
            return view('vues/formLogin',compact('erreur'));
        }catch (MonException $e){
            $monErreur = $e ->getMessage();
            return view ('vues/formLogin',compact('erreur'));
        }catch (Exception $e){
            $monErreur = $e ->getMessage();
            return view ('vues/formLogin',compact('erreur'));
        }
    }

    public function signIn(){
        try{
            $login= Request::input('login');
            $pwd= Request::input('pwd');
            $unVisiteur= new ServiceVisiteur();
            $connected= $unVisiteur->login($login,$pwd);

            if ($connected){
                    return view('home');
            } else {
                $erreur = "Login ou mot de passe incorrect";
                return view('vues/formLogin', compact('erreur'));
            }
        } catch (MonException $e){
            $monErreur = $e->getMessage();
            return view ('vues/formLogin', compact('erreur'));
        } catch (Exception $e){
            $monErreur = $e->getMessage();
            return view ('vues/formLogin', compact('erreur'));
        }
    }


    public function signOut(){
        $unVisiteur = new ServiceVisiteur();
        $unVisiteur->logout();
        return view('home');
    }

}
