<?php

namespace App\dao;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use App\Exceptions\MonException;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;


Class ServiceVisiteur{
    public function login($login, $pwd){
        $connected = false;
        try{
            $visiteur = DB::table('visiteur')
                ->select()
                ->where('login_visiteur', '=', $login)
                ->first();

            if($visiteur){

                if(Hash::check($pwd, $visiteur->pwd_visiteur)){
                    Session::put('id', $visiteur->id_visiteur);
                    Session::put('type', $visiteur->type_visiteur);
                    Session::put('nom_utilisateur', $visiteur->nom_visiteur);
                    Session::put('prenom_utilisateur', $visiteur->prenom_visiteur);
                    $connected = true;
                }
            }
        } catch (QueryException $e){
            throw new MonException($e->getMessage(), 5);
        }
        return $connected;
    }

    public function logout(){
        Session::put('id', 0);

        Session::forget('type');
    }
}
?>
