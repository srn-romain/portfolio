<?php

namespace App\dao;

use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use App\Exceptions\MonException;
use Illuminate\Support\Facades\Session;

class serviceFormulation{

    public function getFormulationVisiteur(){
        try{
            $lesFormulations= DB::table('formuler')
                ->join('medicament', 'formuler.id_medicament', '=', 'medicament.id_medicament')
                ->join('presentation', 'formuler.id_presentation', '=', 'presentation.id_presentation')
                ->select()
                //->orderBy('medicament.nom_commercial', 'asc')
                ->orderBy('formuler.qte_formuler', 'asc')
                ->get();
            return $lesFormulations;
        } catch (QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }


    public function afficherFormulaireAjoutFormulation()
    {
        try {
            $medicaments = DB::table('medicament')->select('id_medicament', 'nom_commercial')->get();
            $presentations = DB::table('presentation')->select('id_presentation', 'lib_presentation')->get();

            return [
                'medicaments' => $medicaments,
                'presentations' => $presentations
            ];
        } catch (QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }


    public function ajoutForm($qte_formuler, $id_medicament, $id_presentation){
        try {
            DB::table('formuler')->insert([
                'id_medicament' => $id_medicament,
                'id_presentation' => $id_presentation,
                'qte_formuler' => $qte_formuler
            ]);
        } catch (\Illuminate\Database\QueryException $e) {
            $errorCode = $e->errorInfo[1];
            if ($errorCode == 1062) { // Erreur de duplication de clé primaire
                throw new MonException("Une formulation avec ces données existe déjà.", 1062);
            } else {
                throw new MonException($e->getMessage(), $errorCode);
            }
        }
    }

    public function getuneForm($id_medicament, $id_presentation) {
        try {
            $uneFormulation = DB::table('formuler')
                ->join('medicament', 'formuler.id_medicament', '=', 'medicament.id_medicament')
                ->join('presentation', 'formuler.id_presentation', '=', 'presentation.id_presentation')
                ->where('formuler.id_medicament', $id_medicament)
                ->where('formuler.id_presentation', $id_presentation)
                ->first();

            return $uneFormulation;
        } catch (\Illuminate\Database\QueryException $e) {
            throw new MonException($e->getMessage(), $e->getCode());
        }
    }

    public function supprimerFormulation($id_medicament, $id_presentation) {
        try {
            DB::table('formuler')
                ->where('id_medicament', $id_medicament)
                ->where('id_presentation', $id_presentation)
                ->delete();
        } catch (Illuminate\Database\QueryException $e) {
            throw new MonException("Erreur lors de la suppression de la formulation.", 5);
        }
    }

    public function modifierFormulation($id_medicament, $id_presentation, $new_id_medicament, $new_id_presentation, $qte_formuler)
    {
        try {
            DB::table('formuler')
                ->where('id_medicament', $id_medicament)
                ->where('id_presentation', $id_presentation)
                ->update([
                    'id_medicament' => $new_id_medicament,
                    'id_presentation' => $new_id_presentation,
                    'qte_formuler' => $qte_formuler
                ]);
        } catch (Illuminate\Database\QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }

    public function getFamille(){
        try{
            $lesFamilles= DB::table('famille')
                ->get();
            return $lesFamilles;
        } catch (QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }

    public function rechercherMedicamentParNom($searchTerm)
    {
        try {
            $resultats = DB::table('medicament as m')
                ->join('formuler', 'formuler.id_medicament', '=', 'm.id_medicament')
                ->join('presentation', 'formuler.id_presentation', '=', 'presentation.id_presentation')
                ->join('famille', 'm.id_famille', '=', 'famille.id_famille')
                ->where('m.nom_commercial', 'like', '%' . $searchTerm . '%')
                ->select('m.*', 'presentation.lib_presentation', 'formuler.qte_formuler', 'famille.lib_famille')
                ->orderBy('m.nom_commercial', 'asc')
                ->get();

            return $resultats;
        } catch (QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }

    public function rechercherMedicamentParFamille($idFamille)
    {
        try {
            $lesFormulations = DB::table('formuler')
                ->join('medicament', 'formuler.id_medicament', '=', 'medicament.id_medicament')
                ->join('presentation', 'formuler.id_presentation', '=', 'presentation.id_presentation')
                ->join('famille', 'medicament.id_famille', '=', 'famille.id_famille')
                ->where('famille.id_famille', $idFamille)
                ->select('medicament.*', 'presentation.lib_presentation', 'formuler.qte_formuler','famille.lib_famille')
                ->orderBy('medicament.nom_commercial', 'asc')
                ->get();
            return $lesFormulations;
        } catch (QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }

    public function getPreTrie($seuil){
        try {
            $lesFrais = DB::table('formuler')
                ->select()
                ->join('presentation', 'formuler.id_presentation', '=', 'presentation.id_presentation')
                ->join('medicament', 'formuler.id_medicament', '=', 'medicament.id_medicament')
                ->where('qte_formuler', '<', $seuil)
                ->distinct()
                ->get();
            return $lesFrais;
        } catch (QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }


}
