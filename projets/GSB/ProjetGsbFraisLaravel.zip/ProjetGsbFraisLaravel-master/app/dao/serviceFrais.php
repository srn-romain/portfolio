<?php

namespace App\dao;

use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use App\Exceptions\MonException;
use Illuminate\Support\Facades\Session;

class serviceFrais{

    public function getFrais($id_visiteur){
        try{
            $lesFrais= DB::table('frais')
                ->Select()
                ->where('frais.id_visiteur','=',$id_visiteur)
                ->get();
            return $lesFrais;
        }catch (QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }

    public function updateFrais($id,$anneemois,$nb){
        try{
            $dateJour=date("Y-m-d");
            DB::table("frais")
                ->where('id_frais','=',$id)
                ->update(["anneemois"=>$anneemois,"nbjustificatifs"=>$nb,
                    "datemodification"=>$dateJour]);
        }catch (QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }

    public function getunFrais($id){
        try{
            $unFrais=DB::table('frais')
                ->select()
                ->where('id_frais','=',$id)
                ->first();
            return $unFrais;
        }catch(\Illuminate\Database\QueryException $e){
            throw new MonException ($e->getMessage(), 5);
        }
    }

    public function ajoutFrais($anneemois, $nbjustificatifs, $id_visiteur){
        try {
            DB::table('frais')->insert(
                ['anneemois' => $anneemois,
                    'nbjustificatifs' => $nbjustificatifs,
                    'id_etat'=>2,
                    'id_visiteur' => $id_visiteur,
                    'montantvalide'=>0]);
        }catch (Illuminate\Database\QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }

    public function deleteFrais($id){
        try {
            DB::table('frais')
                ->where('id_frais', $id)
                ->delete();

        }catch(\Illuminate\Database\QueryException $e){
            throw new MonException($e->getMessage(),5);
        }
    }

    public function getFraisHF($id_frais){
        try{
            $lesFrais= DB::table('fraishorsforfait')
                ->Select()
                ->where('fraishorsforfait.id_frais','=',$id_frais)
                ->get();
            return $lesFrais;
        }catch (QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }

    public function getunFraisHF($id){
        try{
            $unFraisHF=DB::table('fraishorsforfait')
                ->select()
                ->where('id_fraishorsforfait','=',$id)
                ->first();
            return $unFraisHF;
        }catch(\Illuminate\Database\QueryException $e){
            throw new MonException ($e->getMessage(), 5);
        }
    }

    public function updateFraisHF($id_frais, $date, $lib, $montant){
        try{
            DB::table("fraishorsforfait")
                ->where('id_fraishorsforfait','=',$id_frais)
                ->update(["date_fraishorsforfait"=>$date,"lib_fraishorsforfait"=>$lib,
                    "montant_fraishorsforfait"=>$montant]);
        }catch (QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }

    public function deleteFraisHF($id){
        try {
            DB::table('fraishorsforfait')
                ->where('id_fraishorsforfait', $id)
                ->delete();

        }catch(\Illuminate\Database\QueryException $e){
            throw new MonException($e->getMessage(),5);
        }
    }

    public function ajoutFraisHF($date, $lib, $montant, $id_frais){
        try {
            DB::table('fraishorsforfait')->insert(
                ['id_frais'=>$id_frais, 'date_fraishorsforfait' => $date,
                    'lib_fraishorsforfait' => $lib,
                    'montant_fraishorsforfait' =>$montant]);
        }catch (Illuminate\Database\QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }

}
