<?php

namespace App\dao;

use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use App\Exceptions\MonException;

class servicePresentation
{

    public function getPre(){
        try{
            $lesFrais= DB::table('presentation')
                ->Select()
                ->join('formuler', 'presentation.id_presentation', '=', 'formuler.id_presentation')
                ->join('medicament', 'formuler.id_medicament', '=', 'medicament.id_medicament')
                ->orderBy('formuler.qte_formuler')
                ->get();
            return $lesFrais;
        }catch (QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }

    public function getunePre($id_presentation) {
        try {
            $uneFormulation = DB::table('presentation')
                ->Select()
                ->where('presentation.id_presentation', $id_presentation)
                ->first();

            return $uneFormulation;
        } catch (\Illuminate\Database\QueryException $e) {
            throw new MonException($e->getMessage(), $e->getCode());
        }
    }

    public function ajoutPre($libelle){
        try {
            DB::table('presentation')->insert(
                ['lib_presentation' => $libelle,
                    ]);
        }catch (Illuminate\Database\QueryException $e) {
            throw new MonException($e->getMessage(), 5);
        }
    }

}
