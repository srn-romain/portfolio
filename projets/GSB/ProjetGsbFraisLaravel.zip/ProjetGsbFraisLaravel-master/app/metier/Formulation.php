<?php

namespace App\metier;

use Illuminate\Database\Eloquent\Model;
use DB;

class Formulation
{
    //On déclare la table Formulation
    protected $table = 'formulation';
    public $timestamps=false;
    protected $fillable = [
        'id_medicament',
        'id_presentation',
        'qte_formuler',
    ];

}
