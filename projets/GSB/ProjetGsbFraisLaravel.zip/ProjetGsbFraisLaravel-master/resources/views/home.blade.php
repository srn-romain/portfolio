@extends('layouts.master')
@section('content')

    <style>
        .center-image {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
    </style>

    <div>
        @if (Session::get('id') == 0)
            <h1 class="bvn">Bienvenue sur notre application GSB</h1>
            <p>Veuillez vous connecter pour avoir accès aux différents menus de l'application.<br>
                Le bouton de connexion se trouve en haut à droite de cet écran.</p>
        @else
            @if(Session::get('type') == 'V')
                <h1 class="bvn">Bonjour {{ Session::get('prenom_utilisateur') }} {{ Session::get('nom_utilisateur') }},<br> Bienvenue sur notre application GSB</h1>
                <p>Vous êtes désormais connecté en tant que visiteur. Avec ce rôle, vous avez à présent accès à la Gestion des frais de déplacements.</p>
            @elseif(Session::get('type') == 'C')
                <h1 class="bvn">Bonjour {{ Session::get('prenom_utilisateur') }} {{ Session::get('nom_utilisateur') }},<br> Bienvenue sur notre application GSB</h1>
                <p>Vous êtes désormais connecté en tant que commercial. Avec ce rôle, vous avez à présent accès à la Gestion des Formulations</p>
            @else
                <h1 class="bvn">Bonjour {{ Session::get('prenom_utilisateur') }} {{ Session::get('nom_utilisateur') }},<br> Bienvenue sur notre application GSB</h1>
                <p>Vous êtes désormais connecté en tant que Comptable ou qu'Administrateur. Bonne visite !</p>
            @endif
        @endif

            <div class="center-image">
                <img src="{{ asset('assets/images/gsb.png') }}" alt="GSB Image">
            </div>

    </div>
@stop
