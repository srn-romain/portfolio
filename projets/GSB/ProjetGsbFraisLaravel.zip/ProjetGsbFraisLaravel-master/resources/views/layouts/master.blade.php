<!doctype html>
<html lang="fr">
<head>
    <title>App GSB</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    {!! Html::style('assets/css/bootstrap.css') !!}
    {!! Html::style('assets/css/monStyle.css') !!}

    <!-- Code pour le favicon -->
    <link rel="shortcut icon" href="{{ asset('assets/images/favicon.png') }}" type="image/x-icon">

    <!-- Fonts -->
    <link href='//fonts.googleapis.com/css?family=Roboto:400,300' rel='stylesheet' type='text/css'>
</head>
<body class="body">
<div class="container">
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-target">
                    <span class="sr-only">Toggle navigation</span> <span class="iconbar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar+ bvn"></span>
                </button>
                <a class="navbar-brand" href="{{ url('/') }}">GSB Frais </a>
            </div>
            @if (Session::get('id') == 0)
                <div class="collapse navbar-collapse" id="navbar-target">
                    <ul class="nav navbarbar-nav navbar-right">
                        <li><a href="{{ url('/connexion/formLogin') }}" data-toggle="collapse" data-target=".navbar-collapse.in">Se connecter</a></li>
                    </ul>
                </div>
            @endif
            @if (Session::get('id') > 0)
                <div class="collapse navbar-collapse" id="navbar-collapse-target">
                    <ul class="nav navbar-nav">
                        @if(Session::get('type') === 'V')
                            <!-- Si le visiteur est de type 'v' (visiteur), afficher les liens correspondants -->
                            <li><a href="{{ url('/frais/listeFrais') }}" data-toggle="collapse" data-target=".navbar-collapse.in">Lister Frais</a></li>
                            <li><a href="{{ url('/frais/ajouterFrais') }}" data-toggle="collapse" data-target=".navbar-collapse.in">Ajouter Frais</a></li>
                        @elseif(Session::get('type') === 'C')
                            <!-- Si le visiteur est de type 'c' (commercial), afficher les liens correspondants -->
                            <li><a href="{{ url('/formulation/listeFormulation') }}" data-toggle="collapse" data-target=".navbar-collapse.in">Liste des Formulations</a></li>
                            <li><a href="{{ url('/formulation/ajouterFormulation') }}" data-toggle="collapse" data-target=".navbar-collapse.in">Ajouter Formulation</a></li>
                            <li><a href="{{ url('/medicament/rechercheMedicament') }}" data-toggle="collapse" data-target=".navbar-collapse.in">Recherche d'un médicament</a></li>
                            <li><a href="{{ url('/presentation/listerP') }}" data-toggle="collapse" data-target=".navbar-collapse.in">Lister Présentation</a></li>
                        @endif
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="{{ url('/connexion/getLogout') }}" data-toggle="collapse" data-target=".navbar-collapse.in">Se deconnecter </a></li>
                    </ul>
                </div>
            @endif
        </div><!--/.container-fluid -->
    </nav>
</div>
<div class="container">
    @yield('content')
</div>
{!! Html::script('assets/js/bootstrap.min.js') !!}
{!! Html::script('assets/js/bootstrap.js') !!}
</body>
</html>
