@extends ('layouts.master')
@section('content')
    @if(Session::get('type') === 'C')
        {!! Form::open(['url' => '/formulation/postAjouterForm']) !!}
        <div class="blanc">
            <h1 style="text-align: center">Ajouter une Formulation</h1>
        </div>
        <div class="col-md-12 col-sm-12 well well-md">
            <center><h1> </h1></center>
            <div class="form-horizontal">

                <div class="form-group">
                    <label class="col-md-3 col-sm-3 control-label">Médicament : </label>
                    <div class="col-md-6 col-sm-6">
                        {!! Form::select('id_medicament', $mesFormulations['medicaments']->pluck('nom_commercial', 'id_medicament'), null, ['class' => 'form-control', 'placeholder' => 'Sélectionnez un médicament', 'required' => 'required']) !!}
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-md-3 col-sm-3 control-label">Présentation :</label>
                    <div class="col-md-6 col-sm-6">
                        {!! Form::select('id_presentation', $mesFormulations['presentations']->pluck('lib_presentation', 'id_presentation'), null, ['class' => 'form-control', 'placeholder' => 'Sélectionnez une présentation', 'required' => 'required']) !!}
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-md-3 col-sm-3 control-label">Quantité formulée :</label>
                    <div class="col-md-2 col-sm-2">
                        <input type="number" name="qte_formuler" value="" class="form-control" min="1" required>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                        <button type="submit" class="btn btn-default btn-primary">
                            <span class="glyphicon glyphicon-ok"></span> Ajouter
                        </button>
                        &nbsp;
                        <button type="button" class="btn btn-default btn-primary"
                                onclick="javascript:if (confirm('vous êtes sûr ?')) window.location = '{{ url('/')}}';">
                            <span class="glyphicon glyphicon-remove"></span> Annuler</button>
                    </div>
                </div>

                @if(isset($erreurspe))
                    <div class="alert alert-danger">
                        {{ $erreurspe }}
                    </div>
                @endif

            @if(session('errorMessage'))
                    <div class="alert alert-danger">
                        {{ session('errorMessage') }}
                    </div>
                @endif

            </div>

        </div>
    @else
        <div class="alert alert-danger" role="alert">
            Vous n'avez pas accès à cette page. Pour y avoir accès, vous devez être connecté en tant que "Commercial".
        </div>
    @endif
@stop
