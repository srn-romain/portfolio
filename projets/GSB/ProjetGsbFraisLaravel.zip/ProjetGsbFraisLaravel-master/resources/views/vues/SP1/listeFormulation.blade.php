@extends ('layouts.master')
@section('content')
    @if(Session::get('type') === 'C')
        <div class="container">
            <div class="blanc">
                <h1 style="text-align: center">Liste des Formulations</h1>
            </div>
            @if(isset($success))
                <div class="alert alert-success">
                    {{ $success }}
                </div>
            @endif

            <table class="table table-bordered table-striped table-responsive">
                <thead>
                <tr>
                    <th style="width: 20%; text-align: center">Nom du médicament</th>
                    <th style="width: 20%; text-align: center">Libellé présentation</th>
                    <th style="width: 20%; text-align: center">Quantité formulée</th>
                    <th style="width: 20%; text-align: center">Modifier</th>
                    <th style="width: 20%; text-align: center">Supprimer</th>
                </tr>
                </thead>
                @foreach ($mesFormulations as $unForm)
                    <tr>
                        <td style="width: 20%; text-align: center">{{$unForm->nom_commercial}}</td>
                        <td style="width: 20%; text-align: center">{{$unForm->lib_presentation}}</td>
                        <td style="width: 20%; text-align: center">{{$unForm->qte_formuler}}</td>
                        <td style="width: 20%; text-align: center">
                            <a href="{{ url('/formulation/modifierForm') }}/{{ $unForm->id_medicament }}/{{ $unForm->id_presentation }}">
                                <span class="glyphicon glyphicon-pencil" data-toggle="tooltip" data-placement="top" title="modifier"></span>
                            </a>
                        </td>
                        <td style="width: 20%; text-align:center; cursor: pointer">
                            <a class="glyphicon glyphicon-remove" data-toggle="tooltip" data-placement="top" title="Supprimer"
                               onclick="window.location='{{ url('/formulation/supprimerForm') }}/{{ $unForm->id_medicament }}/{{ $unForm->id_presentation }}';">
                            </a>
                        </td>

                    </tr>
                @endforeach
            </table>
            <div class="col-md-6 col-md-offset-3">
                @include('vues/error')
            </div>
        </div>

        <!-- Ajout de l'élément pour afficher le résultat -->
        <div style="text-align: center"><div id="resultatJavascript"></div></div>
        <br><br>

    @else
        <div class="alert alert-danger" role="alert">
            Vous n'avez pas accès à cette page. Pour y avoir accès, vous devez être connecté en tant que "Commercial".
        </div>
    @endif
@stop


<script>
    function afficherMedicamentMaxQuantite() {
        var rows = document.querySelectorAll("table tbody tr");
        var maxQuantite = 0; // Initialiser maxQuantite à zéro
        var medicamentsMaxQuantite = []; // Liste pour stocker les médicaments ex aequo

        rows.forEach(function(row) {
            var quantiteCell = row.querySelector("td:nth-child(3)");
            var quantite = parseInt(quantiteCell.textContent);

            if (quantite > maxQuantite) {
                maxQuantite = quantite;
                medicamentsMaxQuantite = [row.querySelector("td:nth-child(1)").textContent]; // Réinitialiser la liste avec un seul médicament
            } else if (quantite === maxQuantite) {
                medicamentsMaxQuantite.push(row.querySelector("td:nth-child(1)").textContent); // Ajouter le médicament ex aequo à la liste
            }
        });

        // Vérifier s'il y a des médicaments ex aequo
        if (medicamentsMaxQuantite.length > 1) {
            document.getElementById("resultatJavascript").innerHTML = "Les médicaments avec la plus grande quantité sont : <b>" + medicamentsMaxQuantite.join(", ") + "</b>";
        } else {
            // Si pas d'exaequo, afficher normalement
            document.getElementById("resultatJavascript").innerHTML = "Le médicament avec la plus grande quantité est : <b>" + medicamentsMaxQuantite[0] + "</b>";
        }
    }

    window.onload = function() {
        afficherMedicamentMaxQuantite();
    };
</script>


