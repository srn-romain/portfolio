@extends ('layouts.master')
@section('content')
    @if(Session::get('type') === 'C')
        <div class="container">
            <div class="blanc">
                <h1 style="text-align: center">Liste des Présentation</h1>
            </div>
            @if(isset($success))
                <div class="alert alert-success">
                    {{ $success }}
                </div>
            @endif

            <div class="text-center mb-3">
                <a href="{{ url('/presentation/ajouterPresentation') }}" class="btn btn-primary">Ajouter une Présentation</a>
            </div><br>

            <div class="text-center mb-3">
                <a href="{{ url('/presentation/triePresentation') }}" class="btn btn-primary">Filtrer l'affichage par quantité inférieur</a>
            </div><br><br>

            <table class="table table-bordered table-striped table-responsive">
                <thead>
                <tr>
                    <th style="width: 20%; text-align: center">ID</th>
                    <th style="width: 20%; text-align: center">Libellé présentation</th>
                    <th style="width: 20%; text-align: center">Nom Médicament</th>
                    <th style="width: 20%; text-align: center">Quantité formulée</th>
                    <th style="width: 20%; text-align: center">Modifier</th>
                </tr>
                </thead>
                @foreach ($mesFormulations as $unForm)
                    <tr>
                        <td style="width: 20%; text-align: center">{{$unForm->id_presentation}}</td>
                        <td style="width: 20%; text-align: center">{{$unForm->lib_presentation}}</td>
                        <td style="width: 20%; text-align: center">{{$unForm->nom_commercial}}</td>
                        <td style="width: 20%; text-align: center">{{$unForm->qte_formuler}}</td>
                        <td style="width: 20%; text-align: center">
                            <a href="{{ url('/presentation/modifierPresentation') }}/{{ $unForm->id_presentation }}">
                                <span class="glyphicon glyphicon-pencil" data-toggle="tooltip" data-placement="top" title="modifier"></span>
                            </a>
                        </td>

                    </tr>
                @endforeach
            </table>
            <div class="col-md-6 col-md-offset-3">
                @include('vues/error')
            </div>

        </div>
        <!-- Ajout de la phrase avec le nombre de présentations -->
        <div style="text-align: center"><p style="text-align: center;">Il y a {{ count($mesFormulations) }} présentations.</p></div>
    @else
        <div class="alert alert-danger" role="alert">
            Vous n'avez pas accès à cette page. Pour y avoir accès, vous devez être connecté en tant que "Commercial".
        </div>
    @endif
@stop
