@extends ('layouts.master')
@section('content')

    <div>
        <br><br>
        <br><br>
        <div class="container">
            <div class="blanc">
                <h1 style="text-align: center">Modification d'une Presentation</h1>
            </div>
            {!! Form::open(['route' => ['postModifierPre', $unePre->id_presentation, $unePre->lib_presentation], 'method' => 'post']) !!}

            <div class="col-md-12 col-sm-12 well well-md">
                <center><h1> </h1></center>
                <div class="form-horizontal">

                    <div class="form-group">
                        <label class="col-md-3 col-sm-3 control-label">Libellé : </label>
                        <div class="col-md-2  col-sm-2">
                            <input name="libelle" value="{{$unePre->lib_presentation ?? ''}}"  class="form-control" placeholder="Nom du libellé" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                            <button type="submit" class="btn btn-default btn-primary">
                                <span class="glyphicon glyphicon-ok"></span> Valider
                            </button>
                            &nbsp;&nbsp;
                            <button type="button" class="btn btn-default btn-primary" onclick="window.location='{{url('/presentation/listerP')}}';">
                                <span class="glyphicon glyphicon-remove"></span> Annuler
                            </button>
                        </div>
                    </div>

                    @if(session('errorMessage'))
                        <div class="alert alert-danger">
                            {{ session('errorMessage') }}
                        </div>
                    @endif


                </div>
            </div>

        </div>
    </div>

@stop
