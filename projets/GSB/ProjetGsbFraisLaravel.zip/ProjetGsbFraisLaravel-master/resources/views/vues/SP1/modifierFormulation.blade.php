@extends ('layouts.master')
@section('content')

    <div>
        <br><br>
        <br><br>
        <div class="container">
            <div class="blanc">
                <h1 style="text-align: center">Modification d'une Formulation</h1>
            </div>
            {!! Form::open(['route' => ['postModifierFormulation', $uneForm->id_medicament, $uneForm->id_presentation], 'method' => 'post']) !!}

            <div class="col-md-12 col-sm-12 well well-md">
                <center><h1> </h1></center>
                <div class="form-horizontal">

                    <div class="form-group">
                        <label class="col-md-3 col-sm-3 control-label">Nom du médicament : </label>
                        <div class="col-md-6 col-sm-6">
                            <select name="id_medicament" class="form-control" required>
                                @foreach ($mesFormulations->unique('id_medicament') as $formulation)
                                    <option value="{{ $formulation->id_medicament }}" {{ $uneForm->id_medicament == $formulation->id_medicament ? 'selected' : '' }}>{{ $formulation->nom_commercial }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 col-sm-3 control-label">Libellé de la présentation : </label>
                        <div class="col-md-6 col-sm-6">
                            <select name="id_presentation" class="form-control" required>
                                @foreach ($mesFormulations->unique('id_presentation') as $formulation)
                                    <option value="{{ $formulation->id_presentation }}" {{ $uneForm->id_presentation == $formulation->id_presentation ? 'selected' : '' }}>{{ $formulation->lib_presentation }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 col-sm-3 control-label">Quantité formulée : </label>
                        <div class="col-md-2 col-sm-2">
                            <input type="number" name="qte_formuler" value="{{ $uneForm->qte_formuler ?? '' }}" class="form-control" required autofocus>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                            <button type="submit" class="btn btn-default btn-primary">
                                <span class="glyphicon glyphicon-ok"></span> Valider
                            </button>
                            &nbsp;&nbsp;
                            <button type="button" class="btn btn-default btn-primary" onclick="window.location='{{url('/formulation/listeFormulation')}}';">
                                <span class="glyphicon glyphicon-remove"></span> Annuler
                            </button>
                        </div>
                    </div>

                    @if(session('errorMessage'))
                        <div class="alert alert-danger">
                            {{ session('errorMessage') }}
                        </div>
                    @endif


                </div>
            </div>

        </div>
    </div>

@stop
