@extends('layouts.master')

@section('content')
    @if(Session::get('type') === 'C')
        <div class="container">
            <div class="blanc">
                <h1 style="text-align: center">Rechercher un médicament...</h1>
            </div>
            @if(isset($success))
                <div class="alert alert-success">
                    {{ $success }}
                </div>
            @endif

            <div class="row">
                <div class="col-md-6">
                    <h3>...Par nom de médicament :</h3>
                    <form action="{{ url('/medicament/rechercheMedicamentParNom') }}" method="POST">
                        @csrf <!-- Ajoute le jeton CSRF -->
                        <div class="form-group">
                            <input type="text" class="form-control" name="searchTerm" placeholder="Entrez le nom du médicament">
                        </div>
                        <button type="submit" class="btn btn-primary">Rechercher</button>
                    </form>
                </div>

                <div class="col-md-6">
                    <h3>...Par famille :</h3>
                    <form action="{{ url('/medicament/rechercheMedicamentParFamille') }}" method="POST">
                        @csrf <!-- Ajoute le jeton CSRF -->
                        <div class="form-group">
                            <select name="selectedFamily" class="form-control">
                                <option value="">Sélectionnez une famille</option>
                                @foreach($mesFamilles as $famille)
                                    <option value="{{ $famille->id_famille }}">{{ $famille->lib_famille }}</option>
                                @endforeach
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Rechercher</button>
                    </form>
                </div>
            </div>

            <div class="col-md-6 col-md-offset-3">
                @include('vues/error')
            </div>
        </div>
    @else
        <div class="alert alert-danger" role="alert">
            Vous n'avez pas accès à cette page. Pour y avoir accès, vous devez être connecté en tant que "Commercial".
        </div>
    @endif
@stop
