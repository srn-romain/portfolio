@extends('layouts.master')

@section('content')
    @if(Session::get('type') === 'C')
        <div class="container">
            <div class="blanc">
                <h1 style="text-align: center">Résultats de la recherche par famille de médicament</h1>
            </div>
            @if(isset($success))
                <div class="alert alert-success">
                    {{ $success }}
                </div>
            @endif

            @if(isset($mesResultatsFamille) && $mesResultatsFamille !== null && count($mesResultatsFamille) > 0)
                <table class="table table-bordered table-striped table-responsive">
                    <thead>
                    <tr>
                        <th style="width: 20%; text-align: center">Famille du médicament</th>
                        <th style="width: 20%; text-align: center">Nom du médicament</th>
                        <th style="width: 20%; text-align: center">Libellé présentation</th>
                        <th style="width: 20%; text-align: center">Quantité formulée</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach ($mesResultatsFamille as $resultat)
                        <tr>
                            <td style="width: 20%; text-align: center">{{ $resultat->lib_famille }}</td>
                            <td style="width: 20%; text-align: center">{{ $resultat->nom_commercial }}</td>
                            <td style="width: 20%; text-align: center">{{ $resultat->lib_presentation }}</td>
                            <td style="width: 20%; text-align: center">{{ $resultat->qte_formuler }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>

                @if(isset($mesResultatsFamille) && $mesResultatsFamille !== null)
                    <p style="text-align: center; color: red;">Il y a {{ count($mesResultatsFamille) }} médicament{{ count($mesResultatsFamille) > 1 ? 's' : '' }} trouvé{{ count($mesResultatsFamille) > 1 ? 's' : '' }} du type "{{$mesResultatsFamille[0]->lib_famille}}".</p>
                @endif

            @else
                <p>Aucun résultat trouvé pour la recherche : {{$searchTermRempli}}.</p>
            @endif

            <div class="col-md-6 col-md-offset-3">
                @include('vues/error')
            </div>

            <button type="button" class="btn btn-default btn-primary" onclick="window.location='{{url('/medicament/rechercheMedicament')}}';">
                <span class="glyphicon glyphicon-arrow-left"></span> Retour
            </button>


        </div>
    @else
        <div class="alert alert-danger" role="alert">
            Vous n'avez pas accès à cette page. Pour y avoir accès, vous devez être connecté en tant que "Commercial".
        </div>
    @endif
@stop
