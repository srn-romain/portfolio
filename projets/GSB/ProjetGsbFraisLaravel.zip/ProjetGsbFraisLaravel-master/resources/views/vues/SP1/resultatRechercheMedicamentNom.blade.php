@extends('layouts.master')

@section('content')
    @if(Session::get('type') === 'C')
        <div class="container">
            <div class="blanc">
                <h1 style="text-align: center">Résultats de la recherche par nom de médicament</h1>
            </div>
            @if(isset($success))
                <div class="alert alert-success">
                    {{ $success }}
                </div>
            @endif

            @if(isset($mesResultatsNom) && $mesResultatsNom !== null && count($mesResultatsNom) > 0)
                <table class="table table-bordered table-striped table-responsive">
                    <thead>
                    <tr>
                        <th style="width: 20%; text-align: center">Nom du médicament</th>
                        <th style="width: 20%; text-align: center">Libellé présentation</th>
                        <th style="width: 20%; text-align: center">Quantité formulée</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach ($mesResultatsNom as $resultat)
                        <tr>
                            <td style="width: 20%; text-align: center">{{ $resultat->nom_commercial }}</td>
                            <td style="width: 20%; text-align: center">{{ $resultat->lib_presentation }}</td>
                            <td style="width: 20%; text-align: center">{{ $resultat->qte_formuler }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>

                @if(isset($mesResultatsNom) && $mesResultatsNom !== null)
                    <p style="text-align: center; color: red;">Il y a {{ count($mesResultatsNom) }} médicament{{ count($mesResultatsNom) > 1 ? 's' : '' }} trouvé{{ count($mesResultatsNom) > 1 ? 's' : '' }} du type "{{$searchTerm }}"</p>
                @endif

            @else
                <p>Aucun résultat trouvé pour la recherche : "{{$searchTerm}}".</p>
            @endif

            <div class="col-md-6 col-md-offset-3">
                @include('vues/error')
            </div>

            <button type="button" class="btn btn-default btn-primary" onclick="window.location='{{url('/medicament/rechercheMedicament')}}';">
                <span class="glyphicon glyphicon-arrow-left"></span> Retour
            </button>

        </div>
    @else
        <div class="alert alert-danger" role="alert">
            Vous n'avez pas accès à cette page. Pour y avoir accès, vous devez être connecté en tant que "Commercial".
        </div>
    @endif
@stop
