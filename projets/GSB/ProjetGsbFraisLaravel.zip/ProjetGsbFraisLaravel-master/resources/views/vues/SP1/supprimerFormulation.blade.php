@extends('layouts.master')
@section('content')

    <div class="container">
        <div class="blanc">
            <h1>Suppression d'une Formulation</h1>
        </div>

        <div class="col-md-12 col-sm-12 well well-md">
            <center><h1></h1></center>
            <div class="form-horizontal">

                <div class="form-group">
                    <label class="col-md-3 col-sm-3 control-label">Nom du médicament :</label>
                    <div class="col-md-2 col-sm-2">
                        <p>{{ $uneForm->nom_commercial }}</p>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-md-3 col-sm-3 control-label">Libellé présentation :</label>
                    <div class="col-md-2 col-sm-2">
                        <p>{{ $uneForm->lib_presentation }}</p>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-md-3 col-sm-3 control-label">Quantité formulée :</label>
                    <div class="col-md-2 col-sm-2">
                        <p>{{ $uneForm->qte_formuler }}</p>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                        {!! Form::open(['route' => ['postSupprimerFormulation', $uneForm->id_medicament, $uneForm->id_presentation], 'method' => 'delete']) !!}
                        <button type="submit" class="btn btn-default btn-danger" onclick="javascript:if(confirm('Vous êtes sûr de vouloir supprimer cette formulation ?')) return true; else return false;">
                            <span class="glyphicon glyphicon-remove"></span> Supprimer
                        </button>
                        {!! Form::close() !!}
                    </div>
                    <button type="button" class="btn btn-default btn-primary" onclick="window.location='{{url('/formulation/listeFormulation')}}';">
                        <span class="glyphicon glyphicon-arrow-left"></span> Annuler
                    </button>
                </div>

            </div>
        </div>

    </div>

@stop
