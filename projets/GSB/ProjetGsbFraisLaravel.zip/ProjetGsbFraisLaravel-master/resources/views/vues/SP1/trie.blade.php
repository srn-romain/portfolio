@extends ('layouts.master')
@section('content')
    @if(Session::get('type') === 'C')
        {!! Form::open(['url' => '/presentation/postTriePresentation']) !!}
        <div class="blanc">
            <h1 style="text-align: center">Trier l'affichage</h1>
        </div>
        <div class="col-md-12 col-sm-12 well well-md">
            <center><h1> </h1></center>
            <div class="form-horizontal">

                <p><b>Saisissez une quantité de formulation</b></p>
                <div class="form-group">
                    <label class="col-md-3 col-sm-3 control-label">Quantité : </label>
                    <div class="col-md-2 col-sm-2">
                        <input type="number" name="nb" value="" class="form-control" required>
                    </div>
                </div>

                <p>Vous serons ensuite affiché toute les formulations inférieur à ce seuil</p>

                <div class="form-group">
                    <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                        <button type="submit" class="btn btn-default btn-primary">
                            <span class="glyphicon glyphicon-ok"></span> Ajouter
                        </button>
                        &nbsp;
                        <button type="button" class="btn btn-default btn-primary"
                                onclick="javascript:if (confirm('vous êtes sûr ?')) window.location = '{{ url('/')}}';">
                            <span class="glyphicon glyphicon-remove"></span> Annuler</button>
                    </div>
                </div>

            </div>

        </div>
        {!! Form::close() !!}
    @else
        <div class="alert alert-danger" role="alert">
            Vous n'avez pas accès à cette page. Pour y avoir accès, vous devez être connecté en tant que "Commercial".
        </div>
    @endif
@stop
