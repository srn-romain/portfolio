@extends ('layouts.master')
@section('content')
    @if(Session::get('type') === 'V')
        {!! Form::open(['url' => '/frais/postAjouterFrais']) !!}
        <div class="blanc">
            <h1 style="text-align: center">Ajouter un Frais</h1>
        </div>
        <div class="col-md-12 col-sm-12 well well-md">
            <center><h1> </h1></center>
            <div class="form-horizontal">
                <div class="form-group">
                    <label class="col-md-3 col-sm-3 control-label">Date: </label>
                    <div class="col-md-2 col-sm-2">
                        <input type="text" name="anneemois" value="" placeholder="AAAA-MM" class="form-control" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-md-3 col-sm-3 control-label">Nombre de justificatif(s): </label>
                    <div class="col-md-2 col-sm-2">
                        <input type="number" name="nbjustificatifs" value="" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                        <button type="submit" class="btn btn-default btn-primary">
                            <span class="glyphicon glyphicon-ok"></span> Ajouter
                        </button>
                        &nbsp;
                        <button type="button" class="btn btn-default btn-primary"
                                onclick="javascript:if (confirm('vous êtes sûr ?')) window.location = '{{ url('/')}}';">
                            <span class="glyphicon glyphicon-remove"></span> Annuler</button>
                    </div>
                </div>

            </div>

        </div>
        {!! Form::close() !!}
    @else
        <div class="alert alert-danger" role="alert">
            Vous n'avez pas accès à cette page. Pour y avoir accès, vous devez être connecté en tant que "Visiteur".
        </div>
    @endif
@stop
