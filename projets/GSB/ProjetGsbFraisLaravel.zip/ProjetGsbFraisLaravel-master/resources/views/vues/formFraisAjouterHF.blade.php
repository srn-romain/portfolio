@extends ('layouts.master')
@section('content')
    {!! Form::open(['url' => '/fraisHF/postAjouterFraisHF']) !!}
    <div class="blanc">
        <h1 style="text-align: center">Ajouter un Frais Hors Forfait</h1>
    </div>
    <div class="col-md-12 col-sm-12 well well-md">
        <center><h1> </h1></center>
        <div class="form-horizontal">

            <div class="form-group">
                <label class="col-md-3 col-sm-3 control-label"></label>
                <div class="col-md-2 col-sm-2">
                    <input type="hidden" name="id_frais" value="{{$unFraisHF->id_frais}}" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-3 col-sm-3 control-label">Date: </label>
                <div class="col-md-2 col-sm-2">
                    <input type="date" name="date_fraishorsforfait" value="" placeholder="AAAA-MM" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-3 col-sm-3 control-label">Montant : </label>
                <div class="col-md-2 col-sm-2">
                    <input type="number" name="montant_fraishorsforfait" value="" class="form-control">
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-3 col-sm-3 control-label">Libellé : </label>
                <div class="col-md-2 col-sm-2">
                    <input type="text" name="lib_fraishorsforfait" value="" class="form-control">
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                    <button type="submit" class="btn btn-default btn-primary">
                        <span class="glyphicon glyphicon-ok"></span> Ajouter
                    </button>
                    &nbsp;
                    <button type="button" class="btn btn-default btn-primary"
                            onclick="javascript:if (confirm('vous êtes sûr ?')) window.location = '{{ url('/')}}';">
                        <span class="glyphicon glyphicon-remove"></span> Annuler</button>
                </div>
            </div>

        </div>

    </div>
@stop
