@extends ('layouts.master')
@section('content')

    <div>
        <br><br>
        <br><br>
        <div class="container">
            <div class="blanc">
                <h1 style="text-align: center">Modification d'un Frais Hors forfait</h1>
            </div>
            {!! Form::open(array('route'=>array('postmodifierFraisHF',$unFraisHF->id_fraishorsforfait),'method'=>'post')) !!}

            <div class="col-md-12  col-sm-12 well well-md">
                <center><h1> </h1></center>
                <div class="form-horizontal">
                    <input type="hidden" name="id_frais" value="{{$unFraisHF->id_fraishorsforfait ?? 0}}"/>
                    <div class="form-group">
                        <label class="col-md-3 col-sm-3 control-label">Date : </label>
                        <div class="col-md-2 col-sm-2">
                            <input type="text" name="date" value="{{$unFraisHF->date_fraishorsforfait ?? ''}}" class="form-control" placeholder="AAAAMM" required autofocus>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 col-sm-3 control-label">Montant : </label>
                        <div class="col-md-2 col-sm-2">
                            <input type="number" name="montant" value="{{$unFraisHF->montant_fraishorsforfait ?? ''}}" class="form-control" placeholder="AAAAMM" required autofocus>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 col-sm-3 control-label">Libellé : </label>
                        <div class="col-md-2  col-sm-2">
                            <input type="text" name="lib" value="{{$unFraisHF->lib_fraishorsforfait ?? ''}}"  class="form-control" placeholder="Nombre de justificatifs" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                            <button type="submit" class="btn btn-default btn-primary">
                                <span class="glyphicon glyphicon-ok"></span>Valider
                            </button>
                            &nbsp;&nbsp;
                            <button type="submit" class="btn btn-default btn-primary" onclick="javascript:if(confirm('Vous êtes sûr ?')) window.location='{{url('/fraisHF/listerFraisHF')}}/{{$unFraisHF->id_frais}}';">
                                <span class="glyphicon glyphicon-remove"></span>Annuler</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

@stop
