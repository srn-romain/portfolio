@extends ('layouts.master')
@section('content')

    <div>
        <br><br>
        <br><br>
        <div class="container">
            <div class="blanc">
                <h1>Suppression d'un Frais Hors forfait</h1>
            </div>

            {!! Form::open(['route' => ['postSupprimerFraisHF', $unFraisHF->id_fraishorsforfait], 'method' => 'delete']) !!}
            <div class="col-md-12 col-sm-12 well well-md">
                <center><h1></h1></center>
                <div class="form-horizontal">

                    <div class="form-group">
                        <label class="col-md-3 col-sm-3 control-label">ID frais :</label>
                        <div class="col-md-2 col-sm-2">
                            <p>{{$unFraisHF->id_fraishorsforfait}}</p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 col-sm-3 control-label">Date :</label>
                        <div class="col-md-2 col-sm-2">
                            <p>{{$unFraisHF->date_fraishorsforfait}}</p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 col-sm-3 control-label">Montant associé :</label>
                        <div class="col-md-2 col-sm-2">
                            <p>{{$unFraisHF->montant_fraishorsforfait}}</p>
                        </div>
                    </div>


                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                            <button type="submit" class="btn btn-default btn-danger" onclick="javascript:if(confirm('Vous êtes sûr de vouloir supprimer ce frais ?')) return true; else return false;">
                                <span class="glyphicon glyphicon-remove"></span>Supprimer
                            </button>
                            <a href="{{ url('/') }}" class="btn btn-default btn-primary">
                                <span class="glyphicon glyphicon-arrow-left"></span>Retour</a>
                        </div>
                    </div>

                </div>
            </div>

        </div>

@stop
