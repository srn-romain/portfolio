@extends ('layouts.master')
@section('content')

    <div class="container">
        @if(Session::get('type') === 'V')
            <div class="blanc">
                <h1 style="text-align: center">Liste de mes Frais</h1>
            </div>
            <table class="table table-bordered table-striped table-responsive">
                <thead>
                <tr>
                    <th style="width: 20%">Période</th>
                    <th style="width: 20%">Nombre de justificatifs</th>
                    <th style="width: 20%">Date de modification</th>
                    <th style="width: 20%">Montant valide</th>
                    <th style="width: 10%">Modifier</th>
                    <th style="width: 10%">Supprimer</th>
                </tr>
                </thead>
                @foreach ($mesFrais as $unFrais)
                    <tr>
                        <td>{{$unFrais->anneemois}}</td>
                        <td>{{$unFrais->nbjustificatifs}}</td>
                        <td>{{$unFrais->datemodification}}</td>
                        <td>{{$unFrais->montantvalide}}</td>
                        <td style="text-align: center"><a href="{{url('/frais/modifierFrais')}}/{{$unFrais->id_frais}}">
                                <span class="glyphicon glyphicon-pencil" data-toggle="tooltip" data-placement="top" title="modifier"></span>
                        </td>
                        <td style="text-align:center; cursor: pointer" >
                            <a class="glyphicon glyphicon-remove" data-toggle="tooltip" data-placement="top" title="Supprimer"
                               onclick="{window.location='{{url('/frais/supprimerFrais')}}/{{$unFrais->id_frais}}';}">
                            </a>
                        </td>
                    </tr>
                @endforeach
            </table>
        @else
            <div class="alert alert-danger" role="alert">
                Vous n'avez pas accès à cette page. Pour y avoir accès, vous devez être connecté en tant que "Visiteur".
            </div>
        @endif
        <div class="col-md-6 col-md-offset-3">
            @include('vues/error')
        </div>
@stop
