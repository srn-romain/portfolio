@extends ('layouts.master')
@section('content')

    <div class="container">
        <div class="blanc">
            <h1 style="text-align: center">Liste de mes Frais Hors Forfait</h1>
        </div>
        <table class="table table-bordered table-striped table-responsive">
            <thead>
            <tr>
                <th style="width: 10%">Id HF</th>
                <th style="width: 10%">Id frais</th>
                <th style="width: 20%">Date</th>
                <th style="width: 20%">Montant Hors Forfais</th>
                <th style="width: 20%">libellé</th>
                <th style="width: 10%">Modifier</th>
                <th style="width: 10%">Supprimer</th>
            </tr>
            </thead>
            @foreach ($mesFraisHF as $unFrais)
                <tr style="text-align: center">
                    <td>{{$unFrais->id_fraishorsforfait}}</td>
                    <td>{{$unFrais->id_frais}}</td>
                    <td>{{$unFrais->date_fraishorsforfait}}</td>
                    <td>{{$unFrais->montant_fraishorsforfait}}</td>
                    <td>{{$unFrais->lib_fraishorsforfait}}</td>
                    <td style="text-align: center"><a href="{{url('/fraisHF/modifierFraisHF')}}/{{$unFrais->id_fraishorsforfait}}">
                            <span class="glyphicon glyphicon-pencil" data-toggle="tooltip" data-placement="top" title="modifier"></span>
                    </td>
                    <td style="text-align:center; cursor: pointer" >
                        <a class="glyphicon glyphicon-remove" data-toggle="tooltip" data-placement="top" title="Supprimer"
                           onclick="{window.location='{{url('/fraisHF/supprimerFraisHF')}}/{{$unFrais->id_fraishorsforfait}}';}">
                        </a>
                    </td>
                </tr>
            @endforeach
        </table>
        <button type="button" class="btn btn-default btn-primary"
                onclick="window.location = '{{ url('/fraisHF/ajouterFraisHF')}}/{{$id_frais}}';">
            <span class="glyphicon glyphicon-plus"></span> Ajouter un frais HF</button>
        <div class="col-md-6 col-md-offset-3">
            @include('vues/error')
        </div>
@stop

