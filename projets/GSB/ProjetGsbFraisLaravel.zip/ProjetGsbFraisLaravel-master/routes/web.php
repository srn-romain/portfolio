<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VisiteurController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('home');
});


Route::prefix('connexion')->group(function() {
    Route::get('/formLogin',[VisiteurController::class,'getLogin']);
    Route::post('/Login',[VisiteurController::class,'signIn']);
    Route::get('/getLogout',[VisiteurController::class,'signOut']);
});

Route::prefix('frais')->group(function() {
    Route::get('/listeFrais',  [\App\Http\Controllers\FraisController::class, 'getFraisVisiteur']);
    Route::get('/modifierFrais/{id}',  [\App\Http\Controllers\FraisController::class, 'updateFrais']);
    Route::post('/postmodifierFrais/{id}',
        array(
            'uses' => 'App\Http\Controllers\FraisController@postmodifierFrais',
            'as' => 'postmodifierFrais',
        )
    );
    Route::get('/ajouterFrais',  [\App\Http\Controllers\FraisController::class, 'beforeAjouterFrais']);
    Route::post('/postAjouterFrais',  [\App\Http\Controllers\FraisController::class, 'postAjouterFrais']);
    Route::get('/supprimerFrais/{id}',  [\App\Http\Controllers\FraisController::class, 'supprimerFrais']);
    Route::delete('/postSupprimerFrais/{id}', [
        'uses' => 'App\Http\Controllers\FraisController@postSupprimerFrais',
        'as' => 'postSupprimerFrais',
    ]);
});

Route::prefix('fraisHF')->group(function() {
    Route::get('/listerFraisHF/{id}',  [\App\Http\Controllers\FraisController::class, 'getFraisHF']);
    Route::get('/modifierFraisHF/{id}',  [\App\Http\Controllers\FraisController::class, 'updateFraisHF']);
    Route::post('/postmodifierFraisHF/{id}',
        array(
            'uses' => 'App\Http\Controllers\FraisController@postmodifierFraisHF',
            'as' => 'postmodifierFraisHF',
        )
    );
    Route::get('/supprimerFraisHF/{id}',  [\App\Http\Controllers\FraisController::class, 'supprimerFraisHF']);
    Route::delete('/postSupprimerFraisHF/{id}', [
        'uses' => 'App\Http\Controllers\FraisController@postSupprimerFraisHF',
        'as' => 'postSupprimerFraisHF',
    ]);
    Route::get('/ajouterFraisHF/{id_frais}',  [\App\Http\Controllers\FraisController::class, 'beforeajouterFraisHF']);
    Route::post('/postAjouterFraisHF',  [\App\Http\Controllers\FraisController::class, 'postAjouterFraisHF']);
});

/* ICI COMMENCE LES SITUATIONS PRO*/

Route::prefix('formulation')->group(function() {
    Route::get('/listeFormulation',  [\App\Http\Controllers\FormulerController::class, 'getFormulation']);
    Route::get('/ajouterFormulation',  [\App\Http\Controllers\FormulerController::class, 'beforeAjouterFormulation']);
    Route::post('/postAjouterForm',  [\App\Http\Controllers\FormulerController::class, 'postAjouterForm']);
    Route::get('/supprimerForm/{id_medicament}/{id_presentation}', [\App\Http\Controllers\FormulerController::class, 'beforeSupprimerFormulation']);
    Route::delete('/postSupprimerFormulation/{id_medicament}/{id_presentation}', [
        'uses' => 'App\Http\Controllers\FormulerController@postSupprimerFormulation',
        'as' => 'postSupprimerFormulation',
    ]);
    Route::get('/modifierForm/{id_medicament}/{id_presentation}',  [\App\Http\Controllers\FormulerController::class, 'beforeModifierFormulation']);
    Route::post('/postmodifierFormulation/{id_medicament}/{id_presentation}',
        array(
            'uses' => 'App\Http\Controllers\FormulerController@postModifierFormulation',
            'as' => 'postModifierFormulation',
        )
    );
});

Route::prefix('medicament')->group(function() {
    Route::get('/rechercheMedicament',  [\App\Http\Controllers\FormulerController::class, 'getMedicament']);
    Route::post('/rechercheMedicamentParNom',  [\App\Http\Controllers\FormulerController::class, 'getresultatParNom']);
    Route::post('/rechercheMedicamentParFamille',  [\App\Http\Controllers\FormulerController::class, 'getresultatParFamille']);
});


Route::prefix('presentation')->group(function() {
    Route::get('/listerP',  [\App\Http\Controllers\PresentationController::class, 'getPre']);
    Route::get('/ajouterPresentation',  [\App\Http\Controllers\PresentationController::class, 'beforeAjouterPre']);
    Route::post('/postAjouterPresentation',  [\App\Http\Controllers\PresentationController::class, 'postAjouterPre']);
    Route::get('/triePresentation',  [\App\Http\Controllers\PresentationController::class, 'getPageTrie']);
    Route::post('/postTriePresentation',  [\App\Http\Controllers\FormulerController::class, 'postTriePresentation']);
    Route::get('/modifierPresentation/{id_presentation}',  [\App\Http\Controllers\PresentationController::class, 'beforemodifPre']);
    Route::post('/postModifierPre/{id_presentation}/{lib_presentation}',
        array(
            'uses' => 'App\Http\Controllers\PresentationController@postModifierPresentation',
            'as' => 'postModifierPresentation',
        )
    )->name("postModifierPre");
});

