<?php

namespace Tests\Feature;

use Tests\TestCase;

class AuthentificationTest extends TestCase
{
    public function test_authentification_lorsque_pas_connecter(): void
    {
        // Utilisez la méthode get pour simuler une requête à l'URL spécifiée
        $response = $this->get('/modifierFrais/6');

        // Assurez-vous que la réponse a le statut HTTP 401 (Non autorisé)
        $response->assertStatus(401);
    }

}
