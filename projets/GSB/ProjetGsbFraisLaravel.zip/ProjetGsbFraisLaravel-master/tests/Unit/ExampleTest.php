<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\dao\serviceFormulation;

class ExampleTest extends TestCase
{
    public function testGetFormulationVisiteur()
    {
        // Création d'une instance du service de formulation
        $serviceFormulation = new serviceFormulation();

        // Appel de la méthode getFormulationVisiteur
        $formulations = $serviceFormulation->getFormulationVisiteur();

        // Assertion pour vérifier que les formulations sont récupérées avec succès
        $this->assertNotNull($formulations);
        // $this->assertNotEmpty($formulations);
    }

    /**
     * Test de la méthode ajoutForm
     *
     * @return void
     */

    /*public function test_that_true_is_true(): void
    {
        $this->assertTrue(true);
    }*/
}
