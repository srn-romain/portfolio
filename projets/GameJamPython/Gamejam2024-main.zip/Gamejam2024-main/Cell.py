from Consumable import Consumable
# on définit une classe cellule, aux propriétés numériques x, y et aux propriétés booléennes visited, top, bottom, left, right
class Cell:
    def __init__(self, x, y, index):
        self.x = x
        self.y = y
        self.index = index
        self.end = False
        self.start = False
        self.visited = False
        self.top = True
        self.bottom = True
        self.left = True
        self.right = True
        self.consumable = None

    @classmethod
    def fromJSON(cls, data):

        obj = cls.__new__(cls)

        obj.x = data['x']
        obj.y = data['y']
        obj.index = 0
        obj.end = data['end']
        obj.start = data['start']
        obj.visited = False
        obj.top = data['top']
        obj.bottom = data['bottom']
        obj.left = data['left']
        obj.right = data['right']
        # Assurez-vous que la conversion des consommables est correcte
        obj.consumable = Consumable.fromJSON(data['consumable']) if data['consumable'] else None
        return obj

    # méthode qui retourne la tuile à utiliser
    def getTileType(self):
        if self.right and self.bottom and self.left:
            # tuile en U +0°
            return 1
        elif self.bottom and self.left and self.top:
            # tuile en U +90°
            return 2
        elif self.left and self.top and self.right:
            # tuile en U +180°
            return 3
        elif self.top and self.right and self.bottom:
            # tuile en U +270°
            return 4
        elif self.bottom and self.left:
            # tuile en L +0°
            return 5
        elif self.left and self.top:
            # tuile en L +90°
            return 6
        elif self.top and self.right:
            # tuile en L +180°
            return 7
        elif self.right and self.bottom:
            # tuile en L +270°
            return 8
        elif self.right and self.left:
            # tuile en I +0°
            return 9
        elif self.top and self.bottom:
            # tuile en I +90°
            return 10
        elif self.top:
            # mur haut
            return 11
        elif self.right:
            # mur droit
            return 12
        elif self.bottom:
            # mur bas
            return 13
        elif self.left:
            # mur gauche
            return 14
        elif not self.top and not self.right and not self.bottom and not self.left:
            # tuile vide
            return 15
        else:
            # on affiche la cellule pour comprendre l'erreur
            print(self.index, self.x, self.y, self.top, self.bottom, self.left, self.right)
            return '0'
        
    def to_dict(self):
        return {
            'x': self.x,
            'y': self.y,
            'end': self.end,
            'start': self.start,
            'top': self.top,
            'bottom': self.bottom,
            'left': self.left,
            'right': self.right,
            'consumable': self.consumable.to_dict() if self.consumable else None
        }
    
    def toJSON(self):
        return {
            'x': self.x,
            'y': self.y,
            'index': self.index,
            'end': self.end,
            'start': self.start,
            'visited': self.visited,
            'top': self.top,
            'bottom': self.bottom,
            'left': self.left,
            'right': self.right,
            'consumable': self.consumable.toJSON() if self.consumable else None
        }