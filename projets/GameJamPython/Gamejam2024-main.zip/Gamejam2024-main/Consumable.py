import pygame

# on définit une consommable
class Consumable:
    def __init__(self, type):
        self.type = type
        self.consumed = False

    @classmethod
    def fromJSON(cls, data):

        obj = cls.__new__(cls)

        obj.type = data['type']
        obj.consumed = False
        return obj

    def getTile(self, hidden=False):
        if hidden:
            return 51
        elif self.type == "boost":
            return 52
        elif self.type == "teleport":
            return 53
        
    def consume(self, target):
        if not self.consumed:
            if self.type == "boost":
                if not target.isBoosted:
                    self.consumed = True
                    target.boost()
            elif self.type == "teleport":
                self.consumed = True
                target.teleport()

    def to_dict(self):
        return {
            'type': self.type
        }