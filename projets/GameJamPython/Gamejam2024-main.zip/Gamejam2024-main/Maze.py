import random
import os
import json
from collections import deque
import xml.etree.ElementTree as ET
from Cell import Cell
from Consumable import Consumable


#on définit une classe labyrinthe, aux propriétés numériques width et height, et à la propriété liste de cellules
class Maze:
    #constructeur
    def __init__(self, width, height, tile_size, mode='fusion', distanceCap=-1, consumables=True):
        self.width = width
        self.height = height
        self.tile_size = tile_size
        self.cells = []
        self.end = []
        self.start = []
        path = []
        self.distance = distanceCap
        # un nombre aléatoire entre 0 et 11
        self.artifact = random.randint(0, 11)
        # choix aléatoire parmi stone, sand, grass, dirt
        self.wallsTexture = random.choice(['stone', 'sand', 'grass', 'dirt'])
        self.groundTexture = random.choice(['stone', 'sand', 'grass', 'dirt'])
        for i in range(height):
            for j in range(width):
                self.cells.append(Cell(j, i, i*width+j))
        if mode == 'fusion':
            self.generateFusion()
        else:
            self.generateExhaustive()

        # on définit la cellule de départ
        self.defineStart()

        # on ajoute ou non les consommables
        if consumables:
            self.addConsumables()

        # on enregistre dans un fichier map.json
        with open('map.json', 'w') as file:
            json.dump(self.toJSON(), file, indent=4)

    @classmethod
    def fromJSON(cls, data):
        obj = cls.__new__(cls)
        obj.width = data['width']
        obj.height = data['height']
        obj.tile_size = data['tile_size']
        obj.distance = data['distanceCap']
        obj.artifact = data['artifact']
        obj.wallsTexture = data['wallsTexture']
        obj.groundTexture = data['groundTexture']
        obj.start = data['start']
        obj.end = data['end']
        obj.cells = [Cell.fromJSON(cell_data) for cell_data in data['cells']]
        # on remplit self.path, avec les cellules de self.cells aux coordonnées présentes dans data['path']
        obj.path = [obj.getCell(cell_data[0], cell_data[1]) for cell_data in data['path']]
        return obj

    # méthode qui retourne la cellule à partir de ses coordonnées
    def getCell(self, x, y):
        if 0 <= x < self.width and 0 <= y < self.height:
            return next((cell for cell in self.cells if cell.x == x and cell.y == y), None)
        else:
            return None  # Ou gérer le cas hors limites de manière appropriée
    
    # méthode qui retourne la liste des voisines d'une cellule
    def getNeighbors(self, cell):
        neighbors = []
        if cell:
            if cell.x > 0:
                neighbors.append(self.getCell(cell.x-1, cell.y))
            if cell.x < self.width-1:
                neighbors.append(self.getCell(cell.x+1, cell.y))
            if cell.y > 0:
                neighbors.append(self.getCell(cell.x, cell.y-1))
            if cell.y < self.height-1:
                neighbors.append(self.getCell(cell.x, cell.y+1))
        return neighbors
    
    # méthode qui retourne la liste des cellules voisines non visitées d'une cellule
    def getNeighborUnvisitedCells(self, cell):
        neighbors = self.getNeighbors(cell)
        unvisitedNeighbors = []
        for neighbor in neighbors:
            if not neighbor.visited:
                unvisitedNeighbors.append(neighbor)
        return unvisitedNeighbors
    
    # méthode qui retourne la liste des voisines d'index différents d'une cellule
    def getDifferentIndexNeighbors(self, cell):
        neighbors = self.getNeighbors(cell)
        differentIndexNeighbors = []
        for neighbor in neighbors:
            if neighbor.index != cell.index:
                differentIndexNeighbors.append(neighbor)
        return differentIndexNeighbors
    
    # méthode qui retourne la liste des voisines accessibles d'une cellule (sans mur)
    def getAccessibleNeighbors(self, cell):
        neighbors = self.getNeighbors(cell)
        accessibleNeighbors = []
        for neighbor in neighbors:
            # Vérification des murs pour chaque direction
            if not cell.left and neighbor.x == cell.x - 1:
                accessibleNeighbors.append(neighbor)
            elif not cell.right and neighbor.x == cell.x + 1:
                accessibleNeighbors.append(neighbor)
            elif not cell.top and neighbor.y == cell.y - 1:
                accessibleNeighbors.append(neighbor)
            elif not cell.bottom and neighbor.y == cell.y + 1:
                accessibleNeighbors.append(neighbor)
        return accessibleNeighbors
    
    # méthode qui ouvre le mur entre deux cellules
    def openWall(self, cell1, cell2):
        # on ouvre le mur entre les deux cellules
        if cell2.x > cell1.x:
            cell2.left = False
            cell1.right = False
        elif cell2.x < cell1.x:
            cell2.right = False
            cell1.left = False
        elif cell2.y > cell1.y:
            cell2.top = False
            cell1.bottom = False
        elif cell2.y < cell1.y:
            cell2.bottom = False
            cell1.top = False

    # méthode qui retourne le nombre d'index différents de 0 dans le labyrinthe
    def getIndexCount(self):
        count = 0
        for cell in self.cells:
            if cell.index != 0:
                count += 1
        return count
    
    # méthode qui propage un index à toutes les cellules de même index
    def propagateIndex(self, targetIndex, newIndex):
        for cell in self.cells:
            if cell.index == targetIndex:
                cell.index = newIndex

    # méthode qui définit la disposition de murs du labyrinthe par exploration exhaustive
    def generateExhaustive(self):
        # on se place sur une case aléatoire du labyrinthe
        currentCell = self.getCell(random.randint(0, self.width-1), random.randint(0, self.height-1))

        # on marque la case comme visitée et case de fin
        currentCell.visited = True
        currentCell.end = True
            
        # on sauvegarde la cellule visitée dans une pile
        stack = [currentCell]
        self.end = [currentCell.x, currentCell.y]


        while stack:
            # on récupère une cellule aléatoirement parmis les cellules voisines non visitées
            neighbors = self.getNeighborUnvisitedCells(currentCell)
            # si il y a des voisins non visités, on en sélectionne un au hasard
            if neighbors:
                nextCell = random.choice(neighbors)
                nextCell.visited = True

                # on ouvre le mur entre les deux cellules
                self.openWall(currentCell, nextCell)

                # on sauvegarde la nouvelle cellule dans la pile
                stack.append(nextCell)
                # on met à jour la cellule courante
                currentCell = nextCell
            else:
                # on dépile la pile pour revenir en arrière
                currentCell = stack.pop()

    # méthode qui définit la disposition de murs du labyrinthe par fusion des chemins
    def generateFusion(self):
        first = True
        counter = 0
        while self.getIndexCount() > 0:
            # on se place sur une case aléatoire du labyrinthe
            currentCell = self.getCell(random.randint(0, self.width-1), random.randint(0, self.height-1))
            if first:
                currentCell.end = True
                self.end = [currentCell.x, currentCell.y]
                first = False
            neighbors = self.getDifferentIndexNeighbors(currentCell)

            # s'il y a des voisins d'index différents, on en sélectionne un au hasard
            if neighbors:
                nextCell = random.choice(neighbors)
                # on ouvre le mur entre les deux cellules
                self.openWall(currentCell, nextCell)
                # on affecte l'index le plus petit à la cellule qui a le plus grand
                if nextCell.index < currentCell.index:
                    # on affecte l'index de nextCell à toutes les cellules de même index que currentCell
                    self.propagateIndex(currentCell.index, nextCell.index)
                elif nextCell.index > currentCell.index:
                    # on affecte l'index de currentCell à toutes les cellules de même index que nextCell
                    self.propagateIndex(nextCell.index, currentCell.index)

    # méthode qui renvoie la case la plus éloignée de la case de fin (en suivant les chemins, pas à vol d'oiseau)
    def getFurthestCell(self, start):
        # on marque toutes les cellules comme non visitées
        for cell in self.cells:
            cell.visited = False

        # on initialise une file avec notre première case
        queue = deque([(start,0,[])])

        # on marque la case de départ comme visitée
        start.visited = True

        # on initialise la case la plus éloignée à la case de départ
        furthestCell = start
        maxDistance = 0
        path = [start]

        # si on a exploré toutes les possibilités ou qu'on a atteint le cap de distance, on arrête
        while queue and maxDistance != self.distance:
            currentCell, distance, currentPath = queue.popleft() 

            # si on trouve un cellule plus éloignées, on met à jour la variable
            if distance > maxDistance:
                furthestCell = currentCell
                maxDistance = distance
                path = currentPath

            # on récupère les voisins non visités et accessibles (pas de mur)
            neighbors = self.getAccessibleNeighbors(currentCell)
            for neighbor in neighbors:
                if not neighbor.visited:
                    neighbor.visited = True
                    queue.append((neighbor, distance+1, currentPath + [neighbor]))

        return furthestCell, maxDistance, path

    # méthode qui renvoie toutes les cellules à une distance définie d'une certaine cellule (en suivant les chemins, pas à vol d'oiseau)
    def getCellsByDistance(self, origin, minDist, maxDist):
        # on marque toutes les cellules comme non visitées
        for cell in self.cells:
            cell.visited = False

        # on marque la case de départ comme visitée
        origin.visited = True

        # on initialise la liste des cellules à la distance voulue
        cells = []

        # on initialise une file avec notre première case
        queue = deque([(origin,0)])

        # si on a exploré toutes les possibilités, on arrête
        while queue:
            currentCell, currentDistance = queue.popleft()

            # si on trouve une cellule à la distance voulue, on l'ajoute à la liste
            if currentDistance != 0 and currentDistance >= minDist and currentDistance <= maxDist:
                cells.append(currentCell)

            # on récupère les voisins non visités et accessibles (pas de mur)
            neighbors = self.getAccessibleNeighbors(currentCell)
            for neighbor in neighbors:
                if not neighbor.visited:
                    neighbor.visited = True
                    queue.append((neighbor, currentDistance+1))

        return cells

    # méthode qui renvoie la distance entre deux cellules (en suivant les chemins, pas à vol d'oiseau)
    def getDistance(self, cell1, cell2):
        # on marque toutes les cellules comme non visitées
        for cell in self.cells:
            cell.visited = False

        # on marque la case de départ comme visitée
        cell1.visited = True
            
        # on initialise une file avec notre première case
        queue = deque([(cell1,0)])

        # si on a exploré toutes les possibilités, on arrête
        while queue:
            currentCell, currentDistance = queue.popleft()

            # si on trouve la cellule d'arrivée, on renvoie la distance
            if currentCell == cell2:
                return currentDistance

            # on récupère les voisins non visités et accessibles (pas de mur)
            neighbors = self.getAccessibleNeighbors(currentCell)
            for neighbor in neighbors:
                if not neighbor.visited:
                    neighbor.visited = True
                    queue.append((neighbor, currentDistance+1))

        return -1

    # méthode qui définit la cellule de départ
    def defineStart(self):
        # on cherche la case la plus éloignée de la fin pour en faire la case de départ
        endCell = self.getCell(self.end[0], self.end[1])
        print('end ',self.end)
        startCell, distance, path = self.getFurthestCell(endCell)
        startCell.start = True
        self.start = [startCell.x, startCell.y]
        self.path = path
        print('start ',self.start)
        self.distance = distance
        print('distance ',self.distance)

    # méthode qui renvoie les cellules autour d'une liste de cellules
    def getCellsAround(self, cells, min, max):
        cellsAround = set()
        # on ajoute toutes les cellules à moins de MAX d'écart
        for pathCell in self.path:
            cells = self.getCellsByDistance(pathCell, min, max)
            cellsAround.update(cells)

        # on supprime toutes les cellules à moins de MIN d'écart
        for pathCell in self.path:
            cells = self.getCellsByDistance(pathCell, 0, min-1)
            cellsAround.difference_update(cells)
        return cellsAround
    
    def toJSON(self):
        return {
            'width': self.width,
            'height': self.height,
            'tile_size': self.tile_size,
            'distanceCap': self.distance,
            'artifact': self.artifact,
            'wallsTexture': self.wallsTexture,
            'groundTexture': self.groundTexture,
            'start': self.start,
            'end': self.end,
            'path': [[cell.x, cell.y] for cell in self.path],
            'cells': [cell.to_dict() for cell in self.cells]
        }
    
    def to_dict(self):
        return {
            'width': self.width,
            'height': self.height,
            'start': self.start,
            'end': self.end,
            'cells': [
                {
                    'x': cell.x,
                    'y': cell.y,
                    'top': cell.top,
                    'bottom': cell.bottom,
                    'left': cell.left,
                    'right': cell.right,
                    'consumable': cell.consumable.to_dict() if cell.consumable else None
                } for cell in self.cells
            ]
        }

    @classmethod
    def from_dict(cls, data):
        maze = cls(data['width'], data['height'])
        maze.start = data['start']
        maze.end = data['end']
        for i, cell_data in enumerate(data['cells']):
            cell = maze.cells[i]
            cell.x = cell_data['x']
            cell.y = cell_data['y']
            cell.top = cell_data['top']
            cell.bottom = cell_data['bottom']
            cell.left = cell_data['left']
            cell.right = cell_data['right']
            if cell_data['consumable']:
                cell.consumable = Consumable(cell_data['consumable']['type'])
                cell.consumable.consumed = cell_data['consumable']['consumed']
            else:
                cell.consumable = None
        return maze
                    # --------------------------------------------- Consumable ---------------------------------------------

    # méthode qui ajoute des consommables dans le labyrinthe
    def addConsumables(self):
        print('consumables début')
        consumableEligible = self.getCellsAround(self.path, 3, 6)        
        # filtrer consumableEligible pour ne garder que les cellules qui sont des cul de sac
        consumableEligible = [cell for cell in consumableEligible if len(self.getAccessibleNeighbors(cell)) == 1]
        print('consumables filtrage nrv')
        
        # filtrer consumableEligible pour ne pas avoir de consommables trop proches des autres cases de la liste
        consumableEligible = [cell for cell in consumableEligible if all(self.getDistance(cell, other) > 3 for other in consumableEligible if other != cell)]
        for cell in consumableEligible:
            cell.consumable = Consumable("boost")
        print('consumables entre deux')
        consumableEligible = self.getCellsAround(self.path, 7, 50)        
        # filtrer consumableEligible pour ne garder que les cellules qui sont des cul de sac
        consumableEligible = [cell for cell in consumableEligible if len(self.getAccessibleNeighbors(cell)) == 1]
        print('consumables filtrage nrv')
        # filtrer consumableEligible pour ne pas avoir de consommables trop proches des autres cases de la liste
        consumableEligible = [cell for cell in consumableEligible if all(self.getDistance(cell, other) > 5 for other in consumableEligible if other != cell)]
        for cell in consumableEligible:
            cell.consumable = Consumable("teleport")
        print('consumables fin')

    # méthode qui vérifie s'il y a un mur aux coordonnées données
    def isWall(self, oldRect, newRect):
        # on récupère les cellules correspondantes
        newCell = self.getCell(newRect.x // self.tile_size, newRect.y // self.tile_size)
        if newCell == None:
            return True
        oldCell = self.getCell(oldRect.x // self.tile_size, oldRect.y // self.tile_size)
        # si il y a un mur entre les 2 cellules
        if newCell.x > oldCell.x and oldCell.right:
            return True
        if newCell.x < oldCell.x and oldCell.left:
            return True
        if newCell.y > oldCell.y and oldCell.bottom:
            return True
        if newCell.y < oldCell.y and oldCell.top:
            return True
        topLeftInCell = (newRect.x % self.tile_size, newRect.y % self.tile_size)
        minInCell = int(8 / 64 * self.tile_size)
        maxInCell = int((64 - 8) / 64 * self.tile_size)
        left = topLeftInCell[0] < minInCell
        top = topLeftInCell[1] < minInCell
        right = topLeftInCell[0] + newRect.width > maxInCell
        bottom = topLeftInCell[1] + newRect.height > maxInCell
        if (left and top) or (right and top) or (left and bottom) or (right and bottom):
            return True
        elif (newCell.left and left) or (newCell.right and right) or (newCell.top and top) or (newCell.bottom and bottom):
            return True
        else:
            return False

    def getTMX(self):
        map_element = ET.Element('map', version="1.0", orientation="orthogonal", renderorder="right-down", width=str(self.width), height=str(self.height), tilewidth=str(self.tile_size), tileheight=str(self.tile_size), nextlayerid="1", nextobjectid="1")

        # on définit nos ensembles de tuiles
        ground_tileset_element = ET.SubElement(map_element, 'tileset', firstgid="21", source="images/ground/ground_"+self.groundTexture+".tsx")
        others_tileset_element = ET.SubElement(map_element, 'tileset', firstgid="31", source="images/others.tsx")
        cons_tileset_element = ET.SubElement(map_element, 'tileset', firstgid="51", source="images/consumables.tsx")
        walls_tileset_element = ET.SubElement(map_element, 'tileset', firstgid="1", source="images/walls/walls_"+self.wallsTexture+".tsx")

        # on définit nos calques
        ground_layer_element = ET.SubElement(map_element, "layer", id="1", name="ground", width=str(self.width), height=str(self.height))
        others_layer_element = ET.SubElement(map_element, "layer", id="2", name="others", width=str(self.width), height=str(self.height))
        walls_layer_element = ET.SubElement(map_element, "layer", id="3", name="walls", width=str(self.width), height=str(self.height))
        cons_object_element = ET.SubElement(map_element, "objectgroup", id="1", name="consumables")
        ground_data_element = ET.SubElement(ground_layer_element, "data", encoding="csv")
        others_data_element = ET.SubElement(others_layer_element, "data", encoding="csv")
        walls_data_element = ET.SubElement(walls_layer_element, "data", encoding="csv")
        ground_map_data = []
        others_map_data = []
        walls_map_data = []

        for i in range(self.height):
            ground_row_data = []
            others_row_data = []
            walls_row_data = []
            for j in range(self.width):
                cell = self.getCell(j, i)
                wall_type = cell.getTileType()
                if cell.start:
                    other = 31
                elif cell.end:
                    other = 32 + self.artifact
                else:
                    other = 0
                if cell.consumable:
                    gid = cell.consumable.getTile()
                    x = cell.x * self.tile_size
                    y = cell.y * self.tile_size + self.tile_size
                    ET.SubElement(cons_object_element, "object", gid=str(gid), x=str(x), y=str(y), width=str(self.tile_size), height=str(self.tile_size))
                ground = 21
                ground_row_data.append(str(ground))
                others_row_data.append(str(other))
                walls_row_data.append(str(wall_type))
            ground_map_data.append(",".join(ground_row_data))
            others_map_data.append(",".join(others_row_data))
            walls_map_data.append(",".join(walls_row_data))
        ground_data_element.text = ",\n".join(ground_map_data)
        others_data_element.text = ",\n".join(others_map_data)
        walls_data_element.text = ",\n".join(walls_map_data)
        tree = ET.ElementTree(map_element)
        map_path = os.path.join('.', "map.tmx")
        tree.write(map_path, encoding="UTF-8", xml_declaration=True)
        return map_path

# --------------------------------------------- Consumable ---------------------------------------------

class Consumable:
    def __init__(self, type):
        self.type = type
        self.consumed = False  # Initialiser l'attribut consumed

    def to_dict(self):
        return {
            'type': self.type,
            'consumed': self.consumed  # Inclure l'attribut consumed dans la sérialisation
        }

    def getTile(self):
        if self.type == "boost":
            return 41
        elif self.type == "teleport":
            return 41
        else:
            return 0

    def consume(self, player):
        if not self.consumed:
            self.consumed = True
            if self.type == "boost":
                player.boost()
            elif self.type == "teleport":
                player.teleport()

    
    def toJSON(self):
        return {
            'width': self.width,
            'height': self.height,
            'tile_size': self.tile_size,
            'distanceCap': self.distance,
            'artifact': self.artifact,
            'wallsTexture': self.wallsTexture,
            'groundTexture': self.groundTexture,
            'start': self.start,
            'end': self.end,
            'path': [[cell.x, cell.y] for cell in self.path],
            'cells': [cell.to_dict() for cell in self.cells]
        }

