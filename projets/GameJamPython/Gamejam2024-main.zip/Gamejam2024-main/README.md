# Bienvenue sur notre jeu EXPLORACE de la Gamejam 2024

## 📖 **Notre histoire...**

**Explorace** est un jeu de labyrinthe en réseau où deux joueurs en réseau incarnent un chevalier ou un sorcier et s'affrontent pour retrouver des reliques magiques dans un labyrinthe en constante évolution. Chaque partie dure 2 minutes, durant lesquelles vous pouvez amasser des bonus puis trouver la relique magique pour remporter la victoire. Avec un savant mélange de stratégie, magie et aventure, le jeu promet une expérience intense et haletante. Il suffit de se munir de son adresse IP pour jouer, et des mises à jour futures pourraient permettre à plus de deux joueurs de rejoindre la partie !

## 🛠️ **Installation**

Pour exécuter le jeu localement :

1. **Installez** les dépendances requises à partir du fichier `requirements.txt` :
   ```bash
   pip install -r requirements.txt
   ```
2. **Lancez le serveur** en exécutant la commande suivante (remplacez `[IP]` si nécessaire) :
   ```bash
   python game_serveur.py [IP à forcer sur le serveur si plusieurs IP]
   ```
3. **Lancez un ou plusieurs clients** en exécutant la commande suivante dans d'autres terminaux (utilisez l'IP affichée dans la console du serveur) :
   ```bash
   python game_client.py [IP dans la console du serveur]
   ```

## 👥 **Notre équipe...**

**Explorace** est un projet développé en seulement 9 jours lors de la Gamejam 2024 par notre équipe : **GetRect() Studio**.

- **Développement :**  
  EL YANDOUZI Sami, MILLE Virgile, PERBET Lucas, SIEURIN Romain, VINCENT Theo
- **Bande originale :** Arthus
- **Ressources complémentaires :**
  - **Images de fond des menus :** [Microsoft Designer](https://designer.microsoft.com/image-creator)
  - **Logique de modélisation du labyrinthe :** [Modélisation mathématique du labyrinthe](https://fr.wikipedia.org/wiki/Modélisation_mathématique_d'un_labyrinthe)
  - **Sprites des Artéfacts :** [CraftPix](https://craftpix.net/file-licenses/)
  - **Sprites des Sorciers et Chevaliers :** [OpenGameArt LPC Medieval Fantasy](https://opengameart.org/content/lpc-medieval-fantasy-character-sprites)

## 🎮 **Comment jouer**

- Utilisez les touches fléchées pour déplacer votre personnage dans le labyrinthe.
- Collectez des bonus pour augmenter votre vitesse ou encore vous téléporter dans le labyrinthe.
- Objectif : Trouvez les reliques magiques avant la fin du compte à rebours pour remporter la victoire.
- Chaque partie dure 2 minutes, mais le labyrinthe change à chaque fois ! Bon courage, vous en aurez besoin...

## 💻 **Contributions**

Nous acceptons les contributions pour améliorer le jeu ! N'hésitez pas à créer une branche, soumettre des pull requests, ou simplement à nous laisser des commentaires.

---

&copy; 2024 GetRect() Studio - Tous droits réservés
