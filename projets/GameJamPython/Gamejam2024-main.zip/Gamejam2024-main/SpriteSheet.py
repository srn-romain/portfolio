import pygame

class SpriteSheet:
    def __init__(self, image):
        self.sheet = image

    def get_image(self, frame, width, height, scale, color_key=None):
        image = pygame.Surface((width, height) , pygame.SRCALPHA) # Mettre en transparence les images collectées
        image.blit(self.sheet, (0, 0), (frame * width, 0, width, height))
        if color_key is not None:
            image.set_colorkey(color_key)
        image = pygame.transform.scale(image, (width * scale, height * scale))
        return image
