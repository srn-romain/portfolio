import sys
import pygame
import socket 
import time 
# Classe qui gère l'écran d'accueil lorsqu'on lance le jeu
class Accueil:
    def __init__(self, screen, server_ip):
        pygame.init()
        self.server_ip = server_ip
        self.screen = screen
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 30)
        self.jeu_lance = False  # Variable pour suivre si le jeu est lancé ou non

        # Écran d'accueil
        self.ecran_du_debut = False
        self.ecran_histoire = True
        

        # Charger image
        self.image_accueil = pygame.image.load('images/accueil_image.jpg')
        self.image_accueil = pygame.transform.scale(self.image_accueil, (self.screen.get_width(), self.screen.get_height()))
        self.image_credits = pygame.image.load('images/background_credit.png')
        self.image_credits = pygame.transform.scale(self.image_credits, (self.screen.get_width(), self.screen.get_height()))
        self.image_regle = pygame.image.load('images/background_regle.png')
        self.image_regle = pygame.transform.scale(self.image_regle, (self.screen.get_width(), self.screen.get_height()))
        self.image_back = pygame.image.load('images/back.png')
        self.image_back = pygame.transform.scale(self.image_back, (128, 64))
        self.image_sorcier = pygame.image.load('images/sorcier.png')
        self.image_sorcier = pygame.transform.scale(self.image_sorcier, (262, 420))
        self.image_chevalier = pygame.image.load('images/chevalier.png')
        self.image_chevalier = pygame.transform.scale(self.image_chevalier, (262, 420))
        self.image_bouton = pygame.image.load('images/button.png')
        self.image_histoire1 = pygame.image.load('images/1ok.jpeg')
        self.image_histoire2 = pygame.image.load('images/2ok.png')
        self.image_histoire3 = pygame.image.load('images/3ok.png')
        
        # Charger l'image du curseur personnalisé
        self.cursor_image = pygame.image.load('images/cursor.png').convert_alpha()
        pygame.mouse.set_visible(False)  # Cacher le curseur par défaut

        #création rectangle semi-transparent
        self.couleur_rect = (0, 0, 0)
        self.transparence = 180  # Niv de transparence
        self.rect_surface = pygame.Surface((self.screen.get_width() - 100, self.screen.get_height() - 200))  # Taille plus petite que l'écran
        self.rect_surface.set_alpha(self.transparence)  # Appliquer transparence
        self.rect_surface.fill(self.couleur_rect)  # Remplir avec la couleur noire

        # Création rectangle
        self.boutons = {
            "jouer": pygame.Rect(self.screen.get_width() // 2 - 100, 350, 250, 50),
            "regles": pygame.Rect(self.screen.get_width() // 2 - 100, 420, 250, 50),
            "credits": pygame.Rect(self.screen.get_width() // 2 - 100, 490, 250, 50),
            "quitter": pygame.Rect(self.screen.get_width() // 2 - 100, 560, 250, 50)
        }

    def afficher_histoire(self):
        images_histoire = [self.image_histoire1, self.image_histoire2, self.image_histoire3]
        index_image = 0  # Index de l'image actuellement affichée

        while self.ecran_histoire:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                    
                if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                    # Passer à l'image suivante si la touche est pressée ou la souris est cliquée
                    index_image += 1
                    if index_image >= len(images_histoire):
                        # Si toutes les images ont été affichées, fermer l'écran d'histoire
                        self.ecran_du_debut = True
                        self.ecran_histoire = False
                        return
                        

                self.screen.blit(images_histoire[index_image], (0, 0))
                pygame.display.update()



        
        
    def demarrer_jeu(self):
        server_port = 5555
        try:
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.connect((self.server_ip, server_port))
            player_id = int(client_socket.recv(1024).decode('utf-8'))
            print(f"[DEBUG] Connected to server with player ID: {player_id}")
            self.ecran_du_debut = False  # Fermer l'écran d'accueil
            return client_socket, player_id
        except (socket.timeout, OSError) as e:
            print(f"[ERROR] Unable to connect to server: {e}")
            return None, None

    def afficher_ecran_d_accueil(self):
        clignote = False  # Variable pour gérer l'état de clignotement
        last_blink_time = time.time()  # Gérer le timing pour le clignotement

        while self.ecran_du_debut:                       
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                #EVENEMENT SOURIS
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if self.boutons["jouer"].collidepoint(event.pos):
                        print("Démarrer le jeu")
                        client_socket, player_id = self.demarrer_jeu()
                        if client_socket:
                            return client_socket, player_id
                    elif self.boutons["regles"].collidepoint(event.pos):
                        print("Afficher les regles")
                        self.afficher_regle()
                    elif self.boutons["credits"].collidepoint(event.pos):
                        print("Afficher les credits")
                        self.afficher_credits()
                    elif self.boutons["quitter"].collidepoint(event.pos):
                        pygame.quit()
                        sys.exit()

                #EVENEMENT CLAVIER
                if event.type == pygame.KEYDOWN:
                    keys = pygame.key.get_pressed()
                    if keys[pygame.K_LCTRL] or keys[pygame.K_RCTRL]:  # Vérif des touches Ctrl
                        if event.key == pygame.K_r:
                            print("Afficher les règles via Ctrl + R")
                            self.afficher_regle()
                        elif event.key == pygame.K_c:
                            print("Afficher les crédits via Ctrl + C")
                            self.afficher_credits()
                        elif event.key == pygame.K_q:
                            print("Quitter via Ctrl + Q")
                            pygame.quit()
                            sys.exit()        

            #clignotement
            if time.time() - last_blink_time > 1.5: # temps alternernance visible/invisible
                clignote = not clignote
                last_blink_time = time.time()            

            # Affichage principiale
            self.screen.blit(self.image_accueil, (0, 0))

            rect_pos = (50, 100)
            self.screen.blit(self.rect_surface, rect_pos)

            font_titre = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 43)
            titre_text = "EXPLORACE"
            titre_surface = font_titre.render(titre_text, True, (255, 255, 255))
            titre_rect = titre_surface.get_rect(center=(self.screen.get_width() // 2, rect_pos[1] + 47))

            self.screen.blit(titre_surface, titre_rect)

            # Calculer les positions des boutons
            rect_width = self.rect_surface.get_width()
            rect_height = self.rect_surface.get_height()
            bouton_width = 250 
            bouton_height = 50
            espace_total = rect_height - (titre_rect.bottom - rect_pos[1])  # Espace total disponible pour les boutons
            espace_entre_boutons = (espace_total - 4 * bouton_height) // 5  # Espace entre chaque bouton

            # Positionner les boutons
            positions_boutons = []
            y_position = titre_rect.bottom + espace_entre_boutons
            for nom in ["jouer", "regles", "credits", "quitter"]:
                bouton_rect = pygame.Rect(rect_pos[0] + (rect_width - bouton_width) // 2, y_position, bouton_width, bouton_height)
                self.boutons[nom] = bouton_rect
                y_position += bouton_height + espace_entre_boutons

            # Affichage des boutons
            self.afficher_bouton("jouer", "Jouer")
            self.afficher_bouton("regles", "Règles")
            self.afficher_bouton("credits", "Crédits")
            self.afficher_bouton("quitter", "Quitter")

            # Affichage du texte clignotant sous chaque bouton
            if clignote:  # Afficher seulement quand clignote est True
                self.afficher_texte_clignotant()

            # Affichage personnage
            sorcier_x = 80
            sorcier_y = self.screen.get_height() - self.image_sorcier.get_height() - 180
            self.screen.blit(self.image_sorcier, (sorcier_x, sorcier_y))

            chevalier_x = self.screen.get_width() - self.image_chevalier.get_width() - 80
            chevalier_y = self.screen.get_height() - self.image_chevalier.get_height() - 180
            self.screen.blit(self.image_chevalier, (chevalier_x, chevalier_y))
            
            # Obtenir la position actuelle de la souris
            mouse_x, mouse_y = pygame.mouse.get_pos()
            # Dessiner l'image du curseur à la position de la souris
            self.screen.blit(self.cursor_image, (mouse_x, mouse_y))
            
            pygame.display.update()

            

    def afficher_bouton(self, nom, texte):
        # Charger et redimensionner l'image du bouton
        bouton_image = pygame.transform.scale(self.image_bouton, (250, 50))
        bouton_rect = self.boutons[nom]
        self.screen.blit(bouton_image, bouton_rect)

        # Choisir la police pour le texte
        font = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 30)

        # Créer la surface du texte
        texte_surface = font.render(texte, True, (255, 255, 255))

        # Centrer le texte par rapport au bouton
        texte_rect = texte_surface.get_rect(center=bouton_rect.center)

        # Afficher le texte sur le bouton
        self.screen.blit(texte_surface, texte_rect)

    def afficher_credits(self):
        credits_running = True
        font_credits = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 18)  # Police crédits
        font_liens = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 10)  # Police liens
        couleur_liens = (100, 200, 255)  #couleur liens

        #création rectangle semi-transparent
        couleur_rect = (0, 0, 0)
        transparence = 180  # Niv de transparence
        rect_surface = pygame.Surface((self.screen.get_width() - 100, self.screen.get_height() - 200))
        rect_surface.set_alpha(transparence)  # Appliquer transparence
        rect_surface.fill(couleur_rect)  # Remplir avec la couleur noire

        rect_pos = (50, 100)
        font_titre = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 43)
        titre_text = "EXPLORACE - CREDITS"
        titre_surface = font_titre.render(titre_text, True, (255, 255, 255))  # Rendu du texte en blanc
        titre_rect = titre_surface.get_rect(center=(self.screen.get_width() // 2, rect_pos[1] + 50)) 
        
        credits = [
            "Nom d'équipe : GetRect() Studio",
            "Développement :",
            "EL YANDOUZI Sami",
            "MILLE Virgile",
            "PERBET Lucas",
            "SIEURIN Romain",
            "VINCENT Theo",
            "Bande originale : Arthus",
            "Ressources complémentaires :",
            "Images de fond des menus :",
            "https://designer.microsoft.com/image-creator",
            "Logique de modélisation du labyrinthe :",
            "https://fr.wikipedia.org/wiki/Modélisation_mathématique_d'un_labyrinthe",
            "Sprites des Artéfacts :",
            "https://craftpix.net/file-licenses/",
            "Sprites des Sorciers et Chevaliers :",
            "https://opengameart.org/content/lpc-medieval-fantasy-character-sprites",
        ]

        # Fonction pour découper automatiquement une ligne trop longue
        def decouper_texte(texte, font, max_largeur):
            lignes = []
            ligne_courante = ""
            
            # Diviser le texte en mots
            mots = texte.split(' ')
            
            for mot in mots:
                # Vérifier la largeur de la ligne avec le mot ajouté
                if font.size(ligne_courante + mot)[0] > max_largeur:
                    if ligne_courante:
                        lignes.append(ligne_courante)
                    ligne_courante = mot + " "
                else:
                    ligne_courante += mot + " "
            
            if ligne_courante:
                lignes.append(ligne_courante)

            return lignes

        # Position de départ pour les crédits (en dessous du titre)
        y_offset = rect_pos[1] + 100  # Départ après le titre
        max_largeur = 700  # Largeur maximale pour le retour à la ligne

        image_back_rect = self.image_back.get_rect(midbottom=(self.screen.get_width() // 2, self.screen.get_height() - 25))

        while credits_running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN or event.key == pygame.K_ESCAPE:
                        credits_running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    # Vérifier si le clic est sur l'image `back.png`
                    if image_back_rect.collidepoint(event.pos):
                        credits_running = False
                        self.ecran_du_debut = True

            # Affichage
            self.screen.blit(self.image_credits, (0, 0))
            self.screen.blit(rect_surface, rect_pos)

            self.screen.blit(titre_surface, titre_rect)

            current_y = y_offset  # Y de départ pour les crédits
            ressources = False
            for credit in credits:
                if credit == "Ressources complémentaires :":
                    current_y += 25
                # Vérifier si lien
                if ressources:
                    lignes_decoupees = decouper_texte(credit, font_liens, max_largeur)
                    for ligne in lignes_decoupees:
                        couleur = couleur_liens if "http" in ligne else (255, 255, 255)
                        credit_surface = font_liens.render(ligne, True, couleur)  # Texte des liens avec couleur différente
                        credit_rect = credit_surface.get_rect(midtop=(self.screen.get_width() // 2, current_y))  # Centré
                        self.screen.blit(credit_surface, credit_rect)
                        current_y += 20
                else:
                    lignes_decoupees = decouper_texte(credit, font_credits, max_largeur)
                    for ligne in lignes_decoupees:
                        credit_surface = font_credits.render(ligne, True, (255, 255, 255))  # Texte des crédits en blanc
                        credit_rect = credit_surface.get_rect(midtop=(self.screen.get_width() // 2, current_y))  # Centré
                        self.screen.blit(credit_surface, credit_rect)
                        current_y += 30
                if credit == "Ressources complémentaires :":
                    ressources = True

            self.screen.blit(self.image_back, image_back_rect)       
            # Obtenir la position actuelle de la souris
            mouse_x, mouse_y = pygame.mouse.get_pos()
            # Dessiner l'image du curseur à la position de la souris
            self.screen.blit(self.cursor_image, (mouse_x, mouse_y))
            
            pygame.display.update()


    def afficher_regle(self):
        regle_running = True

        #création rectangle semi-transparent
        couleur_rect = (0, 0, 0)
        transparence = 180
        rect_surface = pygame.Surface((self.screen.get_width() - 100, self.screen.get_height() - 200))
        rect_surface.set_alpha(transparence)
        rect_surface.fill(couleur_rect)

        # Position et taille du rectangle
        rect_pos = (50, 100)

        font_titre = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 43)
        titre_text = "EXPLORACE - REGLES"
        titre_surface = font_titre.render(titre_text, True, (255, 255, 255))
        titre_rect = titre_surface.get_rect(center=(self.screen.get_width() // 2, rect_pos[1] + 50))  # Centré en haut du rectangle
        
        font_regles = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 20)
        regles = [
            "1. Choisis ton équipe parmi les Sorciers ou les Chevaliers et affronte l'autre camp !",
            "2. Tu es plongé avec un membre de la faction adverse dans un labyrinthe mystérieux.",
            "3. L'objectif : Trouve l'artéfact avant ton adversaire et dans le temps imparti.",
            "4. Tu disposes de 2 minutes pour le prendre avant que le labyrinthe ne se referme.",
            "5. Le temps presse alors plus vite tu t'en empares, plus ton score sera élevé.",
            "Bonne chance à l'intérieur de ce dédale !"
        ]

        #découpage automatiquement pour une ligne trop longue
        def decouper_texte(texte, font, max_largeur):
            mots = texte.split(' ')
            lignes = []
            ligne_courante = ""

            for mot in mots:
                # Test si ajouter ce mot dépasse la largeur maximale
                if font.size(ligne_courante + mot)[0] <= max_largeur:
                    ligne_courante += mot + " "
                else:
                    lignes.append(ligne_courante)  # Ajoute la ligne actuelle
                    ligne_courante = mot + " "  # Commence une nouvelle ligne

            lignes.append(ligne_courante)  # Ajouter la dernière ligne restante
            return lignes

        # Position de départ pour les règles (en dessous du titre)
        y_offset = rect_pos[1] + 100  # Départ après le titre
        max_largeur = 915  # Largeur max (avant retour à la ligne)

        image_back_rect = self.image_back.get_rect(midbottom=(self.screen.get_width() // 2, self.screen.get_height() - 25))

        while regle_running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN or event.key == pygame.K_ESCAPE:
                        regle_running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if image_back_rect.collidepoint(event.pos):
                        regle_running = False
                        self.ecran_du_debut = True

                # Affichage
                self.screen.blit(self.image_regle, (0, 0))
                self.screen.blit(rect_surface, rect_pos)

                self.screen.blit(titre_surface, titre_rect)

                current_y = y_offset  # Y de départ pour les règles
                for regle in regles:
                    lignes_decoupees = decouper_texte(regle, font_regles, max_largeur)
                    for ligne in lignes_decoupees:
                        regle_surface = font_regles.render(ligne, True, (255, 255, 255))  # Texte en blanc
                        regle_rect = regle_surface.get_rect(midtop=(self.screen.get_width() // 2, current_y))  # Centré
                        self.screen.blit(regle_surface, regle_rect)
                        current_y += 40

                # Calculer la position pour centrer l'image en bas
                image_back_rect = self.image_back.get_rect(midbottom=(self.screen.get_width() // 2, self.screen.get_height() - 25))

                self.screen.blit(self.image_back, image_back_rect)        
                
                # Obtenir la position actuelle de la souris
                mouse_x, mouse_y = pygame.mouse.get_pos()
                # Dessiner l'image du curseur à la position de la souris
                self.screen.blit(self.cursor_image, (mouse_x, mouse_y))

                pygame.display.update()

    def afficher_texte_clignotant(self):
        # Police pour les raccourcis claviers
        font_clignotant = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 10)

        #dico des raccourcis clavier associés à chaque bouton
        raccourcis = {
            "regles": "Ctrl + R",
            "credits": "Ctrl + C",
            "quitter": "Ctrl + Q"
        }

        # Positionner et afficher le texte sous chaque bouton
        for nom, raccourci in raccourcis.items():
            bouton_rect = self.boutons[nom]
            texte_surface = font_clignotant.render(raccourci, True, (255, 255, 255))

            # Positionner le texte légèrement en dessous du bouton
            texte_rect = texte_surface.get_rect(center=(bouton_rect.centerx, bouton_rect.bottom + 15))

            # Afficher le texte clignotant
            self.screen.blit(texte_surface, texte_rect)            