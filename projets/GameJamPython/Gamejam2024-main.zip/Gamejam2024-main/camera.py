import pygame as pg

class Camera:
    def __init__(self, width, height):
        self.camera = pg.Rect(0, 0, width, height) #Ecran de la camera
        self.width = width
        self.height = height
        


    # Applique la camera à un objet
    def apply(self, entity):
        return entity.rect.move(self.camera.center)
    
    # Applique la camera à un rectangle
    def apply_rect(self, rect):
        return rect.move(self.camera.center)

    # Met à jour la camera en fonction de la position du joueur
    def update(self, target):
        # on récupère les dimensions de la map
        width = target.maze.width*target.tile_size
        height = target.maze.height*target.tile_size
        # calculer un offset x et un offset y pour ne pas que la caméra sorte de la map
        # si la moitié de la taille de la caméra est plus grande que la distance entre le centre du joueur et le bord de la map
        offsetX = 0
        offsetY = 0
        if self.width / 2 > target.rect.centerx:
            offsetX = target.rect.centerx - self.width / 2
        if self.height / 2 > target.rect.centery:
            offsetY = target.rect.centery - self.height / 2
        if width - self.width / 2 < target.rect.centerx:
            offsetX = target.rect.centerx - width + self.width / 2
        if height - self.height / 2 < target.rect.centery:
            offsetY = target.rect.centery - height + self.height / 2
        x = -target.rect.centerx + int(self.width / 2) + offsetX
        y = -target.rect.centery + int(self.height / 2) + offsetY

        self.camera = pg.Rect(x, y, 0, 0)

    