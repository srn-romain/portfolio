import pygame
import sys

class FinDeJeu:
    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()

        self.font = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 30)

        #charger images    
        self.image_fin = pygame.image.load('images/background_fin.png')
        self.image_fin = pygame.transform.scale(self.image_fin, (self.screen.get_width(), self.screen.get_height()))
        self.image_sorcier = pygame.image.load('images/sorcier.png')
        self.image_sorcier = pygame.transform.scale(self.image_sorcier, (262, 420))
        self.image_chevalier = pygame.image.load('images/chevalier.png')
        self.image_chevalier = pygame.transform.scale(self.image_chevalier, (262, 420))
        self.image_bouton = pygame.image.load('images/button.png')

        # initialisation rectangle de fond
        self.couleur_rect = (0, 0, 0)
        self.transparence = 180  # Niveau de transparence (0 = complètement transparent, 255 = opaque)
        self.rect_surface = pygame.Surface((self.screen.get_width() - 100, self.screen.get_height() - 200))  # Taille légèrement plus petite que l'écran
        self.rect_surface.set_alpha(self.transparence)  # Appliquer transparence
        self.rect_surface.fill(self.couleur_rect)  # Remplir avec la couleur noire

        # Création rectangle
        self.boutons = {
            "Rejouer": pygame.Rect(self.screen.get_width() // 2 - 100, 490, 250, 50),
            "Quitter": pygame.Rect(self.screen.get_width() // 2 - 100, 560, 250, 50)
        }

        
        # Charger l'image du curseur personnalisé
        self.cursor_image = pygame.image.load('images/cursor.png').convert_alpha()
        pygame.mouse.set_visible(False)  # Cacher le curseur par défaut

    def afficher_ecran_fin(self, score):
        fin_running = True

        while fin_running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if self.boutons["Rejouer"].collidepoint(event.pos):
                        return True
                    if self.boutons["Quitter"].collidepoint(event.pos):
                        pygame.quit()
                        sys.exit()

            # Affichage principiale
            self.screen.blit(self.image_fin, (0, 0))

            rect_pos = (50, 100)
            self.screen.blit(self.rect_surface, rect_pos)

            font_titre = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 43)
            titre_text = "Tu as gagné.e ! Félicitations !"
            titre_surface = font_titre.render(titre_text, True, (255, 255, 255))
            titre_rect = titre_surface.get_rect(center=(self.screen.get_width() // 2, rect_pos[1] + 47))
            self.screen.blit(titre_surface, titre_rect)

            # affichage score
            font_score = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 30)
            score_message = f'Score: {score:.0f}'
            score_surface = font_score.render(score_message, True, (255, 255, 255))
            score_rect = score_surface.get_rect(center=(self.screen.get_width() // 2, rect_pos[1] + 190)) #position vertical
            self.screen.blit(score_surface, score_rect)


            # Calculer les positions des boutons
            rect_width = self.rect_surface.get_width()
            rect_height = self.rect_surface.get_height()
            bouton_width = 250
            bouton_height = 50
            espace_total = rect_height - (titre_rect.bottom - rect_pos[1])  # Espace total dispo
            espace_entre_boutons = 50

            # Positionner les boutons "Rejouer" et "Quitter"
            y_position = score_rect.bottom + espace_entre_boutons
            for nom in ["Rejouer", "Quitter"]:
                bouton_rect = pygame.Rect(rect_pos[0] + (rect_width - bouton_width) // 2, y_position, bouton_width, bouton_height)
                self.boutons[nom] = bouton_rect
                y_position += bouton_height + espace_entre_boutons

            self.afficher_bouton("Rejouer", "Rejouer")
            self.afficher_bouton("Quitter", "Quitter")

            # Affichage perso
            sorcier_x = 80
            sorcier_y = self.screen.get_height() - self.image_sorcier.get_height() - 180
            self.screen.blit(self.image_sorcier, (sorcier_x, sorcier_y))

            chevalier_x = self.screen.get_width() - self.image_chevalier.get_width() - 80
            chevalier_y = self.screen.get_height() - self.image_chevalier.get_height() - 180
            self.screen.blit(self.image_chevalier, (chevalier_x, chevalier_y))

            
            # Obtenir la position actuelle de la souris
            mouse_x, mouse_y = pygame.mouse.get_pos()
            # Dessiner l'image du curseur à la position de la souris
            self.screen.blit(self.cursor_image, (mouse_x, mouse_y))
            
            # Mise à jour de l'affichage
            pygame.display.flip()
            self.clock.tick(30)

        return False
    
    def afficher_bouton(self, nom, texte):
        bouton_image = pygame.transform.scale(self.image_bouton, (250, 50))
        bouton_rect = self.boutons[nom]
        self.screen.blit(bouton_image, bouton_rect)

        font = pygame.font.Font('Press_Start_2P/Press_Start_2P.ttf', 30)

        texte_surface = font.render(texte, True, (255, 255, 255))

        texte_rect = texte_surface.get_rect(center=bouton_rect.center)

        self.screen.blit(texte_surface, texte_rect)