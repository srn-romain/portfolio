import argparse
import pygame
import pytmx
import socket
import threading
import json
from Maze import Maze
from player import Player
from accueil import Accueil
from fin import FinDeJeu
from camera import Camera

def receive_map_name(client_socket):
    buffer = ""
    while True:
        chunk = client_socket.recv(1024).decode('utf-8')
        buffer += chunk
        if '\n' in buffer:
            message = buffer.split('\n')[0]
            data = json.loads(message)
            if data['type'] == 'map_name':
                return data['name']

def main():
    # Création du parser d'arguments
    parser = argparse.ArgumentParser(description="Connexion au serveur")

    # Définition des arguments
    parser.add_argument("ip", type=str, nargs="?", default="127.0.0.1", help="server ip")

    # Parsing des arguments
    args = parser.parse_args()

    server_ip = args.ip
    server_port = 5555

    # Initialisation de Pygame
    pygame.init()

    TILE_SIZE = 256
    WIDTH, HEIGHT = 20, 20
    WINDOW_SIZE = 1024, 768
    MODE = 'fusion'
    MAX_DISTANCE = 50
    CONSUMABLES = True
    FPS = 30  # Définir les images par seconde (30 FPS par exemple)

    # Créer la fenêtre
    screen = pygame.display.set_mode(WINDOW_SIZE)

    # Créer une instance de la classe Accueil
    fin = FinDeJeu(screen)
    accueil = Accueil(screen, server_ip)

    accueil.afficher_histoire()
    # Afficher l'écran d'accueil avant de lancer le jeu
    if not accueil.afficher_ecran_d_accueil():
        return

    # Connexion au serveur
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((server_ip, server_port))

    # Recevoir l'ID du joueur du serveur
    player_id = int(client_socket.recv(1024).decode('utf-8'))
    print(f"[DEBUG] Connected to server with player ID: {player_id}")

    # Recevoir le nom de la carte du serveur
    map_name = receive_map_name(client_socket)
    print(f"Received map name from server: {map_name}")
    try:
        with open("./mazeArray.json", 'r') as file:
            map_data = json.load(file)
        maze = Maze.fromJSON(map_data[map_name])
    except FileNotFoundError:
        print(f"Error: Map file not found.")
        return
    except json.JSONDecodeError:
        print(f"Error: Unable to parse JSON.")
        return

    tmx_file = maze.getTMX()
    tmx_data = pytmx.load_pygame(tmx_file)

    # Créer une instance du joueur
    player = Player(maze, TILE_SIZE)

    # Créer une instance de la caméra
    camera = Camera(1024, 768)

    # Stocker les positions des autres joueurs
    other_players = {}

    # ajout du theme du jeu dans le labyrinthe
    pygame.mixer.music.load('music/inGameTheme.wav')
    pygame.mixer.music.play(-1, 0.1)
    pygame.mixer.music.set_volume(0.1)

    # ajout des sons
    win_sound = pygame.mixer.Sound("music/win.wav")
    loose_sound = pygame.mixer.Sound("music/lose.wav")
    pygame.mixer.Sound.set_volume(win_sound, 0.2)
    pygame.mixer.Sound.set_volume(loose_sound, 0.2)

    def send_position():
        position_data = {
            'type': 'position',
            'position': {'x': player.rect.x, 'y': player.rect.y}
        }
        client_socket.send(json.dumps(position_data).encode('utf-8'))

    def send_win():
        win_data = {
            'type': 'win'
        }
        client_socket.send(json.dumps(win_data).encode('utf-8'))

    def send_consumed():
        consumed_data = {
            'type': 'consumed',
            'coordX': player.consumed[0],
            'coordY': player.consumed[1]
        }
        print(consumed_data)
        client_socket.send(json.dumps(consumed_data).encode('utf-8'))
        player.consumed = []

    def end_game():
        pygame.mixer.music.stop()  # stop la musique
        fin.afficher_ecran_fin(score)
        time = 0
        main()

    def load_new_map(map_name):
        nonlocal maze, tmx_data, player
        try:
            with open("./mazeArray.json", 'r') as file:
                map_data = json.load(file)
            maze = Maze.fromJSON(map_data[map_name])
            tmx_file = maze.getTMX()
            tmx_data = pytmx.load_pygame(tmx_file)
            player.maze = maze  # Update player's maze reference
            player.rect.x, player.rect.y = (maze.start[0] * maze.tile_size + maze.tile_size / 2 - player.rect.width / 2, maze.start[1] * maze.tile_size + maze.tile_size / 2 - player.rect.height / 2)
            print(f"Loaded new map: {map_name}")
        except FileNotFoundError:
            print(f"Error: Map file not found.")
        except json.JSONDecodeError:
            print(f"Error: Unable to parse JSON in.")

    def receive_data():
        buffer = ""
        while True:
            try:
                chunk = client_socket.recv(1024).decode('utf-8')
                if not chunk:
                    break
                buffer += chunk

                if '\n' in buffer:
                    messages = buffer.split('\n')
                    for message in messages[:-1]:
                        try:
                            data = json.loads(message)

                            if data['type'] == 'map_name':
                                map_name = data['name']
                                print(f"Received new map name from server: {map_name}")
                                load_new_map(map_name)

                            elif data['type'] == 'positions':
                                nonlocal other_players
                                other_players = data['positions']
                            elif data['type'] == 'consumed':
                                maze.getCell(data['coordX'], data['coordY']).consumable.consumed = True
                            elif data['type'] == 'win':
                                if data['player_id'] == player_id:
                                    print("gagné")
                                else:
                                    print("perdu")
                                    time = 0
                                    pygame.mixer.Sound.play(loose_sound)
                                    pygame.mixer.music.stop()
                                    fin.afficher_ecran_fin(score)
                                    main()
                                    continue
                                # Ne pas appeler end_game() ici, le jeu continuera avec la nouvelle carte

                        except json.JSONDecodeError as e:
                            print(f"[ERROR] JSON decode error: {e}")

                    buffer = messages[-1]

            except Exception as e:
                print(f"[ERROR] Error receiving data: {e}")
                break

    # Créer et démarrer le thread pour recevoir les données
    receive_thread = threading.Thread(target=receive_data)
    receive_thread.daemon = True
    receive_thread.start()

    # Créer une horloge pour contrôler la vitesse du jeu
    clock = pygame.time.Clock()

    # Initialiser le score
    score = 0
    font = pygame.font.Font(None, 36)

    # Initialiser le décompte du temps
    start_timer = pygame.time.get_ticks()
    seconds = 120

    def draw_player_coordinates(screen, player):
        coordinates_text = f"Player Position: ({player.rect.x}, {player.rect.y})"
        text_surface = font.render(coordinates_text, True, (255, 255, 255))
        screen.blit(text_surface, (10, WINDOW_SIZE[1] - 40))

    def draw_maze(screen, tmx_data):
        for layer in tmx_data.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer):
                for x, y, gid in layer:
                    tile = tmx_data.get_tile_image_by_gid(gid)
                    if tile:
                        screen.blit(tile, camera.apply_rect(pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)))

        for obj in tmx_data.objects:
            cell = maze.getCell(obj.x // TILE_SIZE, obj.y // TILE_SIZE)
            if cell.consumable and not cell.consumable.consumed:
                tile = tmx_data.get_tile_image_by_gid(obj.gid)
                screen.blit(tile, camera.apply_rect(pygame.Rect(obj.x, obj.y, obj.width, obj.height)))

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        player.update(keys)

        send_position()

        camera.update(player)

        time = round(seconds - ((pygame.time.get_ticks() - start_timer) / 1000), 2)
        
        # Clear the screen before drawing
        screen.fill((0, 0, 0))
        
        draw_maze(screen, tmx_data)

        screen.blit(player.image, camera.apply(player))

        other_player_image = pygame.image.load('images/link_down.png').convert_alpha()

        for other_id, position in other_players.items():
            if other_id != player_id:
                other_player_rect = pygame.Rect(position['x'], position['y'], TILE_SIZE, TILE_SIZE)
                screen.blit(other_player_image, camera.apply_rect(other_player_rect))

        score_text = font.render(f"Score: {score}", True, (255, 255, 255))
        screen.blit(score_text, (10, 10))

        time_text = font.render(f"Time: {time}", True, (255, 255, 255))
        screen.blit(time_text, (WINDOW_SIZE[0] // 2 - 50, 10))

        draw_player_coordinates(screen, player)

        pygame.display.flip()

        clock.tick(FPS)

        if player.check_end():
            print("j'ai gagné")
            send_win()
            score += 0 + round(time, 0)
            pygame.mixer.Sound.play(win_sound)
            start_timer = pygame.time.get_ticks()
            fin.afficher_ecran_fin(score)
            score = 0
            main()

        if time <= 0:
            time = 0
            pygame.mixer.Sound.play(loose_sound)
            pygame.mixer.music.stop()
            fin.afficher_ecran_fin(score)
            main()
            continue

    client_socket.close()
    pygame.quit()

if __name__ == "__main__":
    main()
