import argparse
import socket
import threading
import json
import random
import os
from Maze import Maze

class GameServer:
    def __init__(self, hostname, port=5555):
        if hostname != "":
            self.host = hostname
        else:
            self.host = socket.gethostbyname(socket.gethostname())
        print(self.host)
        self.port = port
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.bind((self.host, self.port))
        self.clients = {}
        self.player_positions = {}
        self.consumedList = []
        # self.maze = Maze(20, 20, 256, "fusion", 50)
        # self.maze_data = self.maze.to_dict()
        self.start_position = {'x': 0, 'y': 0} 
        self.clients_lock = threading.Lock()
        self.player_positions_lock = threading.Lock()     
        self.selected_map = self.choose_random_map()


    def choose_random_map(self):
        # retourne un nombre entre 0 et 99
        return random.randint(0, 99)
            # map_files = [f for f in os.listdir("Map") if f.startswith("map_") and f.endswith(".json")]
            #return random.choice(map_files)
    
    
    def notify_new_map(self):
        self.selected_map = self.choose_random_map()
        with self.clients_lock:
            for client_socket in self.clients.values():
                message = json.dumps({'type': 'map_name', 'name': self.selected_map}) + '\n'
                try:
                    client_socket.sendall(message.encode('utf-8'))
                    print(f"Sent new map name to client: {self.selected_map}")
                except Exception as e:
                    print(f"Error sending new map name to client: {e}")

    def process_data(self, player_id, data):
        try:
            data = json.loads(data)
            if data['type'] == 'position':
                with self.player_positions_lock:
                    self.player_positions[player_id] = data['position']
                self.broadcast_positions()
            elif data['type'] == 'consumed':
                print(f"[DEBUG] Consumed: {data['coordX']} {data['coordY']}")
                self.consumedList.append([data['coordX'], data['coordY']])
                self.broadcast_consumed()
            elif data['type'] == 'win':
                self.broadcast_win(player_id)
                self.notify_new_map()  # Notify all clients of the new map
        except json.JSONDecodeError as e:
            print(f"[ERROR] Failed to decode JSON from player {player_id}: {e}")

    # ... (autres méthodes de la classe)


    def send_map_name(self, client_socket):
        message = json.dumps({'type': 'map_name', 'name': self.selected_map}) + '\n'
        try:
            client_socket.sendall(message.encode('utf-8'))
            print(f"Sent map name to client: {self.selected_map}")
        except Exception as e:
            print(f"Error sending map name to client: {e}")


    def start(self):
        self.server_socket.listen()
        print(f"Server started on {self.host}:{self.port}")
        print(f"Selected map: {self.selected_map}")
        while True:
            client_socket, address = self.server_socket.accept()
            print(f"New connection from {address}")
            player_id = len(self.clients)
            client_socket.sendall(str(player_id).encode('utf-8'))
            print(f"Assigned player ID {player_id} to {address}")

            with self.clients_lock:
                self.clients[player_id] = client_socket
                self.player_positions[player_id] = self.start_position.copy()

            self.send_map_name(client_socket)
            client_thread = threading.Thread(target=self.handle_client, args=(client_socket, address, player_id))
            client_thread.start()

    def broadcast_positions(self):
        with self.clients_lock:
            for player_id, client_socket in self.clients.items():
                positions_to_send = {pid: pos for pid, pos in self.player_positions.items() if pid != player_id}
                message = json.dumps({'type': 'positions', 'positions': positions_to_send}) + '\n'
                try:
                    client_socket.sendall(message.encode('utf-8'))
                    # print(f"[DEBUG] Sent positions to player {player_id}: {positions_to_send}")
                except Exception as e:
                    print(f"[ERROR] Error sending data to player {player_id}: {e}")

    def broadcast_consumed(self):
        with self.clients_lock:
            for player_id, client_socket in self.clients.items():
                for consumed in self.consumedList:
                    message = json.dumps({'type': 'consumed', 'coordX': consumed[0], 'coordY': consumed[1]}) + '\n'
                    try:
                        client_socket.sendall(message.encode('utf-8'))
                        print(f"[DEBUG] Sent consumed to player {player_id}: {consumed}")
                    except Exception as e:
                        print(f"[ERROR] Error sending data to player {player_id}: {e}")

    def broadcast_win(self, winner_id):
        with self.clients_lock:
            for player_id, client_socket in self.clients.items():
                message = json.dumps({'type': 'win', 'player_id': winner_id}) + '\n'
                try:
                    client_socket.sendall(message.encode('utf-8'))
                    print(f"[DEBUG] Sent winner to player {player_id}: {winner_id}")
                except Exception as e:
                    print(f"[ERROR] Error sending data to player {player_id}: {e}")
        self.notify_new_map()  # Notify all clients of the new map 

    def broadcast_lose(self, loser_id):
        with self.clients_lock:
            for player_id, client_socket in self.clients.items():
                message = json.dumps({'type': 'loose', 'player_id': loser_id}) + '\n'
                try:
                    client_socket.sendall(message.encode('utf-8'))
                    print(f"[DEBUG] Sent winner to player {player_id}: {loser_id}")
                except Exception as e:
                    print(f"[ERROR] Error sending data to player {player_id}: {e}")
        self.notify_new_map()  # Notify all clients of the new map

    def handle_client(self, client_socket, address, player_id):
        try:
            while True:
                data = client_socket.recv(4096).decode('utf-8')
                if not data:
                    break
                # print(f"[DEBUG] Received data from player {player_id}: {data}")
                self.process_data(player_id, data)
        except Exception as e:
            print(f"[ERROR] Error handling client {player_id}: {e}")
        finally:
            self.handle_player_disconnection(player_id)
            client_socket.close()
            # print(f"[DEBUG] Connection from {address} closed (Player ID: {player_id})")

    def handle_player_disconnection(self, player_id):
        with self.clients_lock:
            if player_id in self.clients:
                del self.clients[player_id]
            if player_id in self.player_positions:
                del self.player_positions[player_id]
        self.broadcast_positions()
        self.notify_disconnection(player_id)

    def notify_disconnection(self, player_id):
        with self.clients_lock:
            for client_socket in self.clients.values():
                message = json.dumps({'type': 'disconnection', 'player_id': player_id}) + '\n'
                try:
                    client_socket.sendall(message.encode('utf-8'))
                    # print(f"[DEBUG] Notified disconnection of player {player_id}")
                except Exception as e:
                    print(f"[ERROR] Error notifying disconnection to player {player_id}: {e}")

    def send_maze_data(self, client_socket):
        maze_message = json.dumps({'type': 'maze', 'maze_data': self.maze_data})
        client_socket.send(maze_message.encode('utf-8'))
        # print(f"[DEBUG] Sent maze data to client")

    def process_data(self, player_id, data):
        try:
            data = json.loads(data)
            if data['type'] == 'position':
                with self.player_positions_lock:
                    self.player_positions[player_id] = data['position']
                # print(f"[DEBUG] Updated position for player {player_id}: {data['position']}")
                self.broadcast_positions()
            elif data['type'] == 'consumed':
                print(f"[DEBUG] Consumed: {data['coordX']} {data['coordY']}")
                self.consumedList.append([data['coordX'], data['coordY']])
                self.broadcast_consumed()
            elif data['type'] == 'win':
                self.broadcast_win(player_id)
            elif data['type'] == 'lose':
                self.broadcast_lose(player_id)
        except json.JSONDecodeError as e:
            print(f"[ERROR] Failed to decode JSON from player {player_id}: {e}")

if __name__ == "__main__":
    # Création du parser d'arguments
    parser = argparse.ArgumentParser(description="IP du serveur")
    
    # Définition des arguments
    parser.add_argument("ip", type=str, nargs="?", default="", help="server ip")
    
    # Parsing des arguments
    args = parser.parse_args()

    server = GameServer(args.ip)
    server.start()