from Maze import Maze
import json

# si mazeArray.json n'existe pas, on le crée
try:
    # on lit le fichier actuel
    with open("mazeArray.json", "r") as file:
        mazeArray = json.load(file)
except FileNotFoundError or json.decoder.JSONDecodeError:
    # on initialise avec une liste vide
    mazeArray = []

for i in range(len(mazeArray), 100):
    print(f"début maze {i+1}")
    mazeArray.append(Maze(20, 20, 256, "fusion", 50).toJSON())
    print(f"fin maze {i+1}")
    with open('mazeArray.json', 'w') as f:
        json.dump(mazeArray, f)

    
