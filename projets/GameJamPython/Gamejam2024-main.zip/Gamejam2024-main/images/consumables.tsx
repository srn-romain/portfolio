<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="consumables" tilewidth="256" tileheight="256" tilecount="3" columns="3">
 <image source="consumables.png" width="768" height="256"/>
</tileset>
