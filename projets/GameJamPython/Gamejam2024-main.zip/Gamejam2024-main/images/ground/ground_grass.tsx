<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="ground_grass" tilewidth="256" tileheight="256" tilecount="1" columns="1">
 <image source="ground_grass.png" width="256" height="256"/>
</tileset>
