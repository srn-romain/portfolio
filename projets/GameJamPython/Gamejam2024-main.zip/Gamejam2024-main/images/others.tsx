<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="others" tilewidth="256" tileheight="256" tilecount="13" columns="13">
 <image source="others.png" width="3328" height="256"/>
</tileset>
