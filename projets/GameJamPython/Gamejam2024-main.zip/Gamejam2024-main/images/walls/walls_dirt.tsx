<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="walls_dirt" tilewidth="256" tileheight="256" tilecount="15" columns="15">
 <image source="walls_dirt.png" width="3840" height="256"/>
</tileset>
