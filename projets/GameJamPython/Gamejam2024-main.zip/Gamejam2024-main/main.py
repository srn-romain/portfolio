import pygame
import pytmx
from Maze import Maze
from player import Player  # Assurez-vous que la classe Player est importée correctement
from accueil import Accueil 
from fin import FinDeJeu
from camera import Camera
import json

def main():
    # Initialisation de Pygame
    pygame.init()

    # Dimensions de la fenêtre et des tuiles
    TILE_SIZE = 256
    WIDTH, HEIGHT = 20, 20
    WINDOW_SIZE = 1024, 768
    MODE = 'fusion'
    MAX_DISTANCE = 50
    CONSUMABLES = True
    FPS = 30  # Définir les images par seconde (30 FPS par exemple)

    

    # Créer la fenêtre
    screen = pygame.display.set_mode(WINDOW_SIZE)
    

    # Générer un labyrinthe
    maze = Maze(WIDTH, HEIGHT, TILE_SIZE, MODE, MAX_DISTANCE, CONSUMABLES)

    # Charger un Labyrinthe depuis un fichier JSON'''
    with open('map.json', 'r') as file:
        map_data = json.load(file)
    maze = Maze.fromJSON(map_data)

    # Générer un fichier TMX à partir du labyrinthe
    tmx_file = maze.getTMX()
    # Charger le fichier TMX avec PyTMX
    tmx_data = pytmx.load_pygame(tmx_file)

    # Créer une instance de la classe Accueil
    fin = FinDeJeu(screen)
    accueil = Accueil(screen)

    # Afficher l'écran d'accueil avant de lancer le jeu
    accueil.afficher_ecran_d_accueil()

    # Créer une instance du joueur
    player = Player(maze, TILE_SIZE)

    # Créer une instance de la caméra
    camera = Camera(1024, 768)

    # Fonction pour dessiner le labyrinthe
    def draw_maze(screen, tmx_data):
        # on gère l'affichage des tuiles
        for layer in tmx_data.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer):
                for x, y, gid in layer:
                    tile = tmx_data.get_tile_image_by_gid(gid)
                    if tile:
                        screen.blit(tile, camera.apply_rect(pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)))
        
        # on gère l'affichage des objets
        for obj in tmx_data.objects:
            # on récupère la case correspondante du labyrinthe
            cell = maze.getCell(obj.x // TILE_SIZE, obj.y // TILE_SIZE)
            # on vérifie si le consommable est consommé ou non
            if cell.consumable and not cell.consumable.consumed:
                tile = tmx_data.get_tile_image_by_gid(obj.gid)
                screen.blit(tile, camera.apply_rect(pygame.Rect(obj.x, obj.y, obj.width, obj.height)))
                    

    # Créer une horloge pour contrôler la vitesse du jeu
    clock = pygame.time.Clock()

    # Initialiser le score
    score = 0
    font = pygame.font.Font(None, 36)

    # Initialiser le décompte du temps
    start_timer = pygame.time.get_ticks()
    seconds = 15
    
    # ajout du theme du jeu dans le labyrinthe
    pygame.mixer.music.load('music/inGameTheme.wav')
    pygame.mixer.music.play(-1, 0.1)
    pygame.mixer.music.set_volume(0.2)
    
    # Boucle principale
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
        keys = pygame.key.get_pressed()
        player.update(keys)  # Mettre à jour la position du joueur en fonction des touches pressées

        # Mettre à jour la caméra en fonction de la position du joueur
        camera.update(player)

        # Calculer le temps restant
        time = round(seconds-((pygame.time.get_ticks() - start_timer)/1000),2)
            
        # Dessiner le labyrinthe
        draw_maze(screen, tmx_data)
        
        # Dessiner le joueur avec l'application de la caméra
        screen.blit(player.image, camera.apply(player))
        
        # Afficher le score
        score_text = font.render(f"Score: {score:.0f}", True, (255, 255, 255))
        screen.blit(score_text, (10, 10))  # Affiche le score en haut à gauche

        #Afficher le temps restant
        time_text = font.render(f"Time: {time}", True, (255, 255, 255))
        # Affiche le temps en haut au milieu
        screen.blit(time_text, (WINDOW_SIZE[0]//2 - 50, 10))

        # Rafraîchir l'écran
        pygame.display.flip()
        
        # Contrôler la vitesse du jeu
        clock.tick(FPS)  # Limiter le jeu à FPS images par seconde

        
        # Vérifier si le joueur a atteint la fin
        if player.check_end():
            score += 0 + round(time,0)  # Incrémente le score (0 point bonus)
            time = 0
            pygame.mixer.music.stop() # stop la musique
            fin.afficher_ecran_fin(score)
            main()
            # Puis ajouter le niveau suivant 

        # Vérifier si le temps est écoulé
        if time <= 0:
            time = 0
            pygame.mixer.music.stop()
            fin.afficher_ecran_fin(score)
            main()
            accueil.ecran_du_debut = True
            accueil.afficher_ecran_d_accueil()

    # Quitter Pygame
    pygame.quit()

if __name__ == "__main__":
    main()