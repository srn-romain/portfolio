import pygame
import random
from SpriteSheet import SpriteSheet

class Player(pygame.sprite.Sprite):
    
    def __init__(self, maze, tile_size):
        super().__init__()
        self.tile_size = tile_size
        self.velocity = 64
        
        # Initialisation des spritesheets
        self.sprite_right_wizard = SpriteSheet(pygame.image.load('images/moveRightWizard.png').convert_alpha())
        self.sprite_left_wizard = SpriteSheet(pygame.image.load('images/moveLeftWizard.png').convert_alpha())
        self.sprite_down_wizard = SpriteSheet(pygame.image.load('images/moveDownWizard.png').convert_alpha())
        self.sprite_up_wizard = SpriteSheet(pygame.image.load('images/moveUpWizard.png').convert_alpha())
        
        # celui du chevalier
        self.sprite_right_knight= SpriteSheet(pygame.image.load('images/moveRightKnight.png').convert_alpha())
        self.sprite_left_knight = SpriteSheet(pygame.image.load('images/moveLeftKnight.png').convert_alpha())
        self.sprite_down_knight = SpriteSheet(pygame.image.load('images/moveDownKnight.png').convert_alpha())
        self.sprite_up_knight = SpriteSheet(pygame.image.load('images/moveUpKnight.png').convert_alpha())

        # Initialisation des animations_wizard
        self.animations_wizard = {
            'right': [self.sprite_right_wizard.get_image(i, 64, 64, 1) for i in range(4)],
            'left': [self.sprite_left_wizard.get_image(i, 64, 64, 1) for i in range(4)],
            'down': [self.sprite_down_wizard.get_image(i, 64, 64, 1) for i in range(4)],
            'up': [self.sprite_up_wizard.get_image(i, 64, 64, 1) for i in range(4)]
        }
        self.animations_knight = {
            'right': [self.sprite_right_knight.get_image(i, 64, 64, 1) for i in range(4)],
            'left': [self.sprite_left_knight.get_image(i, 64, 64, 1) for i in range(4)],
            'down': [self.sprite_down_knight.get_image(i, 64, 64, 1) for i in range(4)],
            'up': [self.sprite_up_knight.get_image(i, 64, 64, 1) for i in range(4)]
        }

        self.animations = self.animations_knight
        
        self.current_frame = 0
        self.animation_speed = 0.2
        self.direction = 'up'
        
        self.image = self.animations[self.direction][self.current_frame]
        self.rect = self.image.get_rect()
        self.rect.topleft = (maze.start[0] * tile_size + tile_size / 2 - self.rect.width / 2, maze.start[1] * tile_size + tile_size / 2 - self.rect.height / 2)
        self.velocity = 32
        self.maze = maze
        self.current_cell = maze.getCell(self.rect.x // tile_size, self.rect.y // tile_size)
        self.consumed = []
        
        
        # gestion du son
        self.boost_sound = pygame.mixer.Sound("music/boost.wav")
        self.teleport_sound = pygame.mixer.Sound("music/teleport.wav")
        pygame.mixer.Sound.set_volume(self.boost_sound,1.0)
        pygame.mixer.Sound.set_volume(self.teleport_sound,1.0)
        
        # gestion du boost
        self.isBoosted = False
        self.boostEndTime = 0  # moment où le boost prendra fin
        
    def update_animation(self):
        self.current_frame += self.animation_speed
        if self.current_frame >= len(self.animations[self.direction]):
            self.current_frame = 0
        self.image = self.animations[self.direction][int(self.current_frame)]
        self.mask = pygame.mask.from_surface(self.image)

    # nouvelle méthode move, mais qui gère plutôt les coordonnées et collisions
    def move(self, dx, dy, collision):
        
        if dx == -1:
            self.direction = 'left'
        elif dx == 1:
            self.direction = 'right'
        elif dy == -1:
            self.direction = 'up'
        elif dy == 1:
            self.direction = 'down'
            
        # on calcule les nouvelles coordonnées
        new_x = self.rect.x + dx * self.velocity
        new_y = self.rect.y + dy * self.velocity
        new_rect = self.rect.move(dx * self.velocity, dy * self.velocity)
        # on vérifie si le déplacement est possible
        if not collision or not self.maze.isWall(self.rect, new_rect):
            # on met à jour le positionnement du joueur
            self.rect = new_rect
            # on met à jour la cellule courante
            self.current_cell = self.maze.getCell(self.rect.x // self.tile_size, self.rect.y // self.tile_size)
            # s'il y a un consommable sur la cellule, on le consomme
            self.check_item()
            

    def check_item(self):
        if self.current_cell.consumable and not self.current_cell.consumable.consumed:
            # on vérifie que le joueur et dans un carré de qui mesure tile_size/2 au milieu de la case
            centerX = self.rect.x % self.tile_size
            centerY = self.rect.y % self.tile_size
            minInCell = self.tile_size // 4 - self.rect.width // 2
            maxInCell = self.tile_size // 4 + self.rect.width // 2
            if minInCell <= centerX <= maxInCell and minInCell <= centerY <= maxInCell:
                self.current_cell.consumable.consume(self)
                self.consumed = [self.current_cell.x, self.current_cell.y]

    def update(self, keys):
        collision = True
        #si space est pressé, collision = False
        if keys[pygame.K_SPACE]:
            collision = False
        if keys[pygame.K_LEFT] or keys[pygame.K_q]:
            self.move(-1, 0, collision)
        elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.move(1, 0, collision)
        elif keys[pygame.K_UP] or keys[pygame.K_z]:
            self.move(0, -1, collision)
        elif keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.move(0, 1, collision)
        self.update_animation()

        self.checkBoost()

    def check_end(self):
        end_x, end_y = self.maze.end
        if (self.rect.x // self.tile_size, self.rect.y // self.tile_size) == (end_x, end_y):
            print("GG")
            return True
        return False
    
    
    def boost(self):
        # on multiplie par 1.5 la vélocité du joueur pendant 10s
        self.velocity *= 1.5
        self.isBoosted = True
        pygame.mixer.Sound.play(self.boost_sound)
        
        self.boostEndTime = pygame.time.get_ticks() + 10000

    def checkBoost(self):
        if self.isBoosted:
            if pygame.time.get_ticks() > self.boostEndTime:
                self.velocity //= 1.5
                self.isBoosted = False

    def teleport(self):
        print("teleport")
        # on demande au labyrinthe la distance entre le joueur et la fin
        distance = self.maze.getDistance(self.current_cell, self.maze.getCell(self.maze.end[0], self.maze.end[1])) // 2
        print(distance)
        pygame.mixer.Sound.play(self.teleport_sound)
        
        # on cherche une cellule aléatoire à distance distance/2 de la fin
        cell = random.choice(self.maze.getCellsByDistance(self.current_cell, distance-1, distance))
        print((self.current_cell.x, self.current_cell.y), "=>", (cell.x, cell.y))
        # on déplace le joueur aux mêmes coordonnées sur la nouvelle cellule
        self.current_cell = cell
        self.rect.x = cell.x * self.tile_size + self.tile_size / 2 - self.rect.width / 2
        self.rect.y = cell.y * self.tile_size + self.tile_size / 2 - self.rect.height / 2